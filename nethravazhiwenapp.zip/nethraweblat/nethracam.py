from pathlib import Path
from hashlib import sha256
import asyncio
import os
import time

# Models and generated speech
APP_DIR = Path(__file__).resolve().parent
POTHOLE_MODEL_PATH = APP_DIR / "runs/detect/pothole_yolo26/weights/best.pt"
COCO_MODEL_PATH = APP_DIR / "yolo26n.pt"
OPEN_VOCAB_MODEL = "yolov8s-worldv2.pt"
ENABLE_OPEN_VOCAB = os.getenv("NETHRA_ENABLE_OPEN_VOCAB", "1").strip().lower() not in {"0", "false", "no"}
TTS_CACHE_DIR = APP_DIR / ".nethra_tts_cache"
TTS_LANGUAGE = "ml-IN"
EDGE_TTS_VOICE = os.getenv("NETHRA_TTS_VOICE", "ml-IN-SobhanaNeural").strip()
TTS_PROVIDER = "edge-tts+gtts-fallback"
STARTUP_TEXT = "നെത്രവഴി പ്രവർത്തനം തുടങ്ങി. മുന്നറിയിപ്പുകൾ ശ്രദ്ധിക്കുക."
SAFETY_STOP_TEXT = "നിൽക്കൂ. മുന്നോട്ട് പോകരുത്. ചൂരൽ ഉപയോഗിച്ച് വഴി പരിശോധിക്കുക."
SAFE_CAUTION_TEXT = "നിൽക്കൂ. മുന്നിൽ ഒരു തടസ്സം കണ്ടെത്തി. ചൂരൽ ഉപയോഗിച്ച് പരിശോധിക്കുക."
SAFE_CLEAR_TEXT = "പിന്തുണയ്ക്കുന്ന തടസ്സം കണ്ടെത്തിയില്ല.ചൂരൽ ഉപയോഗിച്ച് പരിശോധിച്ച് മാത്രം നീങ്ങുക."
POTHOLE_TEXT = "നിൽക്കൂ. മുന്നിൽ കുഴി കണ്ടെത്തി. മുന്നോട്ട് പോകരുത്. ചൂരൽ ഉപയോഗിച്ച് പരിശോധിക്കുക."
STAIRS_TEXT = "നിൽക്കൂ. മുന്നിൽ പടികൾ ഉണ്ടായേക്കാം. മുന്നോട്ട് പോകരുത്. ചൂരൽ ഉപയോഗിച്ച് പരിശോധിക്കുക."
FRONT_BLOCKED_TEXT = "നിൽക്കൂ. മുന്നിൽ തടസ്സം ഉണ്ടായേക്കാം. നിങ്ങൾ നിശ്ചലമായി നിൽക്കുക. വഴി പരിശോധിക്കാൻ ക്യാമറ മാത്രം പതുക്കെ ഇടത്തോട്ടോ വലത്തോട്ടോ തിരിക്കുക. ഇത് വഴി സുരക്ഷിതമാണെന്ന് ഉറപ്പാക്കുന്നില്ല."
LEFT_TEXT = "നിൽക്കൂ. ഇടത് വശം തടസ്സപ്പെട്ടിരിക്കുന്നു. വലത് വശം ചൂരൽ കൊണ്ട് പരിശോധിക്കുക. വഴി ചൂരൽ കൊണ്ട് സുരക്ഷിതമാണെന്ന് ഉറപ്പായാൽ മാത്രം വലത്തേക്ക് നീങ്ങുക."
RIGHT_TEXT = "നിൽക്കൂ. വലത് വശം തടസ്സപ്പെട്ടിരിക്കുന്നു. ഇടത് വശം ചൂരൽ കൊണ്ട് പരിശോധിക്കുക. വഴി ചൂരൽ കൊണ്ട് സുരക്ഷിതമാണെന്ന് ഉറപ്പായാൽ മാത്രം ഇടത്തേക്ക് നീങ്ങുക."
HELP_TEXT = "ഐ അമർത്തിയാൽ നിലവിലെ മുന്നറിയിപ്പ് വീണ്ടും കേൾക്കാം. ക്യു അമർത്തിയാൽ അടയ്ക്കാം."
PAUSE_TEXT = "സാധാരണ ശബ്ദ അറിയിപ്പുകൾ നിർത്തി."
RESUME_TEXT = "സാധാരണ ശബ്ദ അറിയിപ്പുകൾ വീണ്ടും തുടങ്ങി."

# Camera and detector settings
CAMERA_INDEX = 0
MIRROR_CAMERA = False   # True if left/right look swapped (e.g. a selfie-style laptop camera)
FRAME_SIZE = (416, 312)
INFERENCE_SIZE = 416
PROCESS_EVERY_N_FRAMES = 3
OPEN_VOCAB_EVERY_N_CYCLES = 3
COCO_MODEL_CONFIDENCE = 0.15  # Per-class thresholds below decide what is trusted.
COCO_CONFIDENCE = 0.55
PERSON_CONFIDENCE = 0.78  # Higher threshold reduces shirt/poster false positives.
CHAIR_MIN_CONFIDENCE = 0.45
POTHOLE_CONFIDENCE = 0.70
MIN_CONFIRM_FRAMES = 2
PERSON_CONFIRM_FRAMES = 3
POTHOLE_CONFIRM_FRAMES = 4      # a pothole must be seen in 4 frames in a row (false pothole alarms are costly)
OPEN_VOCAB_CONFIRM_FRAMES = 3
OPEN_VOCAB_MIN_CONFIDENCE = 0.45
TRACK_IOU_MIN = 0.12
TRACK_CENTER_MAX = 0.035
OPEN_VOCAB_LABELS = [
    ("stairs", "staircase or steps"),
    ("curb", "road curb"),
    ("ramp", "ramp"),
    ("traffic cone", "traffic cone"),
    ("bollard", "bollard"),
    ("road barrier", "road barrier"),
    ("doorway", "open doorway"),
    ("glass door", "glass door"),
    ("pole", "street pole"),
    ("wall", "wall directly in front of the camera"),
]
OPEN_VOCAB_PROMPTS = [prompt for _, prompt in OPEN_VOCAB_LABELS]
COCO_HAZARD_CLASSES = {
    "person", "bicycle", "motorcycle", "car", "bus", "truck",
    "traffic light", "stop sign", "bench", "chair", "couch",
    "dining table", "potted plant", "dog", "cat", "backpack", "umbrella",
    "handbag", "suitcase", "skateboard", "fire hydrant", "parking meter",
    "sports ball", "vase", "refrigerator", "oven", "sink", "toilet", "tv", "laptop",
    "cow", "horse", "sheep", "elephant",   # common on Indian roads (sheep also matches goats)
}
MALAYALAM_NAMES = {
    "person": "ആൾ", "bicycle": "സൈക്കിൾ", "motorcycle": "മോട്ടോർ സൈക്കിൾ",
    "car": "കാർ", "bus": "ബസ്", "truck": "ട്രക്ക്",
    "traffic light": "ട്രാഫിക് ലൈറ്റ്", "stop sign": "സ്റ്റോപ്പ് ബോർഡ്",
    "bench": "ബെഞ്ച്", "chair": "കസേര", "couch": "സോഫ",
    "dining table": "മേശ", "potted plant": "ചെടിച്ചട്ടി", "dog": "നായ",
    "cat": "പൂച്ച", "backpack": "ബാക്ക്പാക്ക്", "umbrella": "കുട",
    "handbag": "ഹാൻഡ് ബാഗ്", "suitcase": "സ്യൂട്ട്കേസ്",
    "skateboard": "സ്കേറ്റ്ബോർഡ്", "fire hydrant": "ഫയർ ഹൈഡ്രന്റ്",
    "pothole": "കുഴി", "obstacle": "തടസ്സം",
    "stairs": "പടികൾ", "curb": "റോഡിന്റെ അരിക്", "ramp": "ചരിവുള്ള പാത",
    "traffic cone": "ട്രാഫിക് കോൺ", "bollard": "തടയുതൂൺ",
    "road barrier": "വഴി തടയണ", "doorway": "വാതിൽപ്പടി",
    "glass door": "ഗ്ലാസ് വാതിൽ", "pole": "തൂൺ", "wall": "മതിൽ",
    "parking meter": "പാർക്കിംഗ് മീറ്റർ", "sports ball": "പന്ത്",
    "vase": "പൂച്ചട്ടി", "refrigerator": "ഫ്രിഡ്ജ്", "oven": "ഓവൻ",
    "sink": "സിങ്ക്", "toilet": "ടോയ്ലറ്റ്", "tv": "ടിവി", "laptop": "ലാപ്ടോപ്പ്",
    "cow": "പശു", "horse": "കുതിര", "sheep": "ആട്", "elephant": "ആന",
}

# Guidance thresholds: these image ratios are not real-world distances.
CENTER_LEFT_RATIO = 0.30
CENTER_RIGHT_RATIO = 0.70
CENTER_OVERLAP_MIN = 0.40   # an object this much inside the walking lane counts as "ahead"
CLOSE_BOTTOM_RATIO = 0.82
CLOSE_OBJECT_AREA_RATIO = 0.035
CLOSE_POTHOLE_AREA_RATIO = 0.010
# Alert only when an object is a little closer. "visible" (far) objects stay silent.
# To alert LATER (closer), raise APPROACH_BOTTOM_RATIO (e.g. 0.65) and APPROACH_AREA_FACTOR.
# To alert EARLIER (farther), lower them.
APPROACH_BOTTOM_RATIO = 0.58      # object's lower edge is this far down the picture
APPROACH_AREA_FACTOR = 0.45       # or it fills this share of the "near" size
ALERT_PROXIMITY = {"near", "approaching"}
ALERT_COOLDOWN_SECONDS = 0.35
REPEAT_ALERT_COOLDOWN_SECONDS = 3.0
URGENT_REPEAT_COOLDOWN_SECONDS = 0.75
CLEAR_REPEAT_COOLDOWN_SECONDS = 15.0   # the "nothing detected" message is not a loop

# Runtime audio state. TTS is generated once at startup; there is no worker/queue.
pygame_module = None
mixer_ready = False
last_spoken_key = None
last_tts_text = None
last_tts_time = 0.0
routine_speech_paused = False
edge_tts_error_reported = False


def is_reliable_coco_detection(name, confidence):
    """Filter weak detections; person claims require notably higher confidence."""
    label = str(name).strip().lower()
    if label not in COCO_HAZARD_CLASSES:
        return False
    threshold = PERSON_CONFIDENCE if label == "person" else (
        CHAIR_MIN_CONFIDENCE if label == "chair" else COCO_CONFIDENCE
    )
    return float(confidence) >= threshold


def get_class_name(names, class_id):
    try:
        return str(names[class_id])
    except (IndexError, KeyError, TypeError):
        return str(class_id)


def box_iou(first, second):
    """Intersection-over-union for boxes in pixel coordinates."""
    left, top = max(first[0], second[0]), max(first[1], second[1])
    right, bottom = min(first[2], second[2]), min(first[3], second[3])
    intersection = max(0, right - left) * max(0, bottom - top)
    area_a = max(0, first[2] - first[0]) * max(0, first[3] - first[1])
    area_b = max(0, second[2] - second[0]) * max(0, second[3] - second[1])
    union = area_a + area_b - intersection
    return intersection / union if union else 0.0


MAX_MISSED_FRAMES = 2   # a confirmed object may vanish for this many frames before it is forgotten


def confirm_detections(hazards, previous_tracks):
    """Only return an object after stable, one-to-one matches across frames.

    Works with many objects at once: every (detection, track) pair is scored and the
    best pairs are matched first, so two people / two cars never steal each other's
    track. A track that is missed for a frame or two is kept (and a confirmed one is
    still reported), so a single dropped detection does not reset confirmation or make
    the guidance flicker to "clear".
    """
    labels = [
        "pothole" if h.get("is_pothole") else str(h.get("label", "obstacle")).lower()
        for h in hazards
    ]
    pairs = []
    for h_index, hazard in enumerate(hazards):
        box = hazard["box"]
        center_x = (box[0] + box[2]) / 2
        for t_index, track in enumerate(previous_tracks):
            if track["label"] != labels[h_index]:
                continue
            old_box = track["box"]
            old_center = (old_box[0] + old_box[2]) / 2
            center_delta = abs(center_x - old_center) / max(1, hazard["frame_width"])
            overlap = box_iou(box, old_box)
            if overlap >= TRACK_IOU_MIN or center_delta <= TRACK_CENTER_MAX:
                pairs.append((1.0 - overlap + center_delta, h_index, t_index))
    pairs.sort(key=lambda item: item[0])

    matched = {}          # detection index -> track index
    used_tracks = set()
    for _, h_index, t_index in pairs:
        if h_index in matched or t_index in used_tracks:
            continue
        matched[h_index] = t_index
        used_tracks.add(t_index)

    next_tracks = []
    confirmed = []
    for h_index, hazard in enumerate(hazards):
        label = labels[h_index]
        prior = previous_tracks[matched[h_index]] if h_index in matched else None
        frames_seen = prior["frames_seen"] + 1 if prior else 1
        if hazard.get("open_vocab"):
            required = OPEN_VOCAB_CONFIRM_FRAMES
        elif label == "person":
            required = PERSON_CONFIRM_FRAMES
        elif label == "pothole":
            required = POTHOLE_CONFIRM_FRAMES
        else:
            required = MIN_CONFIRM_FRAMES
        hazard["frames_seen"] = frames_seen
        hazard["confirmed"] = frames_seen >= required
        next_tracks.append({
            "label": label, "box": hazard["box"], "frames_seen": frames_seen,
            "open_vocab": bool(hazard.get("open_vocab")), "missed": 0, "hazard": hazard,
        })
        if hazard["confirmed"]:
            confirmed.append(hazard)

    for index, track in enumerate(previous_tracks):
        if index in used_tracks:
            continue
        missed = track.get("missed", 0) + 1
        # Open-vocabulary models only run every few cycles, so their tracks live longer.
        limit = OPEN_VOCAB_EVERY_N_CYCLES - 1 if track.get("open_vocab") else MAX_MISSED_FRAMES
        if missed > limit:
            continue
        next_tracks.append({**track, "missed": missed})
        old = track.get("hazard")
        if old and old.get("confirmed"):          # keep reporting it while it is only briefly missed
            carried = dict(old)
            carried["carried"] = True
            confirmed.append(carried)

    return confirmed, next_tracks


def make_hazard(x1, y1, x2, y2, frame_width, frame_height,
                is_pothole=False, label="object"):
    width = max(0, x2 - x1)
    height = max(0, y2 - y1)
    return {
        "center_x": (x1 + x2) / 2,
        "box": (int(x1), int(y1), int(x2), int(y2)),
        "frame_width": frame_width,
        "bottom_ratio": max(0, min(1, y2 / max(1, frame_height))),
        "area_ratio": width * height / max(1, frame_width * frame_height),
        "is_pothole": is_pothole,
        "label": label,
    }


def hazard_priority(hazard):
    """Higher score means warn sooner; image cues are not a real distance estimate."""
    pothole = bool(hazard.get("is_pothole"))
    bottom = float(hazard.get("bottom_ratio", 0.0))
    area = float(hazard.get("area_ratio", 0.0))
    confidence = float(hazard.get("confidence", 0.0))
    proximity_bonus = {"near": 120, "approaching": 45}.get(hazard.get("proximity"), 0)
    # A low, large object is more immediately relevant in a forward-facing view.
    return proximity_bonus + (100 if pothole else 0) + 45 * bottom + 30 * area + 10 * confidence


def proximity_band(hazard):
    """Return a visual cue only. Monocular pixels cannot provide meters."""
    bottom = float(hazard.get("bottom_ratio", 0.0))
    area = float(hazard.get("area_ratio", 0.0))
    is_pothole = bool(hazard.get("is_pothole"))
    close_area = CLOSE_POTHOLE_AREA_RATIO if is_pothole else CLOSE_OBJECT_AREA_RATIO
    if bottom >= CLOSE_BOTTOM_RATIO and area >= close_area:
        return "near"
    if bottom >= APPROACH_BOTTOM_RATIO or area >= close_area * APPROACH_AREA_FACTOR:
        return "approaching"
    return "visible"


def side_of(hazard, frame_width):
    """'left', 'center' or 'right'. A wide object covering the walking lane is 'center'."""
    x1, _, x2, _ = hazard["box"]
    lane_left = frame_width * CENTER_LEFT_RATIO
    lane_right = frame_width * CENTER_RIGHT_RATIO
    inside = min(x2, lane_right) - max(x1, lane_left)
    if inside >= CENTER_OVERLAP_MIN * max(1, x2 - x1):
        return "center"
    return "left" if (x1 + x2) / 2 < frame_width / 2 else "right"


def aggregate_hazards(hazards, frame_width):
    """Add side, proximity and priority to every confirmed hazard (highest first)."""
    objects = []
    for hazard in hazards:
        item = dict(hazard)
        item["label"] = "pothole" if item.get("is_pothole") else str(item.get("label", "obstacle")).lower()
        item["side"] = side_of(item, frame_width) if frame_width > 0 else "center"
        item["proximity"] = proximity_band(item)
        item["priority"] = hazard_priority(item)
        objects.append(item)
    objects.sort(key=lambda item: item["priority"], reverse=True)
    return {"objects": objects, "alert_label": None}


def choose_guidance(state):
    """Pick the one thing to say. Only near/approaching objects alert.

    Returns (key, on-screen text). Key "far" = something is visible but still
    far, so nothing is spoken. Also records state["alert_label"], the object the
    spoken sentence must name.
    """
    seen = state.get("objects", [])
    close = [item for item in seen if item.get("proximity") in ALERT_PROXIMITY]
    if not close:
        if seen:
            return "far", "Object seen but still far - no alert"
        return "clear", "No supported obstacle detected; check with cane; route is not confirmed clear"

    lead = max(close, key=lambda item: item.get("priority", 0))
    side, label = lead["side"], lead["label"]
    state["alert_label"] = label
    cue = "Near" if lead["proximity"] == "near" else "Approaching"

    if side == "center":
        if label == "pothole" and lead["proximity"] == "near":
            return "pothole_ahead", "STOP - Close pothole ahead; cane-check"
        if label == "stairs":
            return "stairs_ahead", "STOP - Possible stairs ahead; confirm with cane/guide"
        return "front_blocked", f"STOP - {cue} {label.title()} ahead; cane-check both sides"
    opposite = "right" if side == "left" else "left"
    return f"obstacle_{side}", f"STOP - {cue} {label.title()} on {side}; cane-check {opposite}, move only if verified clear"


def side_alert_message(label, blocked_side):
    """Name the detected object and never imply the opposite side is clear."""
    object_name = MALAYALAM_NAMES.get(label, MALAYALAM_NAMES["obstacle"])
    blocked_ml, other_ml, move_ml = (
        ("ഇടത്", "വലത്", "വലത്തേക്ക്") if blocked_side == "left"
        else ("വലത്", "ഇടത്", "ഇടത്തേക്ക്")
    )
    uncertainty = " ഉണ്ടായേക്കാം" if label in {"person", "traffic light"} or label in {item for item, _ in OPEN_VOCAB_LABELS} else ""
    return (
        f"നിൽക്കൂ. {blocked_ml} വശത്ത് {object_name}{uncertainty}. "
        f"{other_ml} വശം ചൂരൽ കൊണ്ട് പരിശോധിക്കുക. "
        f"ചൂരൽ വഴി സുരക്ഷിതമാണെന്ന് ഉറപ്പാക്കിയാൽ മാത്രം {move_ml} നീങ്ങുക."
    )


def front_alert_message(label):
    """Warn by name in front; never pick a direction without cane confirmation."""
    object_name = MALAYALAM_NAMES.get(label, MALAYALAM_NAMES["obstacle"])
    uncertainty = " ഉണ്ടായേക്കാം" if label in {"person", "traffic light"} or label in {item for item, _ in OPEN_VOCAB_LABELS} else ""
    return (
        f"നിൽക്കൂ. മുന്നിൽ {object_name}{uncertainty}. ഇടത്തും വലത്തും ചൂരൽ കൊണ്ട് പരിശോധിക്കുക. "
        "ചൂരൽ വഴി സുരക്ഷിതമാണെന്ന് ഉറപ്പാക്കിയ വശത്തേക്ക് മാത്രം നീങ്ങുക."
    )


def all_named_alert_messages():
    labels = set(COCO_HAZARD_CLASSES) | {name for name, _ in OPEN_VOCAB_LABELS} | {"pothole", "obstacle"}
    return [
        *(side_alert_message(label, side) for label in sorted(labels) for side in ("left", "right")),
        *(front_alert_message(label) for label in sorted(labels)),
    ]


def make_spoken_message(state, key):
    """Choose a pre-generated Malayalam sentence that names the alerting object."""
    label = state.get("alert_label") or "obstacle"
    if key == "clear":
        return SAFE_CLEAR_TEXT
    if key == "obstacle_left":
        return side_alert_message(label, "left")
    if key == "obstacle_right":
        return side_alert_message(label, "right")
    if key == "front_blocked":
        return front_alert_message(label)
    if key == "stairs_ahead":
        return front_alert_message("stairs")
    if key == "pothole_ahead":
        return front_alert_message("pothole")
    return SAFE_CAUTION_TEXT


# If a named sentence is ever missing, play the matching short one (same direction).
FALLBACK_TEXT = {
    "obstacle_left": LEFT_TEXT, "obstacle_right": RIGHT_TEXT,
    "front_blocked": FRONT_BLOCKED_TEXT, "stairs_ahead": STAIRS_TEXT,
    "pothole_ahead": POTHOLE_TEXT,
}


def alert_priority(key):
    return {
        "safety_stop": 150, "pothole_ahead": 145, "stairs_ahead": 140,
        "front_blocked": 138, "stop": 125, "system_ready": 90, "user_command": 80,
        "obstacle_left": 75, "obstacle_right": 75, "pause": 70, "resume": 70,
        "clear": 10,
    }.get(key, 0)


def alert_direction(key):
    if key and key.endswith("_left"):
        return "left"
    if key and key.endswith("_right"):
        return "right"
    return None


def select_alert_during_playback(current, requested, audio_busy=True):
    """Do not cut routine audio; interrupt only for STOP or conflicting directions."""
    if not requested:
        return None
    if not audio_busy or not current:
        return requested
    if current == requested:
        return None

    old_direction = alert_direction(current)
    new_direction = alert_direction(requested)
    if old_direction and new_direction and old_direction != new_direction:
        return "stop"
    if alert_priority(requested) > alert_priority(current) and alert_priority(requested) > 0:
        return requested
    return None


def is_urgent_alert(key):
    return alert_priority(key) >= 120


def init_audio():
    global pygame_module, mixer_ready
    try:
        import pygame
        pygame.mixer.init()
        pygame_module = pygame
        mixer_ready = True
    except Exception as exc:
        print(f"Audio is required; Nethra Vazhi will not start: {exc}")
    return mixer_ready


def tts_cache_path(text):
    profile = f"{TTS_PROVIDER}|{EDGE_TTS_VOICE}|{TTS_LANGUAGE}"
    digest = sha256(f"{profile}\0{text}".encode("utf-8")).hexdigest()
    return TTS_CACHE_DIR / f"{digest}.mp3"


async def _stream_edge_audio(text):
    import edge_tts

    speech = edge_tts.Communicate(text, EDGE_TTS_VOICE)
    chunks = []
    async for chunk in speech.stream():
        if chunk.get("type") == "audio":
            chunks.append(chunk["data"])
    return b"".join(chunks)


def generate_edge_audio(text):
    """Use Microsoft's online Edge speech voice without an API key."""
    return asyncio.run(_stream_edge_audio(text))


def generate_gtts_audio(text):
    from io import BytesIO
    from gtts import gTTS

    buffer = BytesIO()
    gTTS(text=text, lang="ml", tld="co.in", lang_check=False,
         timeout=(4, 8)).write_to_fp(buffer)
    return buffer.getvalue()


def generate_tts_audio(text):
    """Try Edge TTS, then gTTS. Called only while preparing startup audio."""
    global edge_tts_error_reported
    if not edge_tts_error_reported:
        try:
            audio = generate_edge_audio(text)
            if audio:
                return audio
            raise RuntimeError("Edge TTS returned no audio")
        except Exception as exc:
            print(f"Edge TTS unavailable; switching to gTTS fallback: {exc}")
            edge_tts_error_reported = True
    audio = generate_gtts_audio(text)
    if not audio:
        raise RuntimeError("TTS provider returned empty audio")
    return audio


def write_tts_cache(text):
    TTS_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    output = tts_cache_path(text)
    if output.is_file():
        return output
    temporary = output.with_name(output.stem + ".tmp.mp3")
    temporary.write_bytes(generate_tts_audio(text))
    temporary.replace(output)
    return output


def warm_required_speech():
    """Prepare core warnings and named opposite-side alerts before monitoring."""
    messages = [
        STARTUP_TEXT, SAFETY_STOP_TEXT, SAFE_CAUTION_TEXT,
        POTHOLE_TEXT, STAIRS_TEXT, FRONT_BLOCKED_TEXT, LEFT_TEXT, RIGHT_TEXT,
        SAFE_CLEAR_TEXT, HELP_TEXT,
        PAUSE_TEXT, RESUME_TEXT,
    ]
    messages = tuple(dict.fromkeys(messages))
    total = len(messages)
    for index, text in enumerate(messages, start=1):
        try:
            print(f"Preparing safety voice {index}/{total}...", flush=True)
            write_tts_cache(text)
        except Exception as exc:
            print(f"Cannot prepare Malayalam safety speech; app will not start: {exc}")
            return False

    named_messages = all_named_alert_messages()
    total_named = len(named_messages)
    failed_named = 0
    for index, text in enumerate(named_messages, start=1):
        try:
            print(f"Preparing named object alert {index}/{total_named}...", flush=True)
            write_tts_cache(text)
        except Exception as exc:
            failed_named += 1
            print(f"Named alert {index}/{total_named} unavailable; generic safety voice will be used: {exc}", flush=True)
    print(f"Named object alerts ready: {total_named - failed_named}/{total_named}", flush=True)
    return True


def play_tts(key, text, path, explicit=False):
    """Play a cached warning; never start network TTS inside the camera loop."""
    global last_spoken_key, last_tts_text, last_tts_time
    if not mixer_ready or not path.is_file():
        return False
    try:
        busy = pygame_module.mixer.music.get_busy()
        selected = select_alert_during_playback(last_spoken_key, key, busy)
        if busy and key == last_spoken_key and text != last_tts_text:
            selected = key
        if selected == "stop" and key != "stop":
            path = tts_cache_path(SAFETY_STOP_TEXT)
            key, text = "safety_stop", SAFETY_STOP_TEXT
        elif selected is None or selected != key:
            return True

        now = time.monotonic()
        if not explicit and text == last_tts_text:
            cooldown = (URGENT_REPEAT_COOLDOWN_SECONDS if is_urgent_alert(key)
                        else CLEAR_REPEAT_COOLDOWN_SECONDS if key == "clear"
                        else REPEAT_ALERT_COOLDOWN_SECONDS)
            if now - last_tts_time < cooldown:
                return True
        elif not explicit and not is_urgent_alert(key) and now - last_tts_time < ALERT_COOLDOWN_SECONDS:
            return True

        pygame_module.mixer.music.stop()
        pygame_module.mixer.music.load(str(path))
        pygame_module.mixer.music.play()
        last_spoken_key, last_tts_text, last_tts_time = key, text, now
        return True
    except Exception as exc:
        print(f"Audio playback error: {exc}")
        return False


def speak_cached_safety_stop():
    path = tts_cache_path(SAFETY_STOP_TEXT)
    if path.is_file() and mixer_ready:
        play_tts("safety_stop", SAFETY_STOP_TEXT, path)


def speak_guidance(key, state):
    """Play a prepared warning for a confirmed scene; no runtime synthesis."""
    if not key or key == "far" or not mixer_ready:
        return
    if routine_speech_paused and not is_urgent_alert(key):
        return
    text = make_spoken_message(state, key)
    path = tts_cache_path(text)
    if not path.is_file():
        text = FALLBACK_TEXT.get(key, SAFE_CAUTION_TEXT)
        path = tts_cache_path(text)
    if path.is_file():
        play_tts(key, text, path)


def handle_control_key(code, current_key, current_state):
    global routine_speech_paused
    if code == ord("i") and current_key:
        speak_guidance(current_key, current_state)
    elif code == ord("h"):
        text = HELP_TEXT
        play_tts("user_command", text, tts_cache_path(text), explicit=True)
    elif code == ord("p"):
        routine_speech_paused = not routine_speech_paused
        key = "pause" if routine_speech_paused else "resume"
        text = PAUSE_TEXT if routine_speech_paused else RESUME_TEXT
        play_tts(key, text, tts_cache_path(text), explicit=True)


def shutdown_audio():
    global mixer_ready
    if mixer_ready and pygame_module:
        try:
            pygame_module.mixer.music.stop()
            pygame_module.mixer.quit()
        except Exception:
            pass
    mixer_ready = False


def draw_box(cv2, image, box, label, color):
    x1, y1, x2, y2 = box
    cv2.rectangle(image, (x1, y1), (x2, y2), color, 2)
    cv2.putText(image, label, (x1, max(18, y1 - 6)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)


def process_detections(frame, coco_result, pothole_result, coco_names, open_vocab_result=None):
    """Collect only high-confidence candidates; confirmation happens separately."""
    height, width = frame.shape[:2]
    hazards = []

    for box in getattr(coco_result, "boxes", []) or []:
        class_id = int(box.cls[0])
        name = get_class_name(coco_names, class_id).strip().lower()
        confidence = float(box.conf[0])
        if not is_reliable_coco_detection(name, confidence):
            continue
        coords = tuple(map(int, box.xyxy[0]))
        hazard = make_hazard(*coords, width, height, label=name)
        hazard["confidence"] = confidence
        hazards.append(hazard)

    for box in getattr(pothole_result, "boxes", []) or []:
        confidence = float(box.conf[0])
        if confidence < POTHOLE_CONFIDENCE:
            continue
        coords = tuple(map(int, box.xyxy[0]))
        hazard = make_hazard(*coords, width, height, True, "pothole")
        hazard["confidence"] = confidence
        hazards.append(hazard)

    for box in getattr(open_vocab_result, "boxes", []) or []:
        confidence = float(box.conf[0])
        if confidence < OPEN_VOCAB_MIN_CONFIDENCE:
            continue
        class_id = int(box.cls[0])
        if not 0 <= class_id < len(OPEN_VOCAB_LABELS):
            continue
        label = OPEN_VOCAB_LABELS[class_id][0]
        coords = tuple(map(int, box.xyxy[0]))
        hazard = make_hazard(*coords, width, height, label=label)
        hazard["confidence"] = confidence
        hazard["open_vocab"] = True
        hazards.append(hazard)

    return hazards


def draw_detections(frame, hazards, cv2):
    """Show pending boxes as yellow; confirmed boxes as green."""
    image = frame.copy()
    for hazard in hazards:
        confirmed = hazard.get("confirmed", False)
        label = hazard["label"]
        if label == "person":
            label = "possible person?"
        elif hazard.get("open_vocab"):
            label = f"possible {label}?"
        state = "confirmed" if confirmed else f"checking {hazard.get('frames_seen', 1)}"
        color = (0, 200, 0) if confirmed else (0, 220, 255)
        draw_box(cv2, image, hazard["box"],
                 f"{label} {hazard.get('confidence', 0):.2f} {state}", color)
    return image


def run():
    try:
        import cv2
        from ultralytics import YOLO
    except ImportError as exc:
        print(f"Required package unavailable: {exc}")
        return 2

    if not init_audio():
        return 2
    camera = None
    try:
        camera = cv2.VideoCapture(CAMERA_INDEX)
        camera.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        if not camera.isOpened():
            raise RuntimeError(f"Could not open camera {CAMERA_INDEX}")
        loading = __import__("numpy").zeros((FRAME_SIZE[1], FRAME_SIZE[0], 3), dtype="uint8")
        cv2.putText(loading, "Starting Nethra Vazhi...", (18, 42),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)
        cv2.putText(loading, "Preparing safety audio and models", (18, 78),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.48, (0, 220, 255), 1)
        cv2.imshow("Nethra Vazhi", loading)
        cv2.waitKey(1)

        if not warm_required_speech():
            return 2
        for model_path in (POTHOLE_MODEL_PATH, COCO_MODEL_PATH):
            if not model_path.is_file():
                raise FileNotFoundError(f"Model not found: {model_path}")

        coco_model = YOLO(str(COCO_MODEL_PATH))
        pothole_model = YOLO(str(POTHOLE_MODEL_PATH))
        open_vocab_model = None
        if ENABLE_OPEN_VOCAB:
            try:
                from ultralytics import YOLOWorld
                open_vocab_model = YOLOWorld(OPEN_VOCAB_MODEL)
                open_vocab_model.set_classes(OPEN_VOCAB_PROMPTS)
                print("Open-vocabulary hazards enabled:", ", ".join(label for label, _ in OPEN_VOCAB_LABELS))
            except Exception as exc:
                print(f"Open-vocabulary model unavailable; stairs and custom prompts are off: {exc}")
        play_tts("system_ready", STARTUP_TEXT, tts_cache_path(STARTUP_TEXT), explicit=True)
        previous_tracks = []
        frame_count = 0
        inference_cycle = 0
        last_processed = time.monotonic()
        current_key = None
        current_state = aggregate_hazards([], FRAME_SIZE[0])
        guidance = "Starting detection..."
        shown_frame = None
        print("Controls: i=repeat alert, h=help, p=pause/resume routine speech, q=quit")
        print("Person and prompt-hazard alerts require higher confidence and 3 matching frames; movement is never directed by this camera.")

        while True:
            ok, frame = camera.read()
            if not ok or frame is None:
                raise RuntimeError("Camera frame read failed")
            frame = cv2.resize(frame, FRAME_SIZE)
            if MIRROR_CAMERA:
                frame = cv2.flip(frame, 1)
            frame_count += 1

            if frame_count % PROCESS_EVERY_N_FRAMES == 0:
                try:
                    inference_cycle += 1
                    coco = coco_model(frame, conf=COCO_MODEL_CONFIDENCE,
                                      imgsz=INFERENCE_SIZE, max_det=30, verbose=False)[0]
                    pothole = pothole_model(frame, conf=POTHOLE_CONFIDENCE,
                                            imgsz=INFERENCE_SIZE, max_det=20, verbose=False)[0]
                    open_vocab = None
                    if (open_vocab_model is not None and
                            inference_cycle % OPEN_VOCAB_EVERY_N_CYCLES == 0):
                        try:
                            open_vocab = open_vocab_model(
                                frame, conf=OPEN_VOCAB_MIN_CONFIDENCE,
                                imgsz=INFERENCE_SIZE, max_det=20, verbose=False
                            )[0]
                        except Exception as exc:
                            print(f"Open-vocabulary inference failed; disabling it: {exc}")
                            open_vocab_model = None
                    candidates = process_detections(
                        frame, coco, pothole, coco_model.names, open_vocab
                    )
                    confirmed, previous_tracks = confirm_detections(candidates, previous_tracks)
                    confirmed_ids = {id(item) for item in confirmed}
                    for candidate in candidates:
                        candidate["confirmed"] = id(candidate) in confirmed_ids
                    hazard_state = aggregate_hazards(confirmed, frame.shape[1])
                    current_key, guidance = choose_guidance(hazard_state)
                    current_state = hazard_state
                    shown_frame = draw_detections(frame, candidates, cv2)
                    speak_guidance(current_key, current_state)
                    last_processed = time.monotonic()
                except Exception as exc:
                    guidance = "STOP - Detection error; wait and check safely"
                    shown_frame = frame.copy()
                    cv2.putText(shown_frame, str(exc)[:70], (10, 58),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 255), 1)
                    speak_cached_safety_stop()
                    previous_tracks = []
                    print(f"Detection error: {exc}")

            if time.monotonic() - last_processed > 1.5:
                guidance = "STOP - Detection delayed; wait and check safely"
                speak_cached_safety_stop()
            display = shown_frame.copy() if shown_frame is not None else frame.copy()
            cv2.putText(display, guidance, (10, 28), cv2.FONT_HERSHEY_SIMPLEX,
                        0.55, (255, 255, 255), 2)
            cv2.putText(display, f"Confirmed objects: {len(current_state.get('objects', []))}",
                        (10, 54), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (255, 255, 0), 1)
            cv2.imshow("Nethra Vazhi", display)
            pressed = cv2.waitKey(1) & 0xFF
            if pressed == ord("q"):
                break
            handle_control_key(pressed, current_key, current_state)

    except Exception as exc:
        print(f"Nethra Vazhi stopped safely: {exc}")
        speak_cached_safety_stop()
        return 1
    finally:
        if camera is not None:
            camera.release()
        try:
            cv2.destroyAllWindows()
        except Exception:
            pass
        shutdown_audio()
    return 0


if __name__ == "__main__":
    raise SystemExit(run())