"""Nethra Vazhi website server.

Run:  python server.py            -> opens http://localhost:8000
      python server.py --https    -> https://<this-pc-ip>:8000 (for a phone on the same Wi-Fi)

On start it:
  1. downloads every Malayalam voice the site can speak (cached in .nethra_tts_cache),
  2. loads the detection models (same models and rules as nethracam.py),
  3. serves the camera page from ./web on port 8000.

Detection rules come from nethracam.py and walking routes from osmmap.py, so the
website behaves the same as the desktop/mobile app.
"""
import argparse
import json
import math
import os
import shutil
import socket
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
WEB_DIR = APP_DIR / "web"
os.chdir(APP_DIR)                      # YOLO downloads its model files next to this script
sys.path.insert(0, str(APP_DIR))

import nethracam as cam                # noqa: E402  detection + speech rules
import osmmap as nav                   # noqa: E402  OSM walking route helpers

PORT = 8000

# osmmap.py asks ORS for ".../foot-walking/json", which answers in the "routes"
# format (encoded polyline) that osmmap.parse_ors_route cannot read, so every route
# failed. The "/geojson" endpoint returns exactly the "features" format it expects
# (verified against the live ORS API).
nav.ORS_URL = "https://api.openrouteservice.org/v2/directions/foot-walking/geojson"

# Accuracy settings (the website uses a larger model and bigger frames than the
# original 416 px nano setup). Override with environment variables if a PC is slow:
#   set NETHRA_COCO_MODEL=yolo26n.pt   set NETHRA_IMGSZ=416
COCO_MODEL_NAME = os.getenv("NETHRA_COCO_MODEL", "yolo26s.pt").strip()
INFERENCE_SIZE = int(os.getenv("NETHRA_IMGSZ", "640"))
FRAME_SIZE = (640, 480)            # browser sends 640x480; all rules use ratios
DUPLICATE_IOU = 0.60               # same object reported twice (two models / two classes)
MAX_OBJECTS_SPOKEN = 3

# Spoken alerts are short clips played back to back:
#   approaching ->  "Caution."  + "in front: car."                      (no "stop")
#   too close   ->  "Stop."     + "in front: car."  + "check with cane"
STOP_WORD_TEXT = "നിൽക്കൂ."
CAUTION_WORD_TEXT = "ശ്രദ്ധിക്കുക."
CANE_CHECK_TEXT = "ചൂരൽ കൊണ്ട് പരിശോധിക്കുക."
MULTI_CAUTION_TEXT = "ശ്രദ്ധിക്കുക. ഒന്നിലധികം വസ്തുക്കൾ."

# Detection thresholds for the website (nethracam.py keeps its own values for the desktop app).
# Balanced between "misses real objects" (old person 0.78) and "false alarms indoors"
# (too low). Every value can be changed without editing code, e.g.
#   NETHRA_POTHOLE_CONF=0.85 python server.py
def _env_float(name, default):
    try:
        return float(os.getenv(name, default))
    except ValueError:
        return float(default)


cam.PERSON_CONFIDENCE = _env_float("NETHRA_PERSON_CONF", 0.65)
cam.COCO_CONFIDENCE = _env_float("NETHRA_OBJECT_CONF", 0.55)
cam.POTHOLE_CONFIDENCE = _env_float("NETHRA_POTHOLE_CONF", 0.75)
# YOLO-World reports LOWER scores than the other models (a good stairs detection is often
# 0.3-0.4), so its floor is low and every class then needs its own minimum below.
cam.OPEN_VOCAB_MIN_CONFIDENCE = _env_float("NETHRA_OPEN_VOCAB_FLOOR", 0.25)
OPEN_VOCAB_DEFAULT_MIN = _env_float("NETHRA_OPEN_VOCAB_CONF", 0.35)

# Walls, doorways and glass doors are everywhere indoors, so they need higher confidence.
OPEN_VOCAB_LABEL_MIN = {"wall": 0.55, "doorway": 0.55, "glass door": 0.55, "pole": 0.45}

# Household items that are not walking hazards. They caused "several obstacles, stop" at a
# desk. Set NETHRA_IGNORE="" to detect everything again, or list your own classes.
_DEFAULT_IGNORED = "laptop,tv,vase,sink,toilet,oven,refrigerator,sports ball,handbag,backpack,umbrella,dining table"
IGNORED_LABELS = {x.strip().lower() for x in os.getenv("NETHRA_IGNORE", _DEFAULT_IGNORED).split(",") if x.strip()}
DEVICE_OVERRIDE = os.getenv("NETHRA_DEVICE", "").strip()      # e.g. mps (Apple chip), cpu, 0 (NVIDIA)

# ---------------------------------------------------------------- voices
# Extra Malayalam prompts used only by the website (mode switch, navigation).
NAV_MODE_TEXT = "നാവിഗേഷൻ മോഡ് തുടങ്ങി."
ASK_DEST_TEXT = "ലക്ഷ്യസ്ഥാനം പറയുക."
DEST_RETRY_TEXT = "ലക്ഷ്യസ്ഥാനം മനസ്സിലായില്ല. വീണ്ടും പറയുക."
PLACE_NOT_FOUND_TEXT = "സ്ഥലം കണ്ടെത്താനായില്ല. വീണ്ടും പറയുക."
DEST_FAIL_TEXT = "ലക്ഷ്യസ്ഥാനം ലഭിച്ചില്ല. തടസ്സം കണ്ടെത്തൽ മാത്രം തുടരുന്നു."
DEST_OK_TEXT = "ലക്ഷ്യസ്ഥാനം ലഭിച്ചു. വഴി തേടുന്നു."
GPS_WAIT_TEXT = "ജിപിഎസ് സിഗ്നലിനായി കാത്തിരിക്കുന്നു."
GPS_POOR_TEXT = "ജിപിഎസ് കൃത്യത കുറവാണ്. അൽപ്പം കാത്തിരിക്കുക."
ROUTE_READY_TEXT = "വഴി തയ്യാറായി. നിർദ്ദേശങ്ങൾ ശ്രദ്ധിക്കുക."
DETECT_ON_TEXT = "തടസ്സം കണ്ടെത്തൽ തുടങ്ങി."
ROUTE_ERROR_TEXT = "വഴി ലഭ്യമല്ല. തടസ്സം കണ്ടെത്തൽ തുടരുന്നു."
OFF_ROUTE_TEXT = "വഴിയിൽ നിന്ന് മാറിയിരിക്കാം. നിൽക്കുക. പുതിയ വഴി തേടുന്നു."
DETECT_MODE_TEXT = "നാവിഗേഷൻ നിർത്തി. തടസ്സം കണ്ടെത്തൽ മാത്രം."
CAMERA_ERROR_TEXT = "ക്യാമറ തുറക്കാനായില്ല. ക്യാമറ അനുമതി പരിശോധിക്കുക."

NAMED_TEXTS = {
    "startup": cam.STARTUP_TEXT,
    "safety_stop": cam.SAFETY_STOP_TEXT,
    "nav_mode": NAV_MODE_TEXT,
    "ask_dest": ASK_DEST_TEXT,
    "dest_retry": DEST_RETRY_TEXT,
    "place_not_found": PLACE_NOT_FOUND_TEXT,
    "dest_fail": DEST_FAIL_TEXT,
    "dest_ok": DEST_OK_TEXT,
    "gps_wait": GPS_WAIT_TEXT,
    "gps_poor": GPS_POOR_TEXT,
    "route_ready": ROUTE_READY_TEXT,
    "detect_on": DETECT_ON_TEXT,
    "route_error": ROUTE_ERROR_TEXT,
    "off_route": OFF_ROUTE_TEXT,
    "detect_mode": DETECT_MODE_TEXT,
    "camera_error": CAMERA_ERROR_TEXT,
}

# Multiple close objects are spoken as short clips played back to back:
#   "നിൽക്കൂ." + "മുന്നിൽ കാർ." + "ഇടത് വശത്ത് ആൾ ഉണ്ടായേക്കാം." + closing advice
MULTI_START_TEXT = "നിൽക്കൂ. ഒന്നിലധികം തടസ്സങ്ങൾ."
MULTI_CLOSE_TEXT = {
    "center": "മുന്നോട്ട് പോകരുത്. ഇടത്തും വലത്തും ചൂരൽ കൊണ്ട് പരിശോധിക്കുക.",
    "both": "ഇടത്തും വലത്തും തടസ്സങ്ങൾ. മുന്നോട്ട് പോകരുത്. ചൂരൽ ഉപയോഗിച്ച് പരിശോധിക്കുക.",
    "left": "വലത് വശം ചൂരൽ കൊണ്ട് പരിശോധിക്കുക. സുരക്ഷിതമെന്ന് ഉറപ്പായാൽ മാത്രം വലത്തേക്ക് നീങ്ങുക.",
    "right": "ഇടത് വശം ചൂരൽ കൊണ്ട് പരിശോധിക്കുക. സുരക്ഷിതമെന്ന് ഉറപ്പായാൽ മാത്രം ഇടത്തേക്ക് നീങ്ങുക.",
}
SIDE_WORDS = {"center": "മുന്നിൽ", "left": "ഇടത് വശത്ത്", "right": "വലത് വശത്ത്"}
UNCERTAIN_LABELS = {"person", "traffic light"} | {label for label, _ in cam.OPEN_VOCAB_LABELS}


def all_labels():
    return sorted(set(cam.COCO_HAZARD_CLASSES) | {n for n, _ in cam.OPEN_VOCAB_LABELS} | {"pothole", "obstacle"})


def object_clip_text(label, side):
    name = cam.MALAYALAM_NAMES.get(label, cam.MALAYALAM_NAMES["obstacle"])
    maybe = " ഉണ്ടായേക്കാം" if label in UNCERTAIN_LABELS else ""
    return f"{SIDE_WORDS[side]} {name}{maybe}."


def all_multi_texts():
    clips = [object_clip_text(label, side) for label in all_labels() for side in SIDE_WORDS]
    return [MULTI_START_TEXT, MULTI_CAUTION_TEXT, *MULTI_CLOSE_TEXT.values(), *clips]


# Every possible route sentence: osmmap.instruction_malayalam() only has these
# branches, and the "N metres later" prefix is rounded to 10/20/30/40 m.
ROUTE_SAMPLES = [
    "arrive", "make a u-turn", "turn sharp left", "turn sharp right",
    "turn slight left", "turn slight right", "turn left", "turn right",
    "head north", "head south", "head east", "head west", "continue straight", "?",
]
ROUTE_PREFIX_METERS = (0, 10, 20, 30, 40)


def route_distance_bucket(meters):
    if not meters or meters < 10:
        return 0
    return int(max(10, min(40, round(meters / 10) * 10)))


def all_route_texts():
    return [nav.instruction_malayalam(s, d) for s in ROUTE_SAMPLES for d in ROUTE_PREFIX_METERS]


def all_voice_texts():
    core = [
        cam.STARTUP_TEXT, cam.SAFETY_STOP_TEXT, cam.SAFE_CAUTION_TEXT, cam.POTHOLE_TEXT,
        cam.STAIRS_TEXT, cam.FRONT_BLOCKED_TEXT, cam.LEFT_TEXT, cam.RIGHT_TEXT,
        cam.SAFE_CLEAR_TEXT, cam.HELP_TEXT, cam.PAUSE_TEXT, cam.RESUME_TEXT,
        *NAMED_TEXTS.values(),
    ]
    core += [MULTI_START_TEXT, *MULTI_CLOSE_TEXT.values(),
             STOP_WORD_TEXT, CAUTION_WORD_TEXT, CANE_CHECK_TEXT, MULTI_CAUTION_TEXT]
    texts = core + all_multi_texts() + all_route_texts()
    return list(dict.fromkeys(texts)), set(core)


def voice_id(text):
    path = cam.tts_cache_path(text)
    return path.name if path.is_file() else None


def download_all_voices():
    """Generate every sentence once (Edge TTS, gTTS fallback). Cached on disk."""
    texts, core = all_voice_texts()
    missing = [t for t in texts if not cam.tts_cache_path(t).is_file()]
    print(f"Voices: {len(texts) - len(missing)}/{len(texts)} already downloaded.", flush=True)
    failed_core = []
    if missing:
        done = 0
        lock = threading.Lock()

        def job(text):
            nonlocal done
            try:
                cam.write_tts_cache(text)
                ok = True
            except Exception as exc:   # report and keep going
                ok = False
                print(f"  voice failed: {exc}", flush=True)
            with lock:
                done += 1
                print(f"  downloading voice {done}/{len(missing)}", end="\r", flush=True)
            return text, ok

        with ThreadPoolExecutor(max_workers=6) as pool:
            for text, ok in pool.map(job, missing):
                if not ok and text in core:
                    failed_core.append(text)
        print()
    ready = sum(cam.tts_cache_path(t).is_file() for t in texts)
    print(f"Voices ready: {ready}/{len(texts)}", flush=True)
    if failed_core:
        print("ERROR: core safety voices could not be downloaded. Check the internet "
              "connection and start again.", flush=True)
        return False
    return True


# ---------------------------------------------------------------- detection
def _inside_fraction(inner, outer):
    """Share of the `inner` box that lies inside the `outer` box (0..1)."""
    ix1, iy1 = max(inner[0], outer[0]), max(inner[1], outer[1])
    ix2, iy2 = min(inner[2], outer[2]), min(inner[3], outer[3])
    area = max(1, (inner[2] - inner[0]) * (inner[3] - inner[1]))
    return max(0, ix2 - ix1) * max(0, iy2 - iy1) / area


def filter_candidates(hazards, width, height):
    """Drop detections that are very probably wrong, before they are tracked.

    * household items that are not walking hazards,
    * indoor-looking open-vocabulary classes below their own (higher) confidence,
    * potholes that are not where a pothole can be: on the ground (lower half of the
      picture), a plausible size and shape, and not part of a person/chair/car.
    """
    objects = [h for h in hazards if not h.get("is_pothole") and not h.get("open_vocab")
               and h.get("confidence", 0) >= 0.5]
    kept = []
    for h in hazards:
        label = h["label"]
        if h.get("is_pothole"):
            x1, y1, x2, y2 = h["box"]
            box_w, box_h = max(1, x2 - x1), max(1, y2 - y1)
            on_ground = (y1 + y2) / 2 >= 0.50 * height and y2 >= 0.55 * height
            sensible = 0.004 <= h["area_ratio"] <= 0.40 and 0.5 <= box_w / box_h <= 7.0
            inside_object = any(_inside_fraction(h["box"], o["box"]) >= 0.5 for o in objects)
            if on_ground and sensible and not inside_object:
                kept.append(h)
            continue
        if label in IGNORED_LABELS:
            continue
        if h.get("open_vocab") and h.get("confidence", 0) < OPEN_VOCAB_LABEL_MIN.get(label, OPEN_VOCAB_DEFAULT_MIN):
            continue
        kept.append(h)
    return kept


def remove_duplicates(hazards):
    """One physical object -> one hazard. Keeps the most confident box when two
    boxes overlap heavily (e.g. COCO 'person' and open-vocab 'pole', or chair/couch).
    A pothole is never merged with a standing object."""
    kept = []
    for hazard in sorted(hazards, key=lambda h: (not h.get("open_vocab"), h.get("confidence", 0)), reverse=True):
        duplicate = any(
            bool(hazard.get("is_pothole")) == bool(other.get("is_pothole"))
            and cam.box_iou(hazard["box"], other["box"]) >= DUPLICATE_IOU
            for other in kept
        )
        if not duplicate:
            kept.append(hazard)
    return kept


SIDE_KEY = {"center": "front", "left": "left", "right": "right"}


def alert_voices(label, side, near):
    """Short clips for one object: stop + name + cane when it is too close,
    caution + place when it is only approaching. None if a clip is missing."""
    clip = object_clip_text(label, side)
    texts = [STOP_WORD_TEXT, clip, CANE_CHECK_TEXT] if near else [CAUTION_WORD_TEXT, clip]
    voices = [voice_id(t) for t in texts]
    return None if any(v is None for v in voices) else voices


def single_alert(state, key, guidance):
    """(key, guidance, voices) for the lead object, or None to use the old sentences."""
    close = [o for o in state.get("objects", []) if o.get("proximity") in cam.ALERT_PROXIMITY]
    if not close:
        return None
    lead = max(close, key=lambda o: o.get("priority", 0))
    near = lead["proximity"] == "near"
    voices = alert_voices(lead["label"], lead["side"], near)
    if voices is None:
        return None
    if near:
        return key, guidance, voices
    where = "ahead" if lead["side"] == "center" else f"on the {lead['side']}"
    return (f"caution_{SIDE_KEY[lead['side']]}",
            f"CAUTION - {lead['label'].title()} approaching {where}", voices)


def multi_object_alert(state):
    """If two or more different close objects are confirmed, describe them all.

    Returns (key, guidance, [voice ids]) or None when the single-object message fits.
    """
    close = [o for o in state.get("objects", []) if o.get("proximity") in cam.ALERT_PROXIMITY]
    unique = {}
    for obj in sorted(close, key=lambda o: o.get("priority", 0), reverse=True):
        unique.setdefault((obj["label"], obj["side"]), obj)
    if len(unique) < 2:
        return None
    order = {"center": 0, "left": 1, "right": 2}
    ranked = sorted(unique.values(), key=lambda o: -o.get("priority", 0))
    # Cover every blocked side first (front, left, right), then add the next most
    # urgent objects until MAX_OBJECTS_SPOKEN.
    chosen = []
    for side in order:
        lead = next((o for o in ranked if o["side"] == side), None)
        if lead:
            chosen.append(lead)
    chosen += [o for o in ranked if o not in chosen]
    chosen = sorted(chosen[:MAX_OBJECTS_SPOKEN], key=lambda o: (order[o["side"]], -o.get("priority", 0)))
    sides = {o["side"] for o in unique.values()}
    if not any(o["proximity"] == "near" for o in unique.values()):
        # everything is only approaching: caution, name each object and where it is, no "stop"
        key = ("caution_front" if "center" in sides else "caution_both" if {"left", "right"} <= sides
               else f"caution_{next(iter(sides))}")
        texts = [MULTI_CAUTION_TEXT, *(object_clip_text(o["label"], o["side"]) for o in chosen)]
        voices = [voice_id(t) for t in texts]
        if any(v is None for v in voices):
            return None
        return key, "CAUTION - " + ", ".join(f"{o['label']} {o['side']}" for o in chosen), voices
    if "center" in sides:
        pothole_near = any(o["label"] == "pothole" and o["side"] == "center" and o["proximity"] == "near"
                           for o in unique.values())
        key, closing = ("pothole_ahead" if pothole_near else "front_blocked"), "center"
    elif {"left", "right"} <= sides:
        key, closing = "both_sides", "both"
    else:
        side = sides.pop()
        key, closing = f"obstacle_{side}", side
    texts = [MULTI_START_TEXT, *(object_clip_text(o["label"], o["side"]) for o in chosen),
             MULTI_CLOSE_TEXT[closing]]
    voices = [voice_id(t) for t in texts]
    if any(v is None for v in voices):
        return None
    guidance = "STOP - " + ", ".join(f"{o['label']} {o['side']}" for o in chosen)
    return key, guidance, voices


class Detector:
    def __init__(self):
        from ultralytics import YOLO
        import torch
        pothole = cam.POTHOLE_MODEL_PATH
        if not pothole.is_file():
            pothole = APP_DIR / "best.pt"
        if not pothole.is_file():
            raise FileNotFoundError("Pothole model best.pt not found next to server.py")
        self.device = DEVICE_OVERRIDE or (0 if torch.cuda.is_available() else "cpu")
        if isinstance(self.device, str) and self.device.isdigit():
            self.device = int(self.device)
        self.half = self.device == 0
        print(f"Loading detection models ({COCO_MODEL_NAME}, {INFERENCE_SIZE}px, "
              f"{'GPU' if self.half else self.device})...", flush=True)
        self.coco = YOLO(COCO_MODEL_NAME)           # downloads on first run
        self.pothole = YOLO(str(pothole))
        self.open_vocab = None
        self.open_vocab_error = None if cam.ENABLE_OPEN_VOCAB else "switched off (NETHRA_ENABLE_OPEN_VOCAB=0)"
        if cam.ENABLE_OPEN_VOCAB:
            try:
                from ultralytics import YOLOWorld
                world = YOLOWorld(cam.OPEN_VOCAB_MODEL)
                world.set_classes(cam.OPEN_VOCAB_PROMPTS)
                # Assign only after set_classes works: a model left with its default
                # classes would report wrong labels (e.g. "stairs" for a person).
                self.open_vocab = world
                print("Open-vocabulary hazards on:",
                      ", ".join(label for label, _ in cam.OPEN_VOCAB_LABELS), flush=True)
            except Exception as exc:
                self.open_vocab_error = str(exc)
                print(f"Open-vocabulary model unavailable (stairs/curb/pole off): {exc}", flush=True)
        self.lock = threading.Lock()
        self.tracks = []
        self.cycle = 0
        import numpy as np
        self.np = np
        blank = np.zeros((FRAME_SIZE[1], FRAME_SIZE[0], 3), dtype="uint8")
        self.run_models(blank)                      # warm-up so the first frame is fast
        self.run_models(blank)
        self.status = self.self_test(blank)

    def self_test(self, blank):
        """Run each model once and print clearly whether it works."""
        opts = dict(imgsz=INFERENCE_SIZE, device=self.device, verbose=False)
        if self.half:
            opts["half"] = True
        status = {}

        def check(name, label, model, conf, **extra):
            try:
                started = time.perf_counter()
                model(blank, conf=conf, max_det=5, **opts, **extra)
                ms = round((time.perf_counter() - started) * 1000)
                status[name] = {"ok": True, "ms": ms, "model": label}
                print(f"  {name:<11} OK    {label:<22} {ms} ms", flush=True)
            except Exception as exc:
                status[name] = {"ok": False, "error": str(exc), "model": label}
                print(f"  {name:<11} FAILED {label}: {exc}", flush=True)

        print("Model check:", flush=True)
        check("objects", COCO_MODEL_NAME, self.coco, cam.COCO_MODEL_CONFIDENCE)
        check("pothole", Path(cam.POTHOLE_MODEL_PATH).name or "best.pt", self.pothole, cam.POTHOLE_CONFIDENCE)
        if self.open_vocab is not None:
            check("YOLO-World", cam.OPEN_VOCAB_MODEL, self.open_vocab, cam.OPEN_VOCAB_MIN_CONFIDENCE)
            if status["YOLO-World"]["ok"]:
                status["YOLO-World"]["classes"] = [label for label, _ in cam.OPEN_VOCAB_LABELS]
        else:
            status["YOLO-World"] = {"ok": False, "error": self.open_vocab_error or "not loaded"}
            print(f"  YOLO-World  OFF   {self.open_vocab_error}", flush=True)
            print('              fix: pip install "git+https://github.com/ultralytics/CLIP.git"  then restart',
                  flush=True)
        return status

    def run_models(self, frame):
        opts = dict(imgsz=INFERENCE_SIZE, device=self.device, verbose=False)
        if self.half:                      # GPU: half precision is faster
            opts["half"] = True
        coco = self.coco(frame, conf=cam.COCO_MODEL_CONFIDENCE, max_det=30, **opts)[0]
        pothole = self.pothole(frame, conf=cam.POTHOLE_CONFIDENCE, max_det=20, **opts)[0]
        open_vocab = None
        if self.open_vocab is not None and self.cycle % cam.OPEN_VOCAB_EVERY_N_CYCLES == 0:
            try:
                open_vocab = self.open_vocab(frame, conf=cam.OPEN_VOCAB_MIN_CONFIDENCE, max_det=20, **opts)[0]
            except Exception as exc:
                print(f"Open-vocabulary inference failed; disabling it: {exc}", flush=True)
                self.open_vocab = None
        return coco, pothole, open_vocab

    def detect(self, jpeg_bytes):
        import cv2
        started = time.perf_counter()
        frame = cv2.imdecode(self.np.frombuffer(jpeg_bytes, self.np.uint8), cv2.IMREAD_COLOR)
        if frame is None:
            raise ValueError("Bad camera frame")
        height, width = frame.shape[:2]
        scale = max(FRAME_SIZE) / max(height, width)
        if scale < 1:                                # shrink only; stretching a frame hurts accuracy
            frame = cv2.resize(frame, (round(width * scale), round(height * scale)),
                               interpolation=cv2.INTER_AREA)
        with self.lock:
            self.cycle += 1
            coco, pothole, open_vocab = self.run_models(frame)
            candidates = cam.process_detections(frame, coco, pothole, self.coco.names, open_vocab)
            candidates = remove_duplicates(filter_candidates(candidates, frame.shape[1], frame.shape[0]))
            confirmed, self.tracks = cam.confirm_detections(candidates, self.tracks)
            state = cam.aggregate_hazards(confirmed, frame.shape[1])
            key, guidance = cam.choose_guidance(state)
            multi = multi_object_alert(state)
            self.log_alert(confirmed, frame.shape[1])

        voices = None
        if multi:
            key, guidance, voices = multi
        elif key and key not in ("far", "clear") and single_alert(state, key, guidance):
            key, guidance, voices = single_alert(state, key, guidance)
        elif key and key != "far":
            text = cam.make_spoken_message(state, key)
            if not cam.tts_cache_path(text).is_file():
                text = cam.FALLBACK_TEXT.get(key, cam.SAFE_CAUTION_TEXT)
            voice = voice_id(text)
            voices = [voice] if voice else None
        confirmed_ids = {id(c) for c in confirmed}
        return {
            "key": key,
            "guidance": guidance,
            "voice": voices,
            "objects": [
                {"label": c["label"], "box": c["box"], "confidence": round(c.get("confidence", 0), 2),
                 "confirmed": id(c) in confirmed_ids,
                 "side": cam.side_of(c, frame.shape[1]), "proximity": cam.proximity_band(c)}
                for c in candidates
            ],
            "frame": [frame.shape[1], frame.shape[0]],
            "ms": round((time.perf_counter() - started) * 1000),
        }

    def log_alert(self, confirmed, width):
        """Print what is making the voice speak (only when it changes) so false alarms
        can be traced to a class and a confidence."""
        loud = sorted(
            (c["label"], cam.side_of(c, width), cam.proximity_band(c), round(c.get("confidence", 0), 2))
            for c in confirmed if cam.proximity_band(c) in cam.ALERT_PROXIMITY)
        signature = tuple((a, b, c) for a, b, c, _ in loud)
        if signature != getattr(self, "last_signature", None):
            self.last_signature = signature
            if loud:
                print("[alert] " + "; ".join(f"{a} {b} {c} conf {d}" for a, b, c, d in loud), flush=True)
            else:
                print("[alert] none", flush=True)

    def reset(self):
        with self.lock:
            self.tracks = []

# ---------------------------------------------------------------- navigation
OFF_ROUTE_METERS = 45.0


def distance_to_route_m(geometry, lat, lon, around_index):
    """Distance from the walker to the route LINE (not just its corner points).

    osmmap measured to the nearest vertex, so on a long straight stretch (vertices
    100-150 m apart) a walker exactly on the road was reported off-route.
    """
    low = max(0, around_index - 3)
    high = min(len(geometry) - 1, around_index + 80)
    if high <= low:
        return nav._haversine_m((lat, lon), geometry[low])
    k = math.cos(math.radians(lat)) * 111_320.0     # metres per degree longitude
    best = float("inf")
    for i in range(low, high):
        (a_lat, a_lon), (b_lat, b_lon) = geometry[i], geometry[i + 1]
        ax, ay = (a_lon - lon) * k, (a_lat - lat) * 110_540.0
        bx, by = (b_lon - lon) * k, (b_lat - lat) * 110_540.0
        dx, dy = bx - ax, by - ay
        seg = dx * dx + dy * dy
        t = 0.0 if seg == 0 else max(0.0, min(1.0, -(ax * dx + ay * dy) / seg))
        best = min(best, math.hypot(ax + t * dx, ay + t * dy))
    return best

class Navigator:
    """Same logic as osmmap.start_navigation's worker, driven by browser GPS."""

    def __init__(self):
        self.lock = threading.Lock()
        self.stop()

    def stop(self):
        self.destination = None
        self.label = None
        self.route = None
        self.step_index = 0
        self.geometry_index = 0
        self.off_route_hits = 0
        self.last_route_try = 0.0
        self.status = "idle"

    def geocode(self, query, near=None):
        coord = nav.parse_coordinate(query)
        if coord:
            return {"label": query.strip(), "coordinate": coord}
        base = {"text": query, "size": 5}
        if near:
            base["focus.point.lat"], base["focus.point.lon"] = near
        features = []
        # India first (avoids "Kochi, Japan"), then anywhere.
        for extra in ({"boundary.country": "IN"}, {}):
            url = nav.ORS_GEOCODE_URL + "?" + urllib.parse.urlencode({**base, **extra})
            req = urllib.request.Request(url, headers={"Authorization": nav.ORS_API_KEY})
            with urllib.request.urlopen(req, timeout=nav.REQUEST_TIMEOUT_SECONDS) as resp:
                features = json.load(resp).get("features", [])
            if features:
                break
        for feature in features:
            coords = feature.get("geometry", {}).get("coordinates", [])
            if len(coords) >= 2:
                props = feature.get("properties", {})
                return {"label": props.get("label") or props.get("name") or query,
                        "coordinate": (float(coords[1]), float(coords[0]))}
        return None

    def start(self, query, near=None):
        place = self.geocode(query, near)
        with self.lock:
            self.stop()
            if not place:
                return {"ok": False, "voice": voice_id(PLACE_NOT_FOUND_TEXT)}
            self.destination = place["coordinate"]
            self.label = place["label"]
            self.status = "waiting_for_location"
        print(f"Navigation destination: {place['label']} {place['coordinate']}", flush=True)
        return {"ok": True, "label": place["label"], "voice": voice_id(DEST_OK_TEXT)}

    def _reply(self, status, voice_text=None, **extra):
        self.status = status
        return {"status": status, "voice": voice_id(voice_text) if voice_text else None, **extra}

    def update(self, lat, lon, accuracy):
        with self.lock:
            if self.destination is None:
                return self._reply("idle")
            if not (-90 <= lat <= 90 and -180 <= lon <= 180):
                return self._reply("poor_gps", GPS_POOR_TEXT)
            if accuracy > nav.GPS_MAX_ACCURACY_METERS:
                return self._reply("poor_gps", GPS_POOR_TEXT)
            if self.route is None:
                if time.monotonic() - self.last_route_try < 5:
                    return self._reply(self.status if self.status == "route_error" else "requesting_route")
                self.last_route_try = time.monotonic()
                try:
                    self.route = nav.fetch_walking_route((lat, lon), self.destination, nav.ORS_API_KEY)
                    self.geometry_index = 0
                    self.step_index = 0
                    self.off_route_hits = 0
                except Exception as exc:
                    print(f"Route error: {exc}", flush=True)
                    return self._reply("route_error", ROUTE_ERROR_TEXT, error=str(exc))
                ready = self._reply("route_ready", ROUTE_READY_TEXT,
                                    distance_m=self.route["distance_m"])
                return ready

            progress = nav.progress_for_location(self.route, lat, lon, self.geometry_index)
            self.geometry_index = progress["geometry_index"]
            off_by = distance_to_route_m(self.route["geometry"], lat, lon, self.geometry_index)
            self.off_route_hits = self.off_route_hits + 1 if off_by > OFF_ROUTE_METERS else 0
            if self.off_route_hits >= 3:
                self.route = None            # next GPS fix asks for a new route
                self.last_route_try = 0.0
                return self._reply("off_route", OFF_ROUTE_TEXT)

            # Steps only move forward. A turn point is shared by two steps, so just
            # after a turn the nearest point can still belong to the previous step;
            # without this the previous instruction was repeated.
            step_index = max(progress["step_index"], self.step_index)
            self.step_index = step_index
            step = self.route["steps"][step_index]
            bucket = (route_distance_bucket(progress.get("announce_distance_m", 0.0))
                      if step_index == progress["step_index"] else 0)
            text = nav.instruction_malayalam(step["instruction"], bucket)
            voice = voice_id(text)
            if voice is None:                # should not happen; try once
                try:
                    cam.write_tts_cache(text)
                    voice = voice_id(text)
                except Exception:
                    voice = None
            return self._reply("navigating", step_index=step_index, voice=None,
                               step_voice=voice, instruction=text,
                               instruction_en=step["instruction"],
                               distance_to_step_m=round(progress["distance_to_step_m"], 1))


# ---------------------------------------------------------------- http
DETECTOR = None
NAVIGATOR = Navigator()
CONFIG = {"destination": "", "frame_long": max(FRAME_SIZE)}


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WEB_DIR), **kwargs)

    def log_message(self, fmt, *args):     # keep the console readable
        if not self.path.startswith(("/api/detect", "/api/nav/update", "/voices/")):
            super().log_message(fmt, *args)

    def end_headers(self):
        if self.path.startswith("/voices/"):
            self.send_header("Cache-Control", "public, max-age=31536000, immutable")
        else:
            self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def send_json(self, data, code=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_body(self):
        length = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(length) if length else b""

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/voices":
            texts, _ = all_voice_texts()
            ids = [v for v in (voice_id(t) for t in texts) if v]
            named = {k: voice_id(t) for k, t in NAMED_TEXTS.items()}
            return self.send_json({"voices": ids, "named": named})
        if path == "/api/config":
            return self.send_json(CONFIG)
        if path == "/api/status":
            return self.send_json({"models": getattr(DETECTOR, "status", {}),
                                   "thresholds": {"person": cam.PERSON_CONFIDENCE, "object": cam.COCO_CONFIDENCE,
                                                  "pothole": cam.POTHOLE_CONFIDENCE,
                                                  "world_default": OPEN_VOCAB_DEFAULT_MIN},
                                   "ignored": sorted(IGNORED_LABELS)})
        if path.startswith("/voices/"):
            name = Path(path).name
            file = cam.TTS_CACHE_DIR / name
            if not name.endswith(".mp3") or not file.is_file():
                return self.send_error(404)
            data = file.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "audio/mpeg")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return None
        return super().do_GET()

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        try:
            if path == "/api/detect":
                try:
                    return self.send_json(DETECTOR.detect(self.read_body()))
                except Exception as exc:
                    print(f"Detection error: {exc}", flush=True)
                    DETECTOR.reset()
                    return self.send_json({"key": "safety_stop", "voice": [voice_id(cam.SAFETY_STOP_TEXT)],
                                           "guidance": "STOP - Detection error", "error": str(exc)})
            body = json.loads(self.read_body() or b"{}")
            if path == "/api/reset":          # detection paused/resumed: forget old tracks
                DETECTOR.reset()
                return self.send_json({"ok": True})
            if path == "/api/nav/start":
                near = (body["lat"], body["lon"]) if body.get("lat") is not None else None
                try:
                    return self.send_json(NAVIGATOR.start(str(body.get("destination", "")), near))
                except Exception as exc:
                    print(f"Place search error: {exc}", flush=True)
                    return self.send_json({"ok": False, "voice": voice_id(ROUTE_ERROR_TEXT), "error": str(exc)})
            if path == "/api/nav/update":
                return self.send_json(NAVIGATOR.update(float(body["lat"]), float(body["lon"]),
                                                       float(body.get("accuracy", 9999))))
            if path == "/api/nav/stop":
                with NAVIGATOR.lock:
                    NAVIGATOR.stop()
                return self.send_json({"ok": True})
            return self.send_error(404)
        except Exception as exc:
            return self.send_json({"error": str(exc)}, 500)


def make_https_context():
    cert, key = APP_DIR / ".cert.pem", APP_DIR / ".key.pem"
    if not (cert.is_file() and key.is_file()):
        import datetime
        import ipaddress
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID
        pkey = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "nethra-vazhi.local")])
        alt = [x509.DNSName("localhost"), x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]
        ip = local_ip()
        if ip:
            alt.append(x509.IPAddress(ipaddress.ip_address(ip)))
        now = datetime.datetime.now(datetime.timezone.utc)
        certificate = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
                       .public_key(pkey.public_key()).serial_number(x509.random_serial_number())
                       .not_valid_before(now - datetime.timedelta(days=1))
                       .not_valid_after(now + datetime.timedelta(days=825))
                       .add_extension(x509.SubjectAlternativeName(alt), critical=False)
                       .sign(pkey, hashes.SHA256()))
        key.write_bytes(pkey.private_bytes(serialization.Encoding.PEM,
                                           serialization.PrivateFormat.TraditionalOpenSSL,
                                           serialization.NoEncryption()))
        cert.write_bytes(certificate.public_bytes(serialization.Encoding.PEM))
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(str(cert), str(key))
    return context


def local_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            return s.getsockname()[0]
    except OSError:
        return None


def open_browser(url):
    """Open as a full-screen app window. Chrome/Edge get autoplay allowed so the
    start-up voice plays without a tap; otherwise fall back to the default browser."""
    candidates = [
        shutil.which("chrome"), shutil.which("google-chrome"), shutil.which("msedge"),
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
    ]
    for exe in candidates:
        if exe and Path(exe).is_file():
            try:
                subprocess.Popen([exe, f"--app={url}", "--start-fullscreen",
                                  "--autoplay-policy=no-user-gesture-required",
                                  f"--user-data-dir={APP_DIR / '.browser-profile'}"])
                return
            except OSError:
                pass
    webbrowser.open(url)


def main():
    global DETECTOR
    parser = argparse.ArgumentParser(description="Nethra Vazhi website")
    parser.add_argument("--port", type=int, default=PORT)
    parser.add_argument("--https", action="store_true", help="serve HTTPS (needed for a phone's camera/GPS)")
    parser.add_argument("--destination", default=os.getenv("NETHRA_DESTINATION", ""),
                        help="fixed destination for navigation mode (otherwise it is asked by voice)")
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    CONFIG["destination"] = args.destination.strip()

    print("Starting Nethra Vazhi website...", flush=True)
    if not download_all_voices():
        return 2
    DETECTOR = Detector()

    server = ThreadingHTTPServer(("0.0.0.0", args.port), Handler)
    scheme = "http"
    if args.https:
        server.socket = make_https_context().wrap_socket(server.socket, server_side=True)
        scheme = "https"
    url = f"{scheme}://localhost:{args.port}"
    print(f"\nReady:  {url}", flush=True)
    ip = local_ip()
    if ip:
        print(f"Phone (same Wi-Fi): {scheme}://{ip}:{args.port}"
              + ("" if args.https else "   <- phones need --https for camera/GPS"), flush=True)
    print("Triple tap: detection -> detection + navigation -> detection.  Ctrl+C to stop.\n", flush=True)
    if not args.no_browser:
        threading.Timer(0.5, open_browser, args=(url,)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
