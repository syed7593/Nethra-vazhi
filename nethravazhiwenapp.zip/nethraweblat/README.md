# Nethra Vazhi – website

Camera-only web version of the app. No buttons, no text – just the camera and Malayalam voice.

## Start

Double-click **start.bat** (or run `python server.py`).

1. First run downloads all ~353 Malayalam voices and the YOLO models (needs internet, takes a few minutes). After that they load from disk.
2. The page opens full-screen at **http://localhost:8000** with the camera already running and detection on.
3. Allow camera (and microphone + location for navigation) the first time.

## Gestures

| Triple tap anywhere | What happens |
|---|---|
| in detection | **Navigation**: detection pauses and it asks "ലക്ഷ്യസ്ഥാനം പറയുക" – say the place (e.g. "Aluva Railway Station"). Once the route has started, detection starts again and runs together with the spoken route steps. Hazard warnings always come first. |
| in navigation | Back to **detection only**. |

## Options

- Fixed destination (skip speaking it): `python server.py --destination "Kochi Metro Aluva"` or open `http://localhost:8000/?dest=Aluva`
- The place is heard in Indian English by default, because the map search finds "Aluva Railway Station" but often not the same name in Malayalam script. For Malayalam speech: `http://localhost:8000/?lang=ml-IN`
- Detection model: `yolo26s` at 640 px (more accurate). On a slow PC: `set NETHRA_COCO_MODEL=yolo26n.pt` and `set NETHRA_IMGSZ=416` before start.bat. An NVIDIA GPU is used automatically if PyTorch has CUDA.
- Several close objects are named in one warning (front, left and right covered first, up to 3 objects).
- Phone on the same Wi-Fi: run **start-phone.bat** (HTTPS – phones only give camera/GPS to HTTPS pages), open the `https://<pc-ip>:8000` address it prints, accept the certificate warning once.
- See the detection boxes while testing: `http://localhost:8000/?debug=1`

## Files

- `server.py` – port 8000 server. Uses the detection rules from `nethracam.py` and the OSM route logic from `osmmap.py`, so it behaves like the app.
- `web/index.html`, `web/style.css`, `web/app.js` – the page.
- `best.pt` – pothole model. `yolo26s.pt` and `yolov8s-worldv2.pt` download automatically.


## Voice alerts

- **Approaching** object: "Caution" + where it is + its name (no "stop").
- **Too close**: "Stop" + where + its name + "check with the cane".
- Several objects: one announcement names each object and where it is.
- A clip always plays to its end; nothing is cut off except by a triple tap.

## Check that the three models work

```
python check_models.py                 # one frame from the webcam
python check_models.py photo.jpg       # a photo of a pothole, stairs, a road ...
```

It prints every detection of the object model, the pothole model and YOLO-World, says whether
the app would use it, and saves `check_result.jpg` with the boxes. When the server starts it
also prints a "Model check" table; open `http://localhost:8000/?debug=1` to see it on screen.
