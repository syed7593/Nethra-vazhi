@echo off
REM Nethra Vazhi website - http://localhost:8000
cd /d "%~dp0"
python -c "import ultralytics, edge_tts, gtts, cryptography" 2>NUL || python -m pip install -r requirements.txt
python -c "import clip" 2>NUL || python -m pip install "git+https://github.com/ultralytics/CLIP.git"
python server.py %*
pause
