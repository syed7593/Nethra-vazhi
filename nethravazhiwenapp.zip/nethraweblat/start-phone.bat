@echo off
REM Same site over HTTPS so a phone on the same Wi-Fi can use its camera and GPS
cd /d "%~dp0"
call start.bat --https
