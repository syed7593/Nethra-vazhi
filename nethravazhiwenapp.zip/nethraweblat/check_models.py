"""Check that all three models really work, on YOUR pictures.

    python check_models.py                one frame from the webcam
    python check_models.py photo.jpg      a picture (a pothole, stairs, a road ...)

It prints every detection of every model (even weak ones) and says whether the app would
use it, then runs the full app pipeline and shows what the voice would say. The picture
with boxes is saved as check_result.jpg:
    green = objects (YOLO26)   red = pothole model   blue = YOLO-World (stairs, curb, pole ...)
"""
import sys

import cv2

import nethracam as cam
import server as S


def load_frame(path):
    if path:
        frame = cv2.imread(path)
        if frame is None:
            raise SystemExit(f"Cannot read the picture: {path}")
        return frame
    cap = cv2.VideoCapture(0)
    ok, frame = False, None
    for _ in range(10):                       # let the camera adjust its exposure
        ok, frame = cap.read()
    cap.release()
    if not ok:
        raise SystemExit("Cannot read the webcam (is another program using it?)")
    return frame


def rows(result, name_of):
    out = []
    for box in getattr(result, "boxes", []) or []:
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        out.append((name_of(int(box.cls[0])), float(box.conf[0]), (x1, y1, x2, y2)))
    return sorted(out, key=lambda r: -r[1])


def show(title, found, accepts, canvas, color):
    print(f"\n{title}")
    if not found:
        print("  nothing found by this model in this picture")
    for label, conf, box in found:
        verdict = accepts(label, conf)
        print(f"  {label:<14} confidence {conf:.2f}   {verdict}")
        cv2.rectangle(canvas, box[:2], box[2:], color, 2)
        cv2.putText(canvas, f"{label} {conf:.2f}", (box[0], max(14, box[1] - 5)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    frame = load_frame(argv[0] if argv else None)
    height, width = frame.shape[:2]
    scale = max(S.FRAME_SIZE) / max(height, width)
    if scale < 1:
        frame = cv2.resize(frame, (round(width * scale), round(height * scale)), interpolation=cv2.INTER_AREA)

    print("Loading the models (the first run downloads them) ...")
    d = S.Detector()
    opts = dict(imgsz=S.INFERENCE_SIZE, device=d.device, verbose=False, max_det=30)
    if d.half:
        opts["half"] = True
    canvas = frame.copy()

    coco = d.coco(frame, conf=0.15, **opts)[0]
    show("Objects (YOLO26, people, vehicles, animals ...)",
         rows(coco, lambda i: str(d.coco.names[i]).lower()),
         lambda n, c: ("used" if cam.is_reliable_coco_detection(n, c) and n not in S.IGNORED_LABELS
                       else "ignored (too weak, or not a walking hazard)"),
         canvas, (0, 200, 0))

    pothole = d.pothole(frame, conf=0.10, **opts)[0]
    show(f"Pothole model (best.pt) - the app needs {cam.POTHOLE_CONFIDENCE:.2f} or more",
         rows(pothole, lambda i: "pothole"),
         lambda n, c: "used" if c >= cam.POTHOLE_CONFIDENCE else "ignored (below the pothole threshold)",
         canvas, (0, 0, 255))

    if d.open_vocab is None:
        print(f"\nYOLO-World: NOT RUNNING - {d.open_vocab_error}")
        print('  fix: pip install "git+https://github.com/ultralytics/CLIP.git"   then run this again')
    else:
        world = d.open_vocab(frame, conf=0.10, **opts)[0]
        labels = [label for label, _ in cam.OPEN_VOCAB_LABELS]
        show("YOLO-World (stairs, curb, ramp, cone, bollard, barrier, doorway, glass door, pole, wall)",
             rows(world, lambda i: labels[i] if 0 <= i < len(labels) else "?"),
             lambda n, c: ("used" if c >= S.OPEN_VOCAB_LABEL_MIN.get(n, S.OPEN_VOCAB_DEFAULT_MIN)
                           else "ignored (below this class's minimum)"),
             canvas, (255, 120, 0))

    # The whole app pipeline on the same picture, repeated like a live camera: an object is
    # only announced after it is seen in several frames in a row.
    ok, jpeg = cv2.imencode(".jpg", frame)
    result = None
    for _ in range(12):
        result = d.detect(jpeg.tobytes())
    print("\nWhat the app would say (after confirmation over 12 frames):")
    print(f"  {result['guidance']}")
    for o in result["objects"]:
        if o["confirmed"]:
            print(f"  {o['label']:<14} {o['side']:<7} {o['proximity']}")
    cv2.imwrite("check_result.jpg", canvas)
    print("\nSaved check_result.jpg  (green = objects, red = pothole, blue = YOLO-World)")


if __name__ == "__main__":
    main()
