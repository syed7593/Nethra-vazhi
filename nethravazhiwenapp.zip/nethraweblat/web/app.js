/* Nethra Vazhi web: camera opens at once, voice only.
   Triple tap anywhere: detection  ->  detection + navigation  ->  detection. */
(() => {
  "use strict";

  const params = new URLSearchParams(location.search);
  const DEBUG = params.get("debug") === "1";
  // Place names are recognised in English letters by default: the map search finds
  // "Aluva Railway Station" but often not the same name in Malayalam script.
  const SPEECH_LANG = params.get("lang") || "en-IN";
  let FRAME_W = 640, FRAME_H = 480;            // updated from the real camera shape in detectLoop
  const TRIPLE_TAP_MS = 700;                   // 3 taps inside this window
  const ROUTE_REPEAT_S = Number(params.get("repeat")) || 10;   // repeat the direction every 10 s
  // Timing of the voice (seconds). One speaker, one clip at a time: a clip always plays to its end.
  const HAZARD_GAP_S = 4;          // the same warning is repeated no sooner than this after it ENDED
  const URGENT_GAP_S = 2;          // ... for urgent warnings (stop, pothole, stairs, front blocked)
  const CLEAR_GAP_S = 15;          // "nothing detected" (detection-only mode)
  const BREATH_S = 0.35;           // silence between any two clips
  const NAV_PROCESS_PAUSE_MS = 1500;   // after "route ready": time to process the location, then the first direction
  const DETECT_SETTLE_MS = 2500;       // after the first direction: quiet time, then detection starts
  const DELAY_STOP_S = 1.5;                    // same as the app: no result for 1.5 s -> STOP

  const video = document.getElementById("cam");
  const debugCanvas = document.getElementById("debug");
  const grab = document.createElement("canvas");
  grab.width = FRAME_W; grab.height = FRAME_H;
  const grabCtx = grab.getContext("2d");

  const app = {
    mode: "detect",            // "detect" | "nav"
    currentKey: null,          // last detection key (clear / far / obstacle_left ...)
    lastProcessed: 0,
    detecting: false,
    destination: null,
    gpsWatch: null,
    fix: null,
    navTimer: null,
    navBusy: false,
    detectPaused: false,       // true while navigation asks for the place
    navStartedAt: 0,
    lastNavStatus: null,
    lastRouteStep: -1,
    lastRouteAt: 0,
    route: null,               // latest direction from the server {voice, step}
    alert: null,               // latest detection warning {key, ids, id, t}
    recognition: null,
    config: { destination: "" },
  };
  window.nethra = app;          // for testing from the console

  // ------------------------------------------------------------ audio
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  const audio = new AudioCtx();
  const buffers = new Map();
  let named = {};
  let playing = null;           // { src, endsAt }
  let lastKey = null, lastId = null, lastTime = 0;
  let startupPlayed = false;

  const now = () => performance.now() / 1000;
  const busy = () => !!playing && audio.currentTime < playing.endsAt;

  // fetch with a timeout and retries: through a tunnel one stuck request must not freeze startup
  async function fetchRetry(url, tries = 3, ms = 20000) {
    for (let i = 0; ; i++) {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), ms);
      try {
        const res = await fetch(url, { signal: ctl.signal });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res;
      } catch (e) {
        if (i >= tries - 1) throw e;
        await sleep(400 * (i + 1));
      } finally { clearTimeout(timer); }
    }
  }

  let voiceIds = [];
  async function loadManifest() {
    const manifest = await (await fetchRetry("/api/voices")).json();
    named = manifest.named || {};
    voiceIds = manifest.voices || [];
    app.voicesTotal = voiceIds.length;
  }

  // Runs in the background: detection starts without waiting for all ~350 voices.
  async function loadBuffers() {
    let next = 0;
    async function worker() {
      while (next < voiceIds.length) {
        const id = voiceIds[next++];
        try {
          const data = await (await fetchRetry(`/voices/${id}`)).arrayBuffer();
          buffers.set(id, await audio.decodeAudioData(data));
          app.voicesLoaded = buffers.size;
        } catch (e) { console.warn("voice load failed", id, e); }
      }
    }
    await Promise.all(Array.from({ length: 6 }, worker));
    app.voicesLoaded = buffers.size;
    console.log(`[nethra] voices loaded ${buffers.size}/${voiceIds.length}`);
  }

  const voiceKey = ids => [].concat(ids).join("+");

  function stopPlaying() {
    if (playing) { for (const s of playing.srcs) { try { s.stop(); } catch (_) {} } playing = null; }
  }

  // Plays one voice, or several clips back to back (multiple objects). Never cuts what is
  // playing: the scheduler below only calls it when the speaker is silent.
  function playRaw(ids) {
    ids = [].concat(ids).filter(Boolean);
    return new Promise(resolve => {
      const bufs = ids.map(id => buffers.get(id)).filter(Boolean);
      if (!bufs.length) { resolve(); return; }
      let t = audio.currentTime + 0.02;
      const srcs = bufs.map(buf => {
        const src = audio.createBufferSource();
        src.buffer = buf;
        src.connect(audio.destination);
        src.start(t);
        t += buf.duration + 0.08;          // small gap between clips
        return src;
      });
      const entry = { srcs, endsAt: t, id: voiceKey(ids) };
      srcs[srcs.length - 1].onended = () => { if (playing === entry) playing = null; resolve(); };
      playing = entry;
      app.lastPlayed = entry.id;
      app.playLog = (app.playLog || []).concat(ids.length > 1 ? [ids] : ids).slice(-50);
    });
  }

  // Warning classes (same numbers as nethracam.py): only used to tell urgent from normal.
  const PRIORITY = {
    safety_stop: 150, pothole_ahead: 145, stairs_ahead: 140, front_blocked: 138, both_sides: 138, stop: 125,
    obstacle_left: 125, obstacle_right: 125,                 // too close: "stop" + name
    caution_front: 60, caution_left: 60, caution_right: 60, caution_both: 60,   // approaching: "caution" + place
    clear: 10,
  };
  const priority = k => PRIORITY[k] || 0;
  const urgent = k => priority(k) >= 120;

  // ------------------------------------------------------------ one speaker, one voice at a time
  // Three things want to talk: prompts (mode, GPS, route ready ...), detection warnings and the
  // route direction. They never overlap and nothing is cut off. When the speaker is free:
  //   1. queued prompts, in order;
  //   2. an urgent warning, else a direction that is due, else a normal warning.
  // Repeats are spaced by the gaps above, so a direction (due every ROUTE_REPEAT_S) always gets
  // a turn between repeated warnings.
  const prompts = [];                 // { ids, resolve }
  const endedAt = new Map();          // clip id -> time it last finished
  let lastEndAny = 0, lastHazardEnd = 0;

  function speakPrompt(ids) {
    return new Promise(resolve => { prompts.push({ ids, resolve }); });
  }
  function say(name) {
    const id = named[name];
    return id ? speakPrompt(id) : Promise.resolve();
  }
  function speakStatus(name, id) {
    const v = id || named[name];
    const last = prompts[prompts.length - 1];
    if (v && !(last && last.ids === v)) speakPrompt(v);
  }
  const quiet = () => !busy() && !prompts.length;
  async function waitForQuiet() { while (!quiet()) await sleep(100); }

  // A deliberate mode change (triple tap) is the only thing that cuts speech.
  function cutSpeech() {
    stopPlaying();
    while (prompts.length) prompts.shift().resolve();
    app.alert = null;
  }

  function startClip(kind, key, ids) {
    const id = voiceKey(ids);
    lastKey = key; lastId = id; lastTime = now();
    return playRaw(ids).then(() => {
      const t = now();
      endedAt.set(id, t); lastEndAny = t;
      if (kind === "hazard") lastHazardEnd = t;
    });
  }

  function eligibleHazard(t) {
    const a = app.alert;
    if (!a || t - a.t > 1.2 || a.key === "far") return null;
    if (a.key === "clear") {
      if (app.mode === "nav") return null;                 // the directions are the voice while navigating
      if (t - (endedAt.get(a.id) || -1e9) < CLEAR_GAP_S || t - lastHazardEnd < 3) return null;
    }
    const gap = urgent(a.key) ? URGENT_GAP_S : HAZARD_GAP_S;
    if (t - (endedAt.get(a.id) || -1e9) < gap) return null;
    return a;
  }

  function routeDue(t) {
    if (app.mode !== "nav" || !app.route) return false;
    return app.route.step !== app.lastRouteStep || t - app.lastRouteAt >= ROUTE_REPEAT_S;
  }

  setInterval(() => {
    if (busy()) return;
    const t = now();
    if (t - lastEndAny < BREATH_S) return;
    if (prompts.length) {
      const item = prompts.shift();
      startClip("prompt", "user_command", item.ids).then(item.resolve);
      return;
    }
    if (app.detectPaused) return;
    const hazard = eligibleHazard(t);
    const dir = routeDue(t);
    if (hazard && urgent(hazard.key)) startClip("hazard", hazard.key, hazard.ids);
    else if (dir) {
      app.lastRouteStep = app.route.step; app.lastRouteAt = t;
      startClip("route", "route_instruction", app.route.voice);
    } else if (hazard) startClip("hazard", hazard.key, hazard.ids);
  }, 100);

  function unlockAudio() {
    if (audio.state !== "running") {
      audio.resume().then(() => {
        if (!startupPlayed && buffers.size) { startupPlayed = true; say("startup"); }
      });
    }
  }

  // ------------------------------------------------------------ camera + detection
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  async function openCamera() {
    for (;;) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } },
        });
        video.srcObject = stream;
        await video.play().catch(() => {});
        return;
      } catch (e) {
        console.warn("camera", e);
        if (buffers.size) say("camera_error");
        await sleep(4000);
      }
    }
  }

  function toBlob() {
    return new Promise(r => grab.toBlob(r, "image/jpeg", 0.9));
  }

  if (DEBUG) fetch("/api/status").then(r => r.json()).then(j => { app.models = j; }).catch(() => {});

  async function detectLoop() {
    for (;;) {
      if (app.detectPaused) { app.detecting = false; await sleep(100); continue; }
      if (video.readyState < 2 || !video.videoWidth) { await sleep(100); continue; }
      // Keep the camera's own shape (never squash it) and never upscale it.
      const longSide = (app.config && app.config.frame_long) || 640;
      const scale = Math.min(1, longSide / Math.max(video.videoWidth, video.videoHeight));
      const fw = Math.round(video.videoWidth * scale), fh = Math.round(video.videoHeight * scale);
      if (grab.width !== fw || grab.height !== fh) { grab.width = fw; grab.height = fh; FRAME_W = fw; FRAME_H = fh; }
      grabCtx.imageSmoothingQuality = "high";
      grabCtx.drawImage(video, 0, 0, fw, fh);
      const blob = await toBlob();
      try {
        const res = await fetch("/api/detect", { method: "POST", body: blob,
          headers: { "Content-Type": "image/jpeg" } });
        const data = await res.json();
        app.lastResult = data;
        app.frames = (app.frames || 0) + 1;
        app.currentKey = data.key;
        if (app.detectPaused) continue;           // paused while the request was in flight
        if (data.error) app.alert = { key: "safety_stop", ids: data.voice, id: voiceKey(data.voice), t: now() };
        else {
          app.lastProcessed = now();
          app.detecting = true;
          // The scheduler decides when (and whether) this is spoken.
          app.alert = data.voice ? { key: data.key, ids: data.voice, id: voiceKey(data.voice), t: now() } : null;
        }
        if (DEBUG) drawDebug(data);
      } catch (e) {
        console.warn("detect", e);
        await sleep(300);
      }
      await sleep(30);
    }
  }

  // Same as the app: if detection stalls for 1.5 s, say STOP.
  setInterval(() => {
    if (app.detecting && now() - app.lastProcessed > DELAY_STOP_S) {
      app.currentKey = "safety_stop";
      if (named.safety_stop) app.alert = { key: "safety_stop", ids: named.safety_stop, id: named.safety_stop, t: now() };
    }
  }, 250);

  function drawDebug(data) {
    debugCanvas.hidden = false;
    const [fw, fh] = data.frame || [FRAME_W, FRAME_H];
    debugCanvas.width = fw; debugCanvas.height = fh;
    const g = debugCanvas.getContext("2d");
    g.clearRect(0, 0, fw, fh);
    g.lineWidth = 2; g.font = "12px sans-serif";
    for (const o of data.objects || []) {
      const [x1, y1, x2, y2] = o.box;
      g.strokeStyle = g.fillStyle = o.confirmed ? "#00c800" : "#ffdc00";
      g.strokeRect(x1, y1, x2 - x1, y2 - y1);
      g.fillText(`${o.label} ${o.confidence}`, x1 + 2, Math.max(12, y1 - 4));
    }
    g.fillStyle = "#fff";
    g.fillText(`[${app.mode}] ${data.guidance || ""}`, 6, 16);
    const m = (app.models && app.models.models) || {};
    const names = Object.keys(m);
    if (names.length) g.fillText(names.map(n => `${n}: ${m[n].ok ? "OK" : "OFF"}`).join("   "), 6, 32);
  }

  // ------------------------------------------------------------ navigation
  async function postJSON(url, body) {
    const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}) });
    return res.json();
  }

  function startGps() {
    if (!navigator.geolocation) return;
    app.gpsWatch = navigator.geolocation.watchPosition(
      p => { app.fix = { lat: p.coords.latitude, lon: p.coords.longitude, accuracy: p.coords.accuracy }; },
      e => console.warn("gps", e),
      { enableHighAccuracy: true, maximumAge: 2000, timeout: 20000 });
  }

  function stopGps() {
    if (app.gpsWatch !== null) navigator.geolocation.clearWatch(app.gpsWatch);
    app.gpsWatch = null;
  }

  function listenOnce() {
    return new Promise(resolve => {
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SR) { resolve(null); return; }
      const rec = new SR();
      app.recognition = rec;
      rec.lang = SPEECH_LANG;
      rec.interimResults = false;
      rec.maxAlternatives = 1;
      let text = null, done = false;
      const finish = () => {
        if (done) return;
        done = true; clearTimeout(timer); app.recognition = null; resolve(text);
      };
      const timer = setTimeout(() => { try { rec.abort(); } catch (_) {} finish(); }, 10000);
      rec.onresult = e => { text = (e.results[0][0].transcript || "").trim(); };
      rec.onerror = () => {};
      rec.onend = finish;
      try { rec.start(); } catch (_) { finish(); }
    });
  }

  async function getDestination() {
    if (app.config.destination) return app.config.destination;
    if (params.get("dest")) return params.get("dest");
    for (let attempt = 0; attempt < 3 && app.mode === "nav"; attempt++) {
      await say(attempt === 0 ? "ask_dest" : "dest_retry");
      if (app.mode !== "nav") return null;
      const heard = await listenOnce();
      console.log("[nethra] heard:", heard);
      if (heard) return heard;
    }
    return null;
  }

  // Navigation order: 1) ask the place (detection paused, so warnings do not talk
  // over the question or get picked up by the microphone), 2) start the route,
  // 3) detection starts again as soon as navigation has started.
  const DETECT_RESUME_FALLBACK_MS = 25000;   // never leave detection off longer than this

  function pauseDetection() {
    app.detectPaused = true;
    app.detecting = false;
    app.currentKey = null;
    app.alert = null;
  }

  function resumeDetection(announce) {
    if (app.resumeTimer) { clearTimeout(app.resumeTimer); app.resumeTimer = null; }
    if (!app.detectPaused) return;
    postJSON("/api/reset").catch(() => {});
    app.detectPaused = false;
    app.lastProcessed = now();
    if (announce) say("detect_on");
  }

  // Order: ask the place -> "destination received" -> the location and route are processed
  // (GPS fix, route) -> short pause -> FIRST DIRECTION in full -> quiet pause -> detection
  // starts -> from then on the direction repeats every 10 s, sharing the speaker with the
  // detection warnings (see the scheduler above).
  async function enterNavigation() {
    app.mode = "nav";
    app.lastNavStatus = null;
    app.lastRouteStep = -1;
    app.lastRouteAt = 0;
    app.route = null;
    pauseDetection();
    startGps();
    await say("nav_mode");
    let tries = 0;
    while (app.mode === "nav" && tries < 3) {
      tries++;
      const dest = await getDestination();
      if (app.mode !== "nav") return;
      if (!dest) break;
      const near = app.fix ? { lat: app.fix.lat, lon: app.fix.lon } : {};
      const r = await postJSON("/api/nav/start", { destination: dest, ...near }).catch(() => ({ ok: false }));
      if (app.mode !== "nav") return;
      if (r.ok) {
        app.destination = r.label;
        app.navStartedAt = Date.now();
        if (r.voice) await speakPrompt(r.voice);
        if (app.mode !== "nav") return;
        app.navTimer = setInterval(navTick, 1000);
        // Safety net: if GPS/route is slow, turn detection back on anyway.
        app.resumeTimer = setTimeout(() => { if (app.mode === "nav") resumeDetection(true); },
                                     DETECT_RESUME_FALLBACK_MS);
        return;
      }
      if (r.voice) await speakPrompt(r.voice);
      if (app.config.destination || params.get("dest")) break;   // fixed destination failed
    }
    if (app.mode === "nav") {             // no destination: back to detection only
      await say("dest_fail");
      leaveNavigation(false);
    }
  }

  async function navTick() {
    if (app.mode !== "nav" || app.navBusy) return;
    if (!app.fix) {
      if (app.lastNavStatus !== "gps_wait") { app.lastNavStatus = "gps_wait"; speakStatus("gps_wait"); }
      return;
    }
    app.navBusy = true;
    try {
      const r = await postJSON("/api/nav/update", app.fix);
      if (app.mode !== "nav") return;
      app.lastNav = r;
      if (r.status !== app.lastNavStatus) {
        app.lastNavStatus = r.status;
        if (r.voice) speakStatus(null, r.voice);
      }
      if (r.status === "route_ready" || r.status === "off_route") { app.lastRouteStep = -1; app.route = null; }
      // The route failed: do not leave the user without detection.
      if (app.detectPaused && (r.status === "route_error" || r.status === "off_route")) resumeDetection(false);

      if (r.status === "navigating" && r.step_voice) {
        if (app.detectPaused) {
          // 1) let "route ready" finish, 2) time to process the location, 3) the first direction
          // in full, 4) a quiet pause, 5) detection starts.
          await waitForQuiet();
          await sleep(NAV_PROCESS_PAUSE_MS);
          if (app.mode !== "nav") return;
          app.route = { voice: r.step_voice, step: r.step_index };
          app.lastRouteStep = r.step_index;
          app.lastRouteAt = now();
          await speakPrompt(r.step_voice);
          await sleep(DETECT_SETTLE_MS);
          if (app.mode === "nav") resumeDetection(true);
          return;
        }
        // Later directions: the scheduler speaks the latest one every ROUTE_REPEAT_S.
        app.route = { voice: r.step_voice, step: r.step_index };
      }
    } catch (e) {
      console.warn("nav", e);
    } finally {
      app.navBusy = false;
    }
  }

  function leaveNavigation(announce = true) {
    app.mode = "detect";
    if (app.navTimer) clearInterval(app.navTimer);
    app.navTimer = null;
    if (app.recognition) { try { app.recognition.abort(); } catch (_) {} }
    stopGps();
    app.destination = null;
    app.route = null;
    resumeDetection(false);
    postJSON("/api/nav/stop").catch(() => {});
    if (announce) say("detect_mode");
  }

  // ------------------------------------------------------------ triple tap
  let taps = [];
  function onTap() {
    unlockAudio();
    const t = performance.now();
    taps = taps.filter(x => t - x < TRIPLE_TAP_MS);
    taps.push(t);
    if (taps.length >= 3) {
      taps = [];
      cutSpeech();                       // a deliberate mode change is the only thing that cuts speech
      if (app.mode === "detect") enterNavigation();
      else leaveNavigation(true);
    }
  }
  document.addEventListener("pointerdown", onTap, { passive: true });
  document.addEventListener("dblclick", e => e.preventDefault());
  document.addEventListener("contextmenu", e => e.preventDefault());
  document.addEventListener("keydown", unlockAudio);

  // Keep the screen awake while walking.
  async function wakeLock() {
    try { if (navigator.wakeLock) await navigator.wakeLock.request("screen"); } catch (_) {}
  }
  document.addEventListener("visibilitychange", () => { if (!document.hidden) wakeLock(); });

  // ------------------------------------------------------------ start
  (async () => {
    const camera = openCamera();                     // camera first, straight away
    app.config = await fetchRetry("/api/config").then(r => r.json()).catch(() => ({}));
    await loadManifest().catch(e => console.warn("voice list", e));
    const voices = loadBuffers().then(() => {
      if (audio.state === "running") { startupPlayed = true; say("startup"); }
      else audio.resume().then(() => {
        if (!startupPlayed && audio.state === "running") { startupPlayed = true; say("startup"); }
      }).catch(() => {});
    }).catch(e => console.warn("voices", e));
    wakeLock();
    await camera;
    app.ready = true;
    detectLoop();                                    // starts now, voices keep loading behind it
    await voices;
  })();
})();
