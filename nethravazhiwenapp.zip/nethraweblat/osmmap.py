from pathlib import Path
from hashlib import sha256
import asyncio
import importlib
import json
import math
import os
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Callable

# OSM walking route support (standard-library only)
ORS_API_KEY = os.getenv("NETHRA_ORS_API_KEY") or "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjcxMmE4ZTI0YTRmZTQzZmJhZjg0NzViNTU0YjE4ZDQ3IiwiaCI6Im11cm11cjY0In0="
ORS_URL = "https://api.openrouteservice.org/v2/directions/foot-walking/json"
ORS_GEOCODE_URL = "https://api.openrouteservice.org/geocode/search"
GPS_MAX_ACCURACY_METERS = 35.0
ANNOUNCE_STEP_WITHIN_METERS = 35.0
ROUTE_POLL_SECONDS = 1.0
REQUEST_TIMEOUT_SECONDS = 15
GPS_FIX_MAX_AGE_SECONDS = 30


def load_location_provider():
    """Load a real device GPS provider; never substitute IP-based location."""
    custom_module = os.getenv("NETHRA_LOCATION_MODULE", "").strip()
    if custom_module:
        module = importlib.import_module(custom_module)
        provider = getattr(module, "get_current_location")
        cleanup = getattr(module, "stop_location_updates", lambda: None)
        return provider, cleanup

    # Pythonista exposes the iPhone's Core Location service as `location`.
    try:
        ios_location = importlib.import_module("location")
        if not all(hasattr(ios_location, name) for name in ("start_updates", "get_location", "stop_updates")):
            raise ImportError("The imported `location` package is not the Pythonista iOS GPS module")
        ios_location.start_updates()

        def get_ios_location():
            fix = ios_location.get_location()
            if not fix:
                return None
            try:
                lat = float(fix["latitude"])
                lon = float(fix["longitude"])
                accuracy = float(fix.get("horizontal_accuracy", fix.get("accuracy", 99999)))
            except (KeyError, TypeError, ValueError):
                return None
            timestamp = fix.get("timestamp")
            if isinstance(timestamp, (int, float)) and time.time() - float(timestamp) > GPS_FIX_MAX_AGE_SECONDS:
                return None
            if accuracy < 0:
                return None
            return lat, lon, accuracy

        return get_ios_location, ios_location.stop_updates
    except ImportError:
        pass
    except Exception as exc:
        raise RuntimeError(f"Could not start iPhone location services: {exc}") from exc

    # Plyer can provide native GPS callbacks in supported mobile runtimes.
    try:
        from plyer import gps
    except ImportError as exc:
        raise RuntimeError(
            "No native GPS Python module found. On iPhone, run this in Pythonista and allow Location permission; "
            "on a supported Android runtime, install Plyer. A normal computer needs a GPS receiver/provider."
        ) from exc

    fix_state = {"value": None, "received": 0.0}
    fix_lock = threading.Lock()

    def on_location(**values):
        try:
            lat = float(values.get("lat", values.get("latitude")))
            lon = float(values.get("lon", values.get("longitude")))
            accuracy = float(values.get("accuracy", values.get("horizontal_accuracy", 99999)))
            if accuracy < 0:
                return
        except (TypeError, ValueError):
            return
        with fix_lock:
            fix_state["value"] = (lat, lon, accuracy)
            fix_state["received"] = time.monotonic()

    try:
        gps.configure(on_location=on_location)
        gps.start(minTime=1000, minDistance=1)
    except Exception as exc:
        raise RuntimeError(f"Could not start Plyer GPS; check location permission/support: {exc}") from exc

    def get_plyer_location():
        with fix_lock:
            if not fix_state["value"] or time.monotonic() - fix_state["received"] > GPS_FIX_MAX_AGE_SECONDS:
                return None
            return fix_state["value"]

    return get_plyer_location, gps.stop


def _haversine_m(a, b):
    lat1, lon1 = map(math.radians, a)
    lat2, lon2 = map(math.radians, b)
    dlat, dlon = lat2 - lat1, lon2 - lon1
    h = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 6_371_000 * 2 * math.asin(math.sqrt(min(1.0, h)))


def parse_coordinate(text):
    """Accept a typed coordinate pair in latitude,longitude order."""
    try:
        lat, lon = (float(part.strip()) for part in text.split(",", 1))
    except (ValueError, TypeError):
        return None
    if -90 <= lat <= 90 and -180 <= lon <= 180:
        return (lat, lon)
    return None


def geocode_places(query, api_key, timeout=REQUEST_TIMEOUT_SECONDS):
    """Resolve a place name with ORS/Pelias and return up to five choices."""
    coordinate = parse_coordinate(query)
    if coordinate:
        return [{"label": query.strip(), "coordinate": coordinate}]
    if not api_key:
        raise ValueError("Set NETHRA_ORS_API_KEY before searching place names")
    url = ORS_GEOCODE_URL + "?" + urllib.parse.urlencode({"text": query, "size": 5})
    request = urllib.request.Request(url, headers={"Authorization": api_key})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.load(response)
    except urllib.error.HTTPError as exc:
        detail = exc.read(500).decode("utf-8", "replace")
        raise RuntimeError(f"Place search failed ({exc.code}): {detail}") from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise RuntimeError(f"Place search failed: {exc}") from exc
    results = []
    for feature in data.get("features", []):
        coords = feature.get("geometry", {}).get("coordinates", [])
        if len(coords) < 2:
            continue
        props = feature.get("properties", {})
        results.append({
            "label": props.get("label") or props.get("name") or query,
            "coordinate": (float(coords[1]), float(coords[0])),
        })
    return results


def choose_place(query, api_key, input_fn=input, output_fn=print):
    """Resolve coordinates or ask the user to select an unambiguous place result."""
    results = geocode_places(query, api_key)
    if not results:
        raise ValueError(f"No place found for: {query}")
    if len(results) == 1:
        output_fn(f"Selected: {results[0]['label']}")
        return results[0]["coordinate"]
    output_fn("Choose the correct location:")
    for index, result in enumerate(results, 1):
        output_fn(f"{index}. {result['label']}")
    while True:
        answer = input_fn("Enter a number: ").strip()
        if answer.isdigit() and 1 <= int(answer) <= len(results):
            return results[int(answer) - 1]["coordinate"]
        output_fn("Invalid choice; select a listed number.")


def instruction_malayalam(english, distance_m=0):
    """Translate common ORS walking maneuvers into short Malayalam prompts.

    ORS currently returns English route steps here; this local mapping covers
    common turn words and fails conservatively for less common instructions.
    """
    text = str(english).strip().lower()
    prefix = f"{round(distance_m)} മീറ്റർ കഴിഞ്ഞ് " if distance_m >= 10 else ""
    if any(word in text for word in ("arrive", "destination reached", "you have reached")):
        return "നിങ്ങൾ ലക്ഷ്യസ്ഥാനത്ത് എത്തി."
    if "u-turn" in text or "uturn" in text:
        return prefix + "യു-ടേൺ എടുക്കുക. ചൂരൽ ഉപയോഗിച്ച് വഴി ഉറപ്പാക്കുക."
    if "sharp left" in text:
        return prefix + "കഠിനമായി ഇടത്തേക്ക് തിരിയുക."
    if "sharp right" in text:
        return prefix + "കഠിനമായി വലത്തേക്ക് തിരിയുക."
    if "slight left" in text or "keep left" in text:
        return prefix + "ഇടത്തേക്ക് അല്പം തിരിഞ്ഞ് ഇടത് വശത്ത് തുടരുക."
    if "slight right" in text or "keep right" in text:
        return prefix + "വലത്തേക്ക് അല്പം തിരിഞ്ഞ് വലത് വശത്ത് തുടരുക."
    if "left" in text:
        return prefix + "ഇടത്തേക്ക് തിരിയുക."
    if "right" in text:
        return prefix + "വലത്തേക്ക് തിരിയുക."
    if "north" in text:
        return "വടക്കോട്ട് നേരെ നടക്കുക."
    if "south" in text:
        return "തെക്കോട്ട് നേരെ നടക്കുക."
    if "east" in text:
        return "കിഴക്കോട്ട് നേരെ നടക്കുക."
    if "west" in text:
        return "പടിഞ്ഞാറോട്ട് നേരെ നടക്കുക."
    if any(word in text for word in ("continue", "straight", "head", "follow", "walk")):
        return prefix + "നേരെ മുന്നോട്ട് നടക്കുക."
    return "റൂട്ട് നിർദ്ദേശം വ്യക്തമായില്ല. നിൽക്കുക; സുരക്ഷിതമായ വഴി സ്ഥിരീകരിക്കുക."


def fetch_walking_route(start, destination, api_key, timeout=REQUEST_TIMEOUT_SECONDS):
    """Fetch one ORS route. start/destination are (latitude, longitude)."""
    if not api_key:
        raise ValueError("Set NETHRA_ORS_API_KEY to a free openrouteservice API key")
    payload = {
        "coordinates": [
            [float(start[1]), float(start[0])],
            [float(destination[1]), float(destination[0])],
        ],
        "instructions": True,
        "language": "en",
        "units": "m",
    }
    request = urllib.request.Request(
        ORS_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": api_key, "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.load(response)
    except urllib.error.HTTPError as exc:
        detail = exc.read(500).decode("utf-8", "replace")
        raise RuntimeError(f"ORS route request failed ({exc.code}): {detail}") from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise RuntimeError(f"ORS route request failed: {exc}") from exc
    return parse_ors_route(data)


def parse_ors_route(data):
    """Normalize ORS JSON into route geometry and ordered maneuver steps."""
    try:
        feature = data["features"][0]
        coordinates = feature["geometry"]["coordinates"]  # ORS order: lon, lat
        properties = feature["properties"]
        segments = properties["segments"]
        steps = []
        for segment in segments:
            for raw in segment["steps"]:
                start_index, end_index = raw["way_points"]
                distance = float(raw.get("distance", 0))
                steps.append({
                    "instruction": str(raw["instruction"]).strip(),
                    "instruction_ml": instruction_malayalam(raw["instruction"]),
                    "distance_m": distance,
                    "duration_s": float(raw.get("duration", 0)),
                    "start_index": int(start_index),
                    "end_index": int(end_index),
                    "type": int(raw.get("type", -1)),
                })
        if not coordinates or not steps:
            raise ValueError("No route geometry or turn instructions")
        # Convert route coordinates to (latitude, longitude).
        geometry = [(float(point[1]), float(point[0])) for point in coordinates]
        return {
            "geometry": geometry,
            "steps": steps,
            "distance_m": float(properties["summary"]["distance"]),
            "duration_s": float(properties["summary"]["duration"]),
        }
    except (KeyError, IndexError, TypeError, ValueError) as exc:
        raise ValueError(f"Unexpected ORS walking-route response: {exc}") from exc


def progress_for_location(route, latitude, longitude, last_index=0):
    """Return nearest forward route point and the next maneuver distance."""
    geometry = route["geometry"]
    if not geometry:
        return {"geometry_index": 0, "step_index": 0, "distance_to_step_m": 0.0,
                "announce_distance_m": 0.0}
    low = max(0, int(last_index) - 2)
    # Limit nearest-point search to a forward window: avoids jumping to a nearby
    # parallel street elsewhere on a loop.
    high = min(len(geometry), max(low + 80, int(last_index) + 80))
    nearest = min(range(low, high), key=lambda i: _haversine_m((latitude, longitude), geometry[i]))
    steps = route["steps"]
    current_step = len(steps) - 1
    for i, step in enumerate(steps):
        if nearest <= step["end_index"]:
            current_step = i
            break
    step_index = current_step
    step = steps[current_step]
    end_index = max(0, min(len(geometry) - 1, step["end_index"]))
    distance_to_boundary = _haversine_m((latitude, longitude), geometry[end_index])
    # Announce the next maneuver before reaching the step boundary.
    if current_step + 1 < len(steps) and distance_to_boundary <= ANNOUNCE_STEP_WITHIN_METERS:
        step_index = current_step + 1
        step = steps[step_index]
        turn_index = max(0, min(len(geometry) - 1, step["start_index"]))
        turn_distance = _haversine_m((latitude, longitude), geometry[turn_index])
        announce_distance = turn_distance
    else:
        turn_distance = distance_to_boundary
        announce_distance = 0.0
    return {
        "geometry_index": max(int(last_index), nearest),
        "step_index": step_index,
        "distance_to_step_m": turn_distance,
        "announce_distance_m": announce_distance,
    }


def start_navigation(destination, location_provider: Callable[[], tuple | None], api_key=None,
                     poll_seconds=ROUTE_POLL_SECONDS, prepare_speech=None):
    """Start route/GPS work in a daemon thread and return its plain state dict.

    location_provider() must return (latitude, longitude, accuracy_m), or None
    until a fresh GPS fix is available. It must not call camera/model functions.
    prepare_speech(text) may cache the Malayalam text and return an audio path.
    """
    key = api_key or os.getenv("NETHRA_ORS_API_KEY", "")
    state = {
        "lock": threading.Lock(), "stop": threading.Event(), "thread": None,
        "destination": (float(destination[0]), float(destination[1])),
        "route": None, "status": "waiting_for_location", "error": None,
        "instruction": "Waiting for a reliable GPS fix", "step_index": -1,
        "distance_to_step_m": None, "route_distance_m": None,
        "route_duration_s": None, "last_gps_time": None,
        "speech_path": None, "step_changed": False,
    }

    def publish(**values):
        with state["lock"]:
            state.update(values)

    def worker():
        route = None
        geometry_index = 0
        prepared_step_index = -1
        off_route_hits = 0
        last_route_request = 0.0
        while not state["stop"].is_set():
            try:
                fix = location_provider()
                if fix is None:
                    publish(status="waiting_for_location", instruction="Waiting for a reliable GPS fix")
                    state["stop"].wait(poll_seconds)
                    continue
                lat, lon, accuracy = map(float, fix)
                if not (-90 <= lat <= 90 and -180 <= lon <= 180):
                    raise ValueError("GPS provider returned invalid coordinates")
                if accuracy > GPS_MAX_ACCURACY_METERS:
                    publish(status="poor_gps", instruction="GPS accuracy is low; wait before following route", error=None)
                    state["stop"].wait(poll_seconds)
                    continue

                if route is None:
                    publish(status="requesting_route", instruction="Getting OSM walking route", error=None)
                    route = fetch_walking_route((lat, lon), state["destination"], key)
                    last_route_request = time.monotonic()
                    publish(route=route, status="navigating", route_distance_m=route["distance_m"],
                            route_duration_s=route["duration_s"], instruction="Route ready; follow the next step")

                progress = progress_for_location(route, lat, lon, geometry_index)
                geometry_index = progress["geometry_index"]
                step_index = progress["step_index"]
                step = route["steps"][step_index]
                distance_to_step = progress["distance_to_step_m"]
                spoken_instruction = instruction_malayalam(
                    step["instruction"], progress.get("announce_distance_m", 0.0)
                )
                # Conservative off-route signal. Do not silently choose a new direction;
                # a caller can explicitly request a reroute after verifying location.
                nearest_distance = _haversine_m((lat, lon), route["geometry"][geometry_index])
                off_route_hits = off_route_hits + 1 if nearest_distance > 45 else 0
                if off_route_hits >= 3:
                    publish(status="off_route", instruction="Possibly off route; stop and verify location before rerouting",
                            error="GPS is consistently more than 45 m from the planned route")
                else:
                    step_changed = step_index != state.get("step_index")
                    speech_path = state.get("speech_path") if not step_changed else None
                    if prepare_speech and step_index != prepared_step_index:
                        try:
                            speech_path = str(prepare_speech(spoken_instruction))
                            prepared_step_index = step_index
                        except Exception as exc:
                            print(f"Could not prepare route speech: {exc}", flush=True)
                    publish(status="navigating", instruction=spoken_instruction,
                            instruction_en=step["instruction"], step_index=step_index,
                            distance_to_step_m=distance_to_step, last_gps_time=time.time(),
                            speech_path=speech_path, step_changed=step_changed, error=None)
            except Exception as exc:  # Keep camera detection running if routing has a problem.
                publish(status="route_error", error=str(exc), instruction="Route unavailable; camera detection continues")
                route = None
                state["stop"].wait(min(5.0, poll_seconds * 3))
            state["stop"].wait(poll_seconds)

    thread = threading.Thread(target=worker, name="osm-route-progress", daemon=True)
    state["thread"] = thread
    thread.start()
    return state


def navigation_snapshot(state):
    """Return a copy of public status fields, safe to poll from the camera loop."""
    with state["lock"]:
        return {key: value for key, value in state.items() if key not in {"lock", "stop", "thread"}}


def stop_navigation(state, timeout=2.0):
    """Stop the background route worker cleanly."""
    state["stop"].set()
    thread = state.get("thread")
    if thread and thread.is_alive():
        thread.join(timeout=timeout)


# Models and generated speech
APP_DIR = Path(__file__).resolve().parent
POTHOLE_MODEL_PATH = APP_DIR / "runs/detect/pothole_yolo26/weights/best.pt"
COCO_MODEL_PATH = APP_DIR / "yolo26n.pt"
OPEN_VOCAB_MODEL = "yolov8s-worldv2.pt"
ENABLE_OPEN_VOCAB = os.getenv("NETHRA_ENABLE_OPEN_VOCAB", "1").strip().lower() not in {"0", "false", "no"}
TTS_CACHE_DIR = APP_DIR / ".nethra_tts_cache"
TTS_LANGUAGE = "ml-IN"
EDGE_TTS_VOICE = os.getenv("NETHRA_TTS_VOICE", "ml-IN-SobhanaNeural").strip()
TTS_PROVIDER = "edge-tts+gtts-fallback"
STARTUP_TEXT = "നെത്രവഴി പ്രവർത്തനം തുടങ്ങി. മുന്നറിയിപ്പുകൾ ശ്രദ്ധിക്കുക."
SAFETY_STOP_TEXT = "നിൽക്കൂ. മുന്നോട്ട് പോകരുത്. ചൂരൽ ഉപയോഗിച്ച് വഴി പരിശോധിക്കുക."
SAFE_CAUTION_TEXT = "നിൽക്കൂ. മുന്നിൽ ഒരു തടസ്സം കണ്ടെത്തി. ചൂരൽ ഉപയോഗിച്ച് പരിശോധിക്കുക."
SAFE_CLEAR_TEXT = "പിന്തുണയ്ക്കുന്ന തടസ്സം കണ്ടെത്തിയില്ല. ക്യാമറയ്ക്ക് വഴി സുരക്ഷിതമാണെന്ന് ഉറപ്പിക്കാൻ കഴിയില്ല. ചൂരൽ ഉപയോഗിച്ച് പരിശോധിച്ച് മാത്രം നീങ്ങുക."
POTHOLE_TEXT = "നിൽക്കൂ. മുന്നിൽ കുഴി കണ്ടെത്തി. മുന്നോട്ട് പോകരുത്. ചൂരൽ ഉപയോഗിച്ച് പരിശോധിക്കുക."
STAIRS_TEXT = "നിൽക്കൂ. മുന്നിൽ പടികൾ ഉണ്ടായേക്കാം. മുന്നോട്ട് പോകരുത്. ചൂരൽ ഉപയോഗിച്ച് പരിശോധിക്കുക."
FRONT_BLOCKED_TEXT = "നിൽക്കൂ. മുന്നിൽ തടസ്സം ഉണ്ടായേക്കാം. നിങ്ങൾ നിശ്ചലമായി നിൽക്കുക. വഴി പരിശോധിക്കാൻ ക്യാമറ മാത്രം പതുക്കെ ഇടത്തോട്ടോ വലത്തോട്ടോ തിരിക്കുക. ഇത് വഴി സുരക്ഷിതമാണെന്ന് ഉറപ്പാക്കുന്നില്ല."
BOTH_SIDES_TEXT = "നിൽക്കൂ. ഇടത്തും വലത്തും തടസ്സങ്ങൾ കണ്ടെത്തി. മുന്നോട്ട് പോകരുത്."
LEFT_TEXT = "നിൽക്കൂ. ഇടത് വശം തടസ്സപ്പെട്ടിരിക്കുന്നു. വലത് വശം ചൂരൽ കൊണ്ട് പരിശോധിക്കുക. വഴി ചൂരൽ കൊണ്ട് സുരക്ഷിതമാണെന്ന് ഉറപ്പായാൽ മാത്രം വലത്തേക്ക് നീങ്ങുക."
RIGHT_TEXT = "നിൽക്കൂ. വലത് വശം തടസ്സപ്പെട്ടിരിക്കുന്നു. ഇടത് വശം ചൂരൽ കൊണ്ട് പരിശോധിക്കുക. വഴി ചൂരൽ കൊണ്ട് സുരക്ഷിതമാണെന്ന് ഉറപ്പായാൽ മാത്രം ഇടത്തേക്ക് നീങ്ങുക."
HELP_TEXT = "ഐ അമർത്തിയാൽ നിലവിലെ മുന്നറിയിപ്പ് വീണ്ടും കേൾക്കാം. ക്യു അമർത്തിയാൽ അടയ്ക്കാം."
PAUSE_TEXT = "സാധാരണ ശബ്ദ അറിയിപ്പുകൾ നിർത്തി."
RESUME_TEXT = "സാധാരണ ശബ്ദ അറിയിപ്പുകൾ വീണ്ടും തുടങ്ങി."

# Camera and detector settings
CAMERA_INDEX = 0
FRAME_SIZE = (416, 312)
INFERENCE_SIZE = 416
PROCESS_EVERY_N_FRAMES = 3
OPEN_VOCAB_EVERY_N_CYCLES = 3
COCO_MODEL_CONFIDENCE = 0.15  # Per-class thresholds below decide what is trusted.
COCO_CONFIDENCE = 0.55
PERSON_CONFIDENCE = 0.78  # Higher threshold reduces shirt/poster false positives.
CHAIR_MIN_CONFIDENCE = 0.45
POTHOLE_CONFIDENCE = 0.70
MIN_CONFIRM_FRAMES = 2
PERSON_CONFIRM_FRAMES = 3
OPEN_VOCAB_CONFIRM_FRAMES = 3
OPEN_VOCAB_MIN_CONFIDENCE = 0.45
TRACK_IOU_MIN = 0.12
TRACK_CENTER_MAX = 0.035
OPEN_VOCAB_LABELS = [
    ("stairs", "staircase or steps"),
    ("curb", "road curb"),
    ("ramp", "ramp"),
    ("traffic cone", "traffic cone"),
    ("bollard", "bollard"),
    ("road barrier", "road barrier"),
    ("doorway", "open doorway"),
    ("glass door", "glass door"),
    ("pole", "street pole"),
    ("wall", "wall directly in front of the camera"),
]
OPEN_VOCAB_PROMPTS = [prompt for _, prompt in OPEN_VOCAB_LABELS]
COCO_HAZARD_CLASSES = {
    "person", "bicycle", "motorcycle", "car", "bus", "truck",
    "traffic light", "stop sign", "bench", "chair", "couch",
    "dining table", "potted plant", "dog", "cat", "backpack", "umbrella",
    "handbag", "suitcase", "skateboard", "fire hydrant", "parking meter",
    "sports ball", "vase", "refrigerator", "oven", "sink", "toilet", "tv", "laptop",
}
MALAYALAM_NAMES = {
    "person": "ആൾ", "bicycle": "സൈക്കിൾ", "motorcycle": "മോട്ടോർ സൈക്കിൾ",
    "car": "കാർ", "bus": "ബസ്", "truck": "ട്രക്ക്",
    "traffic light": "ട്രാഫിക് ലൈറ്റ്", "stop sign": "സ്റ്റോപ്പ് ബോർഡ്",
    "bench": "ബെഞ്ച്", "chair": "കസേര", "couch": "സോഫ",
    "dining table": "മേശ", "potted plant": "ചെടിച്ചട്ടി", "dog": "നായ",
    "cat": "പൂച്ച", "backpack": "ബാക്ക്പാക്ക്", "umbrella": "കുട",
    "handbag": "ഹാൻഡ് ബാഗ്", "suitcase": "സ്യൂട്ട്കേസ്",
    "skateboard": "സ്കേറ്റ്ബോർഡ്", "fire hydrant": "ഫയർ ഹൈഡ്രന്റ്",
    "pothole": "കുഴി", "obstacle": "തടസ്സം",
    "stairs": "പടികൾ", "curb": "റോഡിന്റെ അരിക്", "ramp": "ചരിവുള്ള പാത",
    "traffic cone": "ട്രാഫിക് കോൺ", "bollard": "തടയുതൂൺ",
    "road barrier": "വഴി തടയണ", "doorway": "വാതിൽപ്പടി",
    "glass door": "ഗ്ലാസ് വാതിൽ", "pole": "തൂൺ", "wall": "മതിൽ",
    "parking meter": "പാർക്കിംഗ് മീറ്റർ", "sports ball": "പന്ത്",
    "vase": "പൂച്ചട്ടി", "refrigerator": "ഫ്രിഡ്ജ്", "oven": "ഓവൻ",
    "sink": "സിങ്ക്", "toilet": "ടോയ്ലറ്റ്", "tv": "ടിവി", "laptop": "ലാപ്ടോപ്പ്",
}

# Guidance thresholds: these image ratios are not real-world distances.
CENTER_LEFT_RATIO = 0.30
CENTER_RIGHT_RATIO = 0.70
CLOSE_BOTTOM_RATIO = 0.82
CLOSE_OBJECT_AREA_RATIO = 0.035
CLOSE_POTHOLE_AREA_RATIO = 0.010
ALERT_COOLDOWN_SECONDS = 0.35
REPEAT_ALERT_COOLDOWN_SECONDS = 3.0
URGENT_REPEAT_COOLDOWN_SECONDS = 0.75

# Runtime audio state. TTS is generated once at startup; there is no worker/queue.
pygame_module = None
mixer_ready = False
last_spoken_key = None
last_tts_text = None
last_tts_time = 0.0
routine_speech_paused = False
edge_tts_error_reported = False


def is_reliable_coco_detection(name, confidence):
    """Filter weak detections; person claims require notably higher confidence."""
    label = str(name).strip().lower()
    if label not in COCO_HAZARD_CLASSES:
        return False
    threshold = PERSON_CONFIDENCE if label == "person" else (
        CHAIR_MIN_CONFIDENCE if label == "chair" else COCO_CONFIDENCE
    )
    return float(confidence) >= threshold


def get_class_name(names, class_id):
    try:
        return str(names[class_id])
    except (IndexError, KeyError, TypeError):
        return str(class_id)


def safer_object_label(name):
    """Retain the detector class for a specific alert; uncertainty is phrased in speech."""
    return str(name).strip().lower()


def box_iou(first, second):
    """Intersection-over-union for boxes in pixel coordinates."""
    left, top = max(first[0], second[0]), max(first[1], second[1])
    right, bottom = min(first[2], second[2]), min(first[3], second[3])
    intersection = max(0, right - left) * max(0, bottom - top)
    area_a = max(0, first[2] - first[0]) * max(0, first[3] - first[1])
    area_b = max(0, second[2] - second[0]) * max(0, second[3] - second[1])
    union = area_a + area_b - intersection
    return intersection / union if union else 0.0


def confirm_detections(hazards, previous_tracks):
    """Only return an object after stable, one-to-one matches across frames."""
    next_tracks = []
    used_tracks = set()
    confirmed = []

    for hazard in hazards:
        label = "pothole" if hazard.get("is_pothole") else str(hazard.get("label", "obstacle")).lower()
        box = hazard["box"]
        center_x = (box[0] + box[2]) / 2
        candidates = []
        for index, track in enumerate(previous_tracks):
            if index in used_tracks or track["label"] != label:
                continue
            old_box = track["box"]
            old_center = (old_box[0] + old_box[2]) / 2
            center_delta = abs(center_x - old_center) / max(1, hazard["frame_width"])
            overlap = box_iou(box, old_box)
            if overlap >= TRACK_IOU_MIN or center_delta <= TRACK_CENTER_MAX:
                candidates.append((1.0 - overlap + center_delta, index, track))

        if candidates:
            _, index, prior = min(candidates, key=lambda item: item[0])
            used_tracks.add(index)
            frames_seen = prior["frames_seen"] + 1
        else:
            frames_seen = 1

        track = {
            "label": label, "box": box, "frames_seen": frames_seen,
            "open_vocab": bool(hazard.get("open_vocab")), "missed": 0,
        }
        next_tracks.append(track)
        if hazard.get("open_vocab") or label == "person":
            required = OPEN_VOCAB_CONFIRM_FRAMES if hazard.get("open_vocab") else PERSON_CONFIRM_FRAMES
        else:
            required = MIN_CONFIRM_FRAMES
        hazard["frames_seen"] = frames_seen
        hazard["confirmed"] = frames_seen >= required
        if hazard["confirmed"]:
            confirmed.append(hazard)

    for index, track in enumerate(previous_tracks):
        if index in used_tracks or not track.get("open_vocab"):
            continue
        missed = track.get("missed", 0) + 1
        if missed < OPEN_VOCAB_EVERY_N_CYCLES:
            next_tracks.append({**track, "missed": missed})

    return confirmed, next_tracks


def make_hazard(x1, y1, x2, y2, frame_width, frame_height,
                is_pothole=False, label="object"):
    width = max(0, x2 - x1)
    height = max(0, y2 - y1)
    return {
        "center_x": (x1 + x2) / 2,
        "box": (int(x1), int(y1), int(x2), int(y2)),
        "frame_width": frame_width,
        "bottom_ratio": max(0, min(1, y2 / max(1, frame_height))),
        "area_ratio": width * height / max(1, frame_width * frame_height),
        "is_pothole": is_pothole,
        "label": label,
    }


def hazard_priority(hazard):
    """Higher score means warn sooner; image cues are not a real distance estimate."""
    pothole = bool(hazard.get("is_pothole"))
    bottom = float(hazard.get("bottom_ratio", 0.0))
    area = float(hazard.get("area_ratio", 0.0))
    confidence = float(hazard.get("confidence", 0.0))
    proximity_bonus = {"near": 120, "approaching": 45}.get(hazard.get("proximity"), 0)
    # A low, large object is more immediately relevant in a forward-facing view.
    return proximity_bonus + (100 if pothole else 0) + 45 * bottom + 30 * area + 10 * confidence


def proximity_band(hazard):
    """Return a visual cue only. Monocular pixels cannot provide meters."""
    bottom = float(hazard.get("bottom_ratio", 0.0))
    area = float(hazard.get("area_ratio", 0.0))
    is_pothole = bool(hazard.get("is_pothole"))
    close_area = CLOSE_POTHOLE_AREA_RATIO if is_pothole else CLOSE_OBJECT_AREA_RATIO
    if bottom >= CLOSE_BOTTOM_RATIO and area >= close_area:
        return "near"
    if bottom >= 0.58 or area >= close_area * 0.45:
        return "approaching"
    return "visible"


def aggregate_hazards(hazards, frame_width):
    """Keep every detection, rank each side, and summarize without merging objects."""
    state = {
        "left": False, "right": False, "center": False,
        "left_pothole": False, "right_pothole": False,
        "center_close": False, "center_pothole_close": False,
        "left_label": None, "right_label": None, "center_label": None,
        "left_approaching": False, "right_approaching": False,
        "center_approaching": False,
        "left_approaching_label": None, "right_approaching_label": None,
        "center_approaching_label": None,
        "left_count": 0, "right_count": 0, "center_count": 0,
        "objects": [],
    }
    if frame_width <= 0:
        return state

    grouped = {"left": [], "center": [], "right": []}
    for hazard in hazards:
        x = float(hazard.get("center_x", 0.0))
        side = ("left" if x < frame_width * CENTER_LEFT_RATIO else
                "right" if x > frame_width * CENTER_RIGHT_RATIO else "center")
        item = dict(hazard)
        item["side"] = side
        item["label"] = "pothole" if item.get("is_pothole") else str(item.get("label", "obstacle")).lower()
        item["proximity"] = proximity_band(item)
        item["priority"] = hazard_priority(item)
        grouped[side].append(item)
        state["objects"].append(item)

    for side, items in grouped.items():
        if not items:
            continue
        items.sort(key=lambda item: item["priority"], reverse=True)
        lead = items[0]
        state[side] = True
        state[f"{side}_count"] = len(items)
        state[f"{side}_label"] = lead["label"]
        state[f"{side}_pothole"] = any(item.get("is_pothole") for item in items)
        state[f"{side}_approaching"] = any(item.get("approaching") for item in items)
        approaching = next((item for item in items if item.get("approaching")), None)
        state[f"{side}_approaching_label"] = approaching["label"] if approaching else None
        if side == "center":
            state["center_close"] = any(item["proximity"] == "near" for item in items)
            state["center_pothole_close"] = any(
                item.get("is_pothole") and item["proximity"] == "near" for item in items
            )
    state["objects"].sort(key=lambda item: item["priority"], reverse=True)
    return state


def choose_guidance(state):
    """Warn for the highest visual risk; suggest a side only after cane verification."""
    objects = state.get("objects", [])
    if not objects:
        return "clear", "No supported obstacle detected; check with cane; route is not confirmed clear"

    most_urgent = max(objects, key=lambda item: item.get("priority", 0))
    if most_urgent.get("proximity") == "near" and most_urgent.get("is_pothole"):
        if most_urgent.get("side") == "center":
            return "pothole_ahead", "STOP - Close pothole visually detected ahead; cane-check"
        side = most_urgent["side"]
        return f"obstacle_{side}", f"STOP - Close pothole on {side}; check opposite side with cane"
    if most_urgent.get("label") == "stairs" and most_urgent.get("side") == "center":
        return "stairs_ahead", "STOP - Possible stairs ahead; confirm with cane/guide"
    if most_urgent.get("proximity") in {"near", "approaching"}:
        side = most_urgent.get("side")
        label = str(most_urgent.get("label", "obstacle")).title()
        if side in {"left", "right"}:
            opposite = "right" if side == "left" else "left"
            cue = "Near" if most_urgent.get("proximity") == "near" else "Approaching"
            return f"obstacle_{side}", f"STOP - {cue} {label} on {side}; cane-check {opposite}, move only if verified clear"
        cue = "Near" if most_urgent.get("proximity") == "near" else "Approaching"
        return "front_blocked", f"STOP - {cue} {label} ahead; cane-check both sides and move only toward a side verified clear"
    if state.get("center"):
        label = (state.get("center_label") or "object").title()
        count = state.get("center_count", 1)
        return "front_blocked", f"STOP - {count} {label} object(s) ahead; hold position and slowly scan camera left/right"
    if state.get("left") and state.get("right"):
        return "both_sides", (f"STOP - Obstacles both sides "
                               f"(left {state['left_count']}, right {state['right_count']})")
    if state.get("left") or state.get("right"):
        side = "left" if state.get("left") else "right"
        opposite = "right" if side == "left" else "left"
        count = state.get(f"{side}_count", 1)
        label = (state.get(f"{side}_label") or "obstacle").title()
        key = f"obstacle_{side}"
        return key, f"STOP - {count} confirmed {label} object(s) on {side}; cane-check {opposite} and move only if verified clear"
    return "clear", "No supported obstacle detected; check with cane; route is not confirmed clear"


def side_alert_message(label, blocked_side):
    """Name the detected object and never imply the opposite side is clear."""
    object_name = MALAYALAM_NAMES.get(label, MALAYALAM_NAMES["obstacle"])
    blocked_ml, other_ml, move_ml = (
        ("ഇടത്", "വലത്", "വലത്തേക്ക്") if blocked_side == "left"
        else ("വലത്", "ഇടത്", "ഇടത്തേക്ക്")
    )
    uncertainty = " ഉണ്ടായേക്കാം" if label in {"person", "traffic light"} or label in {item for item, _ in OPEN_VOCAB_LABELS} else ""
    return (
        f"നിൽക്കൂ. {blocked_ml} വശത്ത് {object_name}{uncertainty}. "
        f"{other_ml} വശം ചൂരൽ കൊണ്ട് പരിശോധിക്കുക. "
        f"ചൂരൽ വഴി സുരക്ഷിതമാണെന്ന് ഉറപ്പാക്കിയാൽ മാത്രം {move_ml} നീങ്ങുക."
    )


def front_alert_message(label):
    """Warn by name in front; never pick a direction without cane confirmation."""
    object_name = MALAYALAM_NAMES.get(label, MALAYALAM_NAMES["obstacle"])
    uncertainty = " ഉണ്ടായേക്കാം" if label in {"person", "traffic light"} or label in {item for item, _ in OPEN_VOCAB_LABELS} else ""
    return (
        f"നിൽക്കൂ. മുന്നിൽ {object_name}{uncertainty}. ഇടത്തും വലത്തും ചൂരൽ കൊണ്ട് പരിശോധിക്കുക. "
        "ചൂരൽ വഴി സുരക്ഷിതമാണെന്ന് ഉറപ്പാക്കിയ വശത്തേക്ക് മാത്രം നീങ്ങുക."
    )


def all_named_alert_messages():
    labels = set(COCO_HAZARD_CLASSES) | {name for name, _ in OPEN_VOCAB_LABELS} | {"pothole", "obstacle"}
    return [
        *(side_alert_message(label, side) for label in sorted(labels) for side in ("left", "right")),
        *(front_alert_message(label) for label in sorted(labels)),
    ]


def make_spoken_message(state, key):
    """Choose a short, pre-generated Malayalam sentence; never voice a guess as fact."""
    if key == "clear":
        return SAFE_CLEAR_TEXT
    if key == "obstacle_left":
        return side_alert_message(state.get("left_label") or "obstacle", "left")
    if key == "obstacle_right":
        return side_alert_message(state.get("right_label") or "obstacle", "right")
    if key == "front_blocked" and state.get("center_label"):
        return front_alert_message(state["center_label"])
    if key == "stairs_ahead":
        return front_alert_message("stairs")
    if key == "pothole_ahead":
        return front_alert_message("pothole")
    if key in {"caution", "stop", "obstacle_left", "obstacle_right"}:
        side = "left" if key == "obstacle_left" else "right" if key == "obstacle_right" else "center"
        label = state.get(f"{side}_label")
        if label:
            malayalam_label = MALAYALAM_NAMES.get(label, "തടസ്സം")
            uncertainty = " ഉണ്ടായേക്കാം" if label == "person" or label in {name for name, _ in OPEN_VOCAB_LABELS} else ""
            return f"നിൽക്കൂ. {malayalam_label}{uncertainty} കണ്ടെത്തി. മുന്നോട്ട് പോകരുത്. ചൂരൽ ഉപയോഗിച്ച് പരിശോധിക്കുക."
    messages = {
        "pothole_ahead": POTHOLE_TEXT,
        "stairs_ahead": STAIRS_TEXT,
        "front_blocked": FRONT_BLOCKED_TEXT,
        "clear": SAFE_CLEAR_TEXT,
        "stop": SAFETY_STOP_TEXT,
        "caution": SAFE_CAUTION_TEXT,
        "both_sides": BOTH_SIDES_TEXT,
        "obstacle_left": LEFT_TEXT,
        "obstacle_right": RIGHT_TEXT,
        "safety_stop": SAFETY_STOP_TEXT,
        "system_ready": STARTUP_TEXT,
        "user_command": HELP_TEXT,
        "pause": PAUSE_TEXT,
        "resume": RESUME_TEXT,
    }
    return messages.get(key, SAFE_CAUTION_TEXT)


def alert_priority(key):
    priorities = {
        "safety_stop": 150, "pothole_ahead": 145, "stairs_ahead": 140,
        "front_blocked": 138, "both_sides": 130,
        "stop": 125, "system_ready": 90, "user_command": 80,
        "caution": 80, "obstacle_left": 75, "obstacle_right": 75,
        "pause": 70, "resume": 70, "route_instruction": 20, "clear": 10,
    }
    if key and key.startswith("pothole_"):
        return 70
    return priorities.get(key, 0)


def alert_direction(key):
    if key and key.endswith("_left"):
        return "left"
    if key and key.endswith("_right"):
        return "right"
    return None


def select_alert_during_playback(current, requested, audio_busy=True):
    """Do not cut routine audio; interrupt only for STOP or conflicting directions."""
    if not requested:
        return None
    if not audio_busy or not current:
        return requested
    if current == requested:
        return None

    old_direction = alert_direction(current)
    new_direction = alert_direction(requested)
    if old_direction and new_direction and old_direction != new_direction:
        return "stop"
    if alert_priority(requested) > alert_priority(current) and alert_priority(requested) > 0:
        return requested
    return None


def is_urgent_alert(key):
    return alert_priority(key) >= 120


def init_audio():
    global pygame_module, mixer_ready
    try:
        import pygame
        pygame.mixer.init()
        pygame_module = pygame
        mixer_ready = True
    except Exception as exc:
        print(f"Audio is required; Nethra Vazhi will not start: {exc}")
    return mixer_ready


def tts_cache_path(text):
    profile = f"{TTS_PROVIDER}|{EDGE_TTS_VOICE}|{TTS_LANGUAGE}"
    digest = sha256(f"{profile}\0{text}".encode("utf-8")).hexdigest()
    return TTS_CACHE_DIR / f"{digest}.mp3"


async def _stream_edge_audio(text):
    import edge_tts

    speech = edge_tts.Communicate(text, EDGE_TTS_VOICE)
    chunks = []
    async for chunk in speech.stream():
        if chunk.get("type") == "audio":
            chunks.append(chunk["data"])
    return b"".join(chunks)


def generate_edge_audio(text):
    """Use Microsoft's online Edge speech voice without an API key."""
    return asyncio.run(_stream_edge_audio(text))


def generate_gtts_audio(text):
    from io import BytesIO
    from gtts import gTTS

    buffer = BytesIO()
    gTTS(text=text, lang="ml", tld="co.in", lang_check=False,
         timeout=(4, 8)).write_to_fp(buffer)
    return buffer.getvalue()


def generate_tts_audio(text):
    """Try Edge TTS, then gTTS. Called only while preparing startup audio."""
    global edge_tts_error_reported
    if not edge_tts_error_reported:
        try:
            audio = generate_edge_audio(text)
            if audio:
                return audio
            raise RuntimeError("Edge TTS returned no audio")
        except Exception as exc:
            print(f"Edge TTS unavailable; switching to gTTS fallback: {exc}")
            edge_tts_error_reported = True
    audio = generate_gtts_audio(text)
    if not audio:
        raise RuntimeError("TTS provider returned empty audio")
    return audio


def write_tts_cache(text):
    TTS_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    output = tts_cache_path(text)
    if output.is_file():
        return output
    temporary = output.with_name(output.stem + ".tmp.mp3")
    temporary.write_bytes(generate_tts_audio(text))
    temporary.replace(output)
    return output


def warm_required_speech():
    """Prepare core warnings and named opposite-side alerts before monitoring."""
    messages = [
        STARTUP_TEXT, SAFETY_STOP_TEXT, SAFE_CAUTION_TEXT,
        POTHOLE_TEXT, STAIRS_TEXT, FRONT_BLOCKED_TEXT, BOTH_SIDES_TEXT, LEFT_TEXT, RIGHT_TEXT,
        SAFE_CLEAR_TEXT, HELP_TEXT,
        PAUSE_TEXT, RESUME_TEXT,
    ]
    messages = tuple(dict.fromkeys(messages))
    total = len(messages)
    for index, text in enumerate(messages, start=1):
        try:
            print(f"Preparing safety voice {index}/{total}...", flush=True)
            write_tts_cache(text)
        except Exception as exc:
            print(f"Cannot prepare Malayalam safety speech; app will not start: {exc}")
            return False

    named_messages = all_named_alert_messages()
    total_named = len(named_messages)
    failed_named = 0
    for index, text in enumerate(named_messages, start=1):
        try:
            print(f"Preparing named object alert {index}/{total_named}...", flush=True)
            write_tts_cache(text)
        except Exception as exc:
            failed_named += 1
            print(f"Named alert {index}/{total_named} unavailable; generic safety voice will be used: {exc}", flush=True)
    print(f"Named object alerts ready: {total_named - failed_named}/{total_named}", flush=True)
    return True


def play_tts(key, text, path, explicit=False):
    """Play a cached warning; never start network TTS inside the camera loop."""
    global last_spoken_key, last_tts_text, last_tts_time
    if not mixer_ready or not path.is_file():
        return False
    try:
        busy = pygame_module.mixer.music.get_busy()
        selected = select_alert_during_playback(last_spoken_key, key, busy)
        if busy and key == last_spoken_key and text != last_tts_text:
            selected = key
        if selected == "stop" and key != "stop":
            path = tts_cache_path(SAFETY_STOP_TEXT)
            key, text = "safety_stop", SAFETY_STOP_TEXT
        elif selected is None or selected != key:
            return True

        now = time.monotonic()
        if not explicit and text == last_tts_text:
            cooldown = URGENT_REPEAT_COOLDOWN_SECONDS if is_urgent_alert(key) else REPEAT_ALERT_COOLDOWN_SECONDS
            if now - last_tts_time < cooldown:
                return True
        elif not explicit and not is_urgent_alert(key) and now - last_tts_time < ALERT_COOLDOWN_SECONDS:
            return True

        pygame_module.mixer.music.stop()
        pygame_module.mixer.music.load(str(path))
        pygame_module.mixer.music.play()
        last_spoken_key, last_tts_text, last_tts_time = key, text, now
        return True
    except Exception as exc:
        print(f"Audio playback error: {exc}")
        return False


def speak_cached_safety_stop():
    path = tts_cache_path(SAFETY_STOP_TEXT)
    if path.is_file() and mixer_ready:
        play_tts("safety_stop", SAFETY_STOP_TEXT, path)


def speak_guidance(key, state):
    """Play a prepared warning for a confirmed scene; no runtime synthesis."""
    if not key or not mixer_ready:
        return
    if routine_speech_paused and not is_urgent_alert(key):
        return
    text = make_spoken_message(state, key)
    path = tts_cache_path(text)
    if not path.is_file():
        text = FRONT_BLOCKED_TEXT if key == "front_blocked" else SAFE_CAUTION_TEXT
        path = tts_cache_path(text)
    if path.is_file():
        play_tts(key, text, path)


def handle_control_key(code, current_key, current_state):
    global routine_speech_paused
    if code == ord("i") and current_key:
        speak_guidance(current_key, current_state)
    elif code == ord("h"):
        text = HELP_TEXT
        play_tts("user_command", text, tts_cache_path(text), explicit=True)
    elif code == ord("p"):
        routine_speech_paused = not routine_speech_paused
        key = "pause" if routine_speech_paused else "resume"
        text = PAUSE_TEXT if routine_speech_paused else RESUME_TEXT
        play_tts(key, text, tts_cache_path(text), explicit=True)


def shutdown_audio():
    global mixer_ready
    if mixer_ready and pygame_module:
        try:
            pygame_module.mixer.music.stop()
            pygame_module.mixer.quit()
        except Exception:
            pass
    mixer_ready = False


def draw_box(cv2, image, box, label, color):
    x1, y1, x2, y2 = box
    cv2.rectangle(image, (x1, y1), (x2, y2), color, 2)
    cv2.putText(image, label, (x1, max(18, y1 - 6)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)


def process_detections(frame, coco_result, pothole_result, coco_names, open_vocab_result=None):
    """Collect only high-confidence candidates; confirmation happens separately."""
    height, width = frame.shape[:2]
    hazards = []

    for box in getattr(coco_result, "boxes", []) or []:
        class_id = int(box.cls[0])
        name = get_class_name(coco_names, class_id).strip().lower()
        confidence = float(box.conf[0])
        if not is_reliable_coco_detection(name, confidence):
            continue
        coords = tuple(map(int, box.xyxy[0]))
        label = safer_object_label(name)
        hazard = make_hazard(*coords, width, height, label=label)
        hazard["confidence"] = confidence
        hazards.append(hazard)

    for box in getattr(pothole_result, "boxes", []) or []:
        confidence = float(box.conf[0])
        if confidence < POTHOLE_CONFIDENCE:
            continue
        coords = tuple(map(int, box.xyxy[0]))
        hazard = make_hazard(*coords, width, height, True, "pothole")
        hazard["confidence"] = confidence
        hazards.append(hazard)

    for box in getattr(open_vocab_result, "boxes", []) or []:
        confidence = float(box.conf[0])
        if confidence < OPEN_VOCAB_MIN_CONFIDENCE:
            continue
        class_id = int(box.cls[0])
        if not 0 <= class_id < len(OPEN_VOCAB_LABELS):
            continue
        label = OPEN_VOCAB_LABELS[class_id][0]
        coords = tuple(map(int, box.xyxy[0]))
        hazard = make_hazard(*coords, width, height, label=label)
        hazard["confidence"] = confidence
        hazard["open_vocab"] = True
        hazards.append(hazard)

    return hazards


def draw_detections(frame, hazards, cv2):
    """Show pending boxes as yellow; confirmed boxes as green."""
    image = frame.copy()
    for hazard in hazards:
        confirmed = hazard.get("confirmed", False)
        label = hazard["label"]
        if label == "person":
            label = "possible person?"
        elif hazard.get("open_vocab"):
            label = f"possible {label}?"
        state = "confirmed" if confirmed else f"checking {hazard.get('frames_seen', 1)}"
        color = (0, 200, 0) if confirmed else (0, 220, 255)
        draw_box(cv2, image, hazard["box"],
                 f"{label} {hazard.get('confidence', 0):.2f} {state}", color)
    return image


def run():
    try:
        import cv2
        from ultralytics import YOLO
    except ImportError as exc:
        print(f"Required package unavailable: {exc}")
        return 2

    if not init_audio():
        return 2
    camera = None
    navigation = None
    location_cleanup = None
    try:
        camera = cv2.VideoCapture(CAMERA_INDEX)
        camera.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        if not camera.isOpened():
            raise RuntimeError(f"Could not open camera {CAMERA_INDEX}")
        loading = __import__("numpy").zeros((FRAME_SIZE[1], FRAME_SIZE[0], 3), dtype="uint8")
        cv2.putText(loading, "Starting Nethra Vazhi...", (18, 42),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)
        cv2.putText(loading, "Preparing safety audio and models", (18, 78),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.48, (0, 220, 255), 1)
        cv2.imshow("Nethra Vazhi", loading)
        cv2.waitKey(1)

        if not warm_required_speech():
            return 2
        for model_path in (POTHOLE_MODEL_PATH, COCO_MODEL_PATH):
            if not model_path.is_file():
                raise FileNotFoundError(f"Model not found: {model_path}")

        coco_model = YOLO(str(COCO_MODEL_PATH))
        pothole_model = YOLO(str(POTHOLE_MODEL_PATH))
        open_vocab_model = None
        if ENABLE_OPEN_VOCAB:
            try:
                from ultralytics import YOLOWorld
                open_vocab_model = YOLOWorld(OPEN_VOCAB_MODEL)
                open_vocab_model.set_classes(OPEN_VOCAB_PROMPTS)
                print("Open-vocabulary hazards enabled:", ", ".join(label for label, _ in OPEN_VOCAB_LABELS))
            except Exception as exc:
                print(f"Open-vocabulary model unavailable; stairs and custom prompts are off: {exc}")
        play_tts("system_ready", STARTUP_TEXT, tts_cache_path(STARTUP_TEXT), explicit=True)
        route_state = os.getenv("NETHRA_ENABLE_OSM", "").strip().lower()
        route_enabled = route_state in {"1", "true", "yes"}
        if not route_state and sys.stdin.isatty():
            route_enabled = input("Enable OSM walking directions? [y/N]: ").strip().lower() in {"y", "yes"}
        destination_text = os.getenv("NETHRA_DESTINATION", "").strip()
        if destination_text:
            route_enabled = True
        if route_enabled:
            try:
                api_key = ORS_API_KEY
                if not api_key:
                    raise RuntimeError("Set NETHRA_ORS_API_KEY (free ORS key) to request walking directions")
                location_provider, location_cleanup = load_location_provider()
                if not destination_text:
                    destination_text = input("Enter destination (place name or latitude,longitude): ").strip()
                if not destination_text:
                    raise ValueError("A destination is required to start walking directions")
                destination = choose_place(destination_text, api_key)
                navigation = start_navigation(
                    destination, location_provider, api_key=api_key,
                    prepare_speech=write_tts_cache,
                )
                print("Route origin will be the current GPS location. Walking directions started; detection alerts take priority.")
            except Exception as exc:
                print(f"OSM guidance not started; camera detection continues: {exc}")
        else:
            print("OSM guidance not selected. Set NETHRA_ENABLE_OSM=1 or choose yes at the prompt.")
        previous_tracks = []
        frame_count = 0
        inference_cycle = 0
        last_processed = time.monotonic()
        current_key = None
        current_state = aggregate_hazards([], FRAME_SIZE[0])
        guidance = "Starting detection..."
        shown_frame = None
        last_route_spoken_step = -1
        print("Controls: i=repeat alert, h=help, p=pause/resume routine speech, q=quit")
        print("Person and prompt-hazard alerts require higher confidence and 3 matching frames; movement is never directed by this camera.")

        while True:
            ok, frame = camera.read()
            if not ok or frame is None:
                raise RuntimeError("Camera frame read failed")
            frame = cv2.resize(frame, FRAME_SIZE)
            frame_count += 1

            if frame_count % PROCESS_EVERY_N_FRAMES == 0:
                try:
                    inference_cycle += 1
                    coco = coco_model(frame, conf=COCO_MODEL_CONFIDENCE,
                                      imgsz=INFERENCE_SIZE, max_det=30, verbose=False)[0]
                    pothole = pothole_model(frame, conf=POTHOLE_CONFIDENCE,
                                            imgsz=INFERENCE_SIZE, max_det=20, verbose=False)[0]
                    open_vocab = None
                    if (open_vocab_model is not None and
                            inference_cycle % OPEN_VOCAB_EVERY_N_CYCLES == 0):
                        try:
                            open_vocab = open_vocab_model(
                                frame, conf=OPEN_VOCAB_MIN_CONFIDENCE,
                                imgsz=INFERENCE_SIZE, max_det=20, verbose=False
                            )[0]
                        except Exception as exc:
                            print(f"Open-vocabulary inference failed; disabling it: {exc}")
                            open_vocab_model = None
                    candidates = process_detections(
                        frame, coco, pothole, coco_model.names, open_vocab
                    )
                    confirmed, previous_tracks = confirm_detections(candidates, previous_tracks)
                    confirmed_ids = {id(item) for item in confirmed}
                    for candidate in candidates:
                        candidate["confirmed"] = id(candidate) in confirmed_ids
                    hazard_state = aggregate_hazards(confirmed, frame.shape[1])
                    current_key, guidance = choose_guidance(hazard_state)
                    current_state = hazard_state
                    shown_frame = draw_detections(frame, candidates, cv2)
                    speak_guidance(current_key, current_state)
                    last_processed = time.monotonic()
                except Exception as exc:
                    guidance = "STOP - Detection error; wait and check safely"
                    shown_frame = frame.copy()
                    cv2.putText(shown_frame, str(exc)[:70], (10, 58),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 255), 1)
                    speak_cached_safety_stop()
                    previous_tracks = []
                    print(f"Detection error: {exc}")

            if time.monotonic() - last_processed > 1.5:
                guidance = "STOP - Detection delayed; wait and check safely"
                speak_cached_safety_stop()
            display = shown_frame.copy() if shown_frame is not None else frame.copy()
            cv2.putText(display, guidance, (10, 28), cv2.FONT_HERSHEY_SIMPLEX,
                        0.55, (255, 255, 255), 2)
            cv2.putText(display, f"Confirmed objects: {len(current_state.get('objects', []))}",
                        (10, 54), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (255, 255, 0), 1)
            if navigation is not None:
                route = navigation_snapshot(navigation)
                remaining = route.get("distance_to_step_m")
                distance_text = f" ({round(remaining)} m)" if remaining is not None else ""
                route_text = f"ROUTE [{route['status']}]: {route['instruction']}{distance_text}"
                cv2.putText(display, route_text[:64], (10, 80), cv2.FONT_HERSHEY_SIMPLEX,
                            0.40, (0, 220, 255), 1)
                # Hazards always win. Resume the current route step after the
                # camera no longer reports an approaching/near object.
                no_confirmed_hazard = (
                    current_key in {"clear", "far", None}
                    and not guidance.startswith("STOP")
                    and time.monotonic() - last_processed <= 1.5
                )
                audio_path = route.get("speech_path")
                step_index = route.get("step_index", -1)
                if (no_confirmed_hazard and step_index >= 0 and audio_path and
                        step_index != last_route_spoken_step and not routine_speech_paused):
                    route_text_ml = route.get("instruction", "")
                    play_tts("route_instruction", route_text_ml, Path(audio_path))
                    if last_spoken_key == "route_instruction" and last_tts_text == route_text_ml:
                        last_route_spoken_step = step_index
            cv2.imshow("Nethra Vazhi", display)
            pressed = cv2.waitKey(1) & 0xFF
            if pressed == ord("q"):
                break
            handle_control_key(pressed, current_key, current_state)

    except Exception as exc:
        print(f"Nethra Vazhi stopped safely: {exc}")
        speak_cached_safety_stop()
        return 1
    finally:
        if navigation is not None:
            stop_navigation(navigation)
        if location_cleanup is not None:
            try:
                location_cleanup()
            except Exception as exc:
                print(f"Could not stop location updates cleanly: {exc}")
        if camera is not None:
            camera.release()
        try:
            cv2.destroyAllWindows()
        except Exception:
            pass
        shutdown_audio()
    return 0


if __name__ == "__main__":
    raise SystemExit(run())
