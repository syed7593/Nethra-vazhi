This project came in TWO zip files because of a 25 MB size limit.

Part 2 (appnethravazhi-part2-HazardDetector.zip) holds the largest model.
After unzipping it you get a folder named  HazardDetector.mlpackage

Put that folder here, next to the other two models:

    appnethravazhi/NethraVazhi/Models/HazardDetector.mlpackage

Then open NethraVazhi.xcodeproj in Xcode and run. Xcode will not build until the folder is in place.
