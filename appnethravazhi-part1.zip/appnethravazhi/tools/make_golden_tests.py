"""Generate golden test vectors from the ORIGINAL Python code (nethracam.py / osmmap.py).

The Swift unit tests (NethraVazhiTests) replay these and must produce identical results,
which proves the iPhone port behaves like the desktop Python app.

usage: python3 make_golden_tests.py <folder with nethracam.py & osmmap.py> <output dir>
"""
import base64, json, random, sys, struct
from pathlib import Path

src, out = Path(sys.argv[1]), Path(sys.argv[2])
sys.path.insert(0, str(src))
import nethracam as cam  # noqa: E402
import osmmap as osm     # noqa: E402

FW, FH = 320, 416
rng = random.Random(7)
OPEN = [label for label, _ in cam.OPEN_VOCAB_LABELS]
COCO = sorted(cam.COCO_HAZARD_CLASSES)


def rand_box():
    w = rng.uniform(10, 260); h = rng.uniform(10, 380)
    x1 = rng.uniform(0, FW - w); y1 = rng.uniform(0, FH - h)
    return [x1, y1, x1 + w, y1 + h]


# ---------------------------------------------------------------- detection sequences
detection = []
for seq in range(60):
    objects = []
    for _ in range(rng.randint(0, 4)):
        kind = rng.choice(["coco", "coco", "pothole", "open"])
        label = rng.choice(COCO) if kind == "coco" else ("pothole" if kind == "pothole" else rng.choice(OPEN))
        objects.append({"kind": kind, "label": label, "box": rand_box(), "conf": rng.uniform(0.45, 0.99)})
    tracks, frames = [], []
    for f in range(8):
        cands = []
        for o in objects:
            if rng.random() < 0.15:
                continue  # missed this frame
            dx, dy = rng.uniform(-6, 6), rng.uniform(-4, 8)
            o["box"] = [max(0, o["box"][0] + dx), max(0, o["box"][1] + dy),
                        min(FW, o["box"][2] + dx), min(FH, o["box"][3] + dy)]
            x1, y1, x2, y2 = (int(v) for v in o["box"])
            h = cam.make_hazard(x1, y1, x2, y2, FW, FH, o["kind"] == "pothole", o["label"])
            h["confidence"] = round(o["conf"], 4)
            if o["kind"] == "open":
                h["open_vocab"] = True
            cands.append(h)
        inputs = [{"label": h["label"], "box": list(h["box"]), "conf": h["confidence"],
                   "pothole": bool(h["is_pothole"]), "open": bool(h.get("open_vocab"))} for h in cands]
        confirmed, tracks = cam.confirm_detections(cands, tracks)
        state = cam.aggregate_hazards(confirmed, FW)
        key, display = cam.choose_guidance(state)
        frames.append({
            "inputs": inputs,
            "frames_seen": [h["frames_seen"] for h in cands],
            "confirmed": [bool(h["confirmed"]) for h in cands],
            "objects": [{"label": o["label"], "side": o["side"], "proximity": o["proximity"],
                         "priority": o["priority"]} for o in state["objects"]],
            "key": key, "display": display, "alert_label": state.get("alert_label"),
            "spoken_ml": cam.make_spoken_message(state, key),
        })
    detection.append(frames)

reliable = [{"name": n, "conf": c, "ok": cam.is_reliable_coco_detection(n, c)}
            for n in COCO + ["airplane", "Person ", "chair"] for c in (0.44, 0.46, 0.56, 0.77, 0.79)]

# ---------------------------------------------------------------- speech arbitration (play_tts logic)
KEYS = ["clear", "obstacle_left", "obstacle_right", "front_blocked", "pothole_ahead", "stairs_ahead",
        "safety_stop", "system_ready", "user_command", "pause", "resume"]
SAFETY = "SAFETY"
arb_cases = []
for case in range(40):
    last_key = last_text = None
    last_time = -1e9
    now = 0.0
    events = []
    for _ in range(25):
        now += rng.choice([0.1, 0.2, 0.5, 1.0, 2.0, 4.0, 16.0])
        key = rng.choice(KEYS)
        text = f"{key}-{rng.randint(0, 2)}"
        explicit = rng.random() < 0.15
        busy = rng.random() < 0.5
        # --- verbatim decision logic of nethracam.play_tts (without pygame) ---
        selected = cam.select_alert_during_playback(last_key, key, busy)
        if busy and key == last_key and text != last_text:
            selected = key
        spoke = None
        k, t = key, text
        if selected == "stop" and k != "stop":
            k, t = "safety_stop", SAFETY
            go = True
        elif selected is None or selected != k:
            go = False
        else:
            go = True
        if go:
            if not explicit and t == last_text:
                cooldown = (cam.URGENT_REPEAT_COOLDOWN_SECONDS if cam.is_urgent_alert(k)
                            else cam.CLEAR_REPEAT_COOLDOWN_SECONDS if k == "clear"
                            else cam.REPEAT_ALERT_COOLDOWN_SECONDS)
                go = not (now - last_time < cooldown)
            elif not explicit and not cam.is_urgent_alert(k) and now - last_time < cam.ALERT_COOLDOWN_SECONDS:
                go = False
        if go:
            last_key, last_text, last_time = k, t, now
            spoke = [k, t]
        events.append({"key": key, "text": text, "explicit": explicit, "busy": busy, "now": now, "spoke": spoke})
    arb_cases.append(events)

# ---------------------------------------------------------------- messages
labels = sorted(set(cam.COCO_HAZARD_CLASSES) | set(OPEN) | {"pothole", "obstacle"})
messages = {
    "side": [{"label": l, "side": s, "text": cam.side_alert_message(l, s)} for l in labels for s in ("left", "right")],
    "front": [{"label": l, "text": cam.front_alert_message(l)} for l in labels],
    "core": {"safety_stop": cam.SAFETY_STOP_TEXT, "caution": cam.SAFE_CAUTION_TEXT, "clear": cam.SAFE_CLEAR_TEXT,
             "pause": cam.PAUSE_TEXT, "resume": cam.RESUME_TEXT},
}

# ---------------------------------------------------------------- route
def fake_ors(n_points=60):
    lat, lon = 9.9312, 76.2673  # Kochi
    pts = []
    for i in range(n_points):
        lat += rng.uniform(0.00005, 0.0002) * (1 if i < 30 else 0.3)
        lon += rng.uniform(-0.00005, 0.0002) * (0.3 if i < 30 else 1)
        pts.append([round(lon, 7), round(lat, 7)])
    words = ["Head north on MG Road", "Turn left onto Broadway", "Turn sharp right", "Keep left",
             "Continue straight", "Turn slight right onto Market Road", "Make a U-turn", "Arrive at destination, on the right"]
    cuts = sorted(rng.sample(range(1, n_points - 1), 5))
    bounds = [0] + cuts + [n_points - 1]
    steps = []
    for i in range(len(bounds) - 1):
        steps.append({"instruction": rng.choice(words[:-1]), "distance": round(rng.uniform(20, 300), 1),
                      "duration": round(rng.uniform(10, 200), 1), "type": rng.randint(0, 9),
                      "way_points": [bounds[i], bounds[i + 1]]})
    steps.append({"instruction": words[-1], "distance": 0, "duration": 0, "type": 10,
                  "way_points": [n_points - 1, n_points - 1]})
    return {"type": "FeatureCollection", "features": [{
        "geometry": {"type": "LineString", "coordinates": pts},
        "properties": {"segments": [{"steps": steps}], "summary": {"distance": 1234.5, "duration": 888.0}}}]}

routes = []
for r in range(6):
    data = fake_ors()
    parsed = osm.parse_ors_route(data)
    probes = []
    last = 0
    geo = parsed["geometry"]
    for i in range(0, len(geo), 2):
        lat = geo[i][0] + rng.uniform(-0.0002, 0.0002)
        lon = geo[i][1] + rng.uniform(-0.0002, 0.0002)
        p = osm.progress_for_location(parsed, lat, lon, last)
        probes.append({"lat": lat, "lon": lon, "last": last, **p})
        last = p["geometry_index"]
    routes.append({"ors": data, "steps": [{k: s[k] for k in ("instruction", "distance_m", "start_index", "end_index", "type")}
                                          for s in parsed["steps"]],
                   "distance_m": parsed["distance_m"], "duration_s": parsed["duration_s"],
                   "points": len(geo), "probes": probes})

instr = ["Head north on MG Road", "Turn left onto Broadway", "Turn sharp left", "Turn sharp right", "Keep right",
         "Turn slight left", "Continue straight", "Make a U-turn", "Arrive at destination", "Head east", "Head west",
         "Head south", "Turn right", "Enter the roundabout", "Follow the path", "Walk along the river"]
instructions = [{"text": t, "d": d, "ml": osm.instruction_malayalam(t, d)} for t in instr for d in (0, 9.9, 10, 37.5, 120.5)]
haversine = [{"a": [9.93, 76.26], "b": [9.94, 76.27], "m": osm._haversine_m((9.93, 76.26), (9.94, 76.27))},
             {"a": [0, 0], "b": [0, 1], "m": osm._haversine_m((0, 0), (0, 1))}]

out.mkdir(parents=True, exist_ok=True)
(out / "golden_logic.json").write_text(json.dumps({
    "frame": [FW, FH], "detection": detection, "reliable": reliable, "arbiter": arb_cases,
    "messages": messages, "routes": routes, "instructions": instructions, "haversine": haversine,
}, ensure_ascii=False))
print("wrote", out / "golden_logic.json")
