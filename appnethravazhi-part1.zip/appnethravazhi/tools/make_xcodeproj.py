"""Writes NethraVazhi.xcodeproj (Xcode 16+ format with folder-synchronized groups).
Every file inside NethraVazhi/ and NethraVazhiTests/ is picked up automatically.
usage: python3 make_xcodeproj.py <project root>"""
import hashlib, sys
from pathlib import Path

root = Path(sys.argv[1])
BUNDLE_ID = "com.nethravazhi.NethraVazhi"

def oid(name):
    return hashlib.md5(name.encode()).hexdigest()[:24].upper()

ID = {k: oid(k) for k in [
    "project", "maingroup", "products", "appgroup", "testgroup", "appproduct", "testproduct",
    "apptarget", "testtarget", "appsources", "appframeworks", "appresources", "testsources",
    "testframeworks", "testresources", "proxy", "dependency", "projcfg", "appcfg", "testcfg",
    "projdebug", "projrelease", "appdebug", "apprelease", "testdebug", "testrelease"]}

def q(v):
    v = str(v)
    if v and all(c.isalnum() or c in "._/" for c in v):
        return v
    return '"' + v.replace("\\", "\\\\").replace('"', '\\"') + '"'

def settings(d, indent="\t\t\t\t"):
    out = []
    for k in sorted(d):
        v = d[k]
        if isinstance(v, list):
            inner = "".join(f"{indent}\t{q(x)},\n" for x in v)
            out.append(f"{indent}{k} = (\n{inner}{indent});")
        else:
            out.append(f"{indent}{k} = {q(v)};")
    return "\n".join(out)

common = {
    "ALWAYS_SEARCH_USER_PATHS": "NO", "ASSETCATALOG_COMPILER_GENERATE_SWIFT_ASSET_SYMBOL_EXTENSIONS": "YES",
    "CLANG_ANALYZER_NONNULL": "YES", "CLANG_CXX_LANGUAGE_STANDARD": "gnu++20", "CLANG_ENABLE_MODULES": "YES",
    "CLANG_ENABLE_OBJC_ARC": "YES", "CLANG_ENABLE_OBJC_WEAK": "YES", "COPY_PHASE_STRIP": "NO",
    "ENABLE_STRICT_OBJC_MSGSEND": "YES", "ENABLE_USER_SCRIPT_SANDBOXING": "YES", "GCC_C_LANGUAGE_STANDARD": "gnu17",
    "GCC_NO_COMMON_BLOCKS": "YES", "IPHONEOS_DEPLOYMENT_TARGET": "17.0", "LOCALIZATION_PREFERS_STRING_CATALOGS": "YES",
    "MTL_FAST_MATH": "YES", "SDKROOT": "iphoneos", "SWIFT_VERSION": "5.0",
}
proj_debug = {**common, "DEBUG_INFORMATION_FORMAT": "dwarf", "ENABLE_TESTABILITY": "YES", "GCC_DYNAMIC_NO_PIC": "NO",
              "GCC_OPTIMIZATION_LEVEL": "0", "GCC_PREPROCESSOR_DEFINITIONS": ["DEBUG=1", "$(inherited)"],
              "MTL_ENABLE_DEBUG_INFO": "INCLUDE_SOURCE", "ONLY_ACTIVE_ARCH": "YES",
              "SWIFT_ACTIVE_COMPILATION_CONDITIONS": "DEBUG $(inherited)", "SWIFT_OPTIMIZATION_LEVEL": "-Onone"}
proj_release = {**common, "DEBUG_INFORMATION_FORMAT": "dwarf-with-dsym", "ENABLE_NS_ASSERTIONS": "NO",
                "MTL_ENABLE_DEBUG_INFO": "NO", "SWIFT_COMPILATION_MODE": "wholemodule", "VALIDATE_PRODUCT": "YES"}
app = {
    "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon", "CODE_SIGN_STYLE": "Automatic", "CURRENT_PROJECT_VERSION": "1",
    "DEVELOPMENT_TEAM": "", "ENABLE_PREVIEWS": "YES", "GENERATE_INFOPLIST_FILE": "YES",
    "INFOPLIST_KEY_CFBundleDisplayName": "Nethra Vazhi",
    "INFOPLIST_KEY_LSApplicationCategoryType": "public.app-category.navigation",
    "INFOPLIST_KEY_NSCameraUsageDescription": "Nethra Vazhi uses the camera to detect obstacles, potholes and stairs in front of you.",
    "INFOPLIST_KEY_NSMicrophoneUsageDescription": "Nethra Vazhi listens for the place you want to walk to.",
    "INFOPLIST_KEY_NSSpeechRecognitionUsageDescription": "Your spoken destination is converted to text to find a walking route.",
    "INFOPLIST_KEY_NSLocationWhenInUseUsageDescription": "Your location is the starting point for walking directions.",
    "INFOPLIST_KEY_NSMotionUsageDescription": "Motion and fitness data (steps and air pressure) are used to warn you about slopes and ramps.",
    "INFOPLIST_KEY_UIApplicationSceneManifest_Generation": "YES",
    "INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents": "YES",
    "INFOPLIST_KEY_UILaunchScreen_Generation": "YES",
    "INFOPLIST_KEY_UIRequiresFullScreen": "YES",
    "INFOPLIST_KEY_UIStatusBarHidden": "YES",
    "INFOPLIST_KEY_UISupportedInterfaceOrientations_iPhone": "UIInterfaceOrientationPortrait",
    "INFOPLIST_KEY_UISupportedInterfaceOrientations_iPad": "UIInterfaceOrientationPortrait",
    "LD_RUNPATH_SEARCH_PATHS": ["$(inherited)", "@executable_path/Frameworks"],
    "MARKETING_VERSION": "1.0", "PRODUCT_BUNDLE_IDENTIFIER": BUNDLE_ID, "PRODUCT_NAME": "$(TARGET_NAME)",
    "SUPPORTED_PLATFORMS": "iphoneos iphonesimulator", "SUPPORTS_MACCATALYST": "NO",
    "SUPPORTS_MAC_DESIGNED_FOR_IPHONE_IPAD": "NO", "SWIFT_EMIT_LOC_STRINGS": "YES",
    "SWIFT_STRICT_CONCURRENCY": "minimal", "SWIFT_VERSION": "5.0", "TARGETED_DEVICE_FAMILY": "1",
}
test = {
    "BUNDLE_LOADER": "$(TEST_HOST)", "CODE_SIGN_STYLE": "Automatic", "CURRENT_PROJECT_VERSION": "1",
    "DEVELOPMENT_TEAM": "", "GENERATE_INFOPLIST_FILE": "YES", "IPHONEOS_DEPLOYMENT_TARGET": "17.0",
    "MARKETING_VERSION": "1.0", "PRODUCT_BUNDLE_IDENTIFIER": BUNDLE_ID + "Tests", "PRODUCT_NAME": "$(TARGET_NAME)",
    "SWIFT_EMIT_LOC_STRINGS": "NO", "SWIFT_STRICT_CONCURRENCY": "minimal", "SWIFT_VERSION": "5.0",
    "TARGETED_DEVICE_FAMILY": "1",
    "TEST_HOST": "$(BUILT_PRODUCTS_DIR)/NethraVazhi.app/$(BUNDLE_EXECUTABLE_FOLDER_PATH)/NethraVazhi",
}

def cfg(key, name, d):
    return f"""\t\t{ID[key]} /* {name} */ = {{
\t\t\tisa = XCBuildConfiguration;
\t\t\tbuildSettings = {{
{settings(d)}
\t\t\t}};
\t\t\tname = {name};
\t\t}};
"""

def phase(key, isa, name):
    return f"""\t\t{ID[key]} /* {name} */ = {{
\t\t\tisa = {isa};
\t\t\tbuildActionMask = 2147483647;
\t\t\tfiles = (
\t\t\t);
\t\t\trunOnlyForDeploymentPostprocessing = 0;
\t\t}};
"""

def cfglist(key, a, b, label):
    return f"""\t\t{ID[key]} /* Build configuration list for {label} */ = {{
\t\t\tisa = XCConfigurationList;
\t\t\tbuildConfigurations = (
\t\t\t\t{ID[a]} /* Debug */,
\t\t\t\t{ID[b]} /* Release */,
\t\t\t);
\t\t\tdefaultConfigurationIsVisible = 0;
\t\t\tdefaultConfigurationName = Release;
\t\t}};
"""

pbx = f"""// !$*UTF8*$!
{{
\tarchiveVersion = 1;
\tclasses = {{
\t}};
\tobjectVersion = 77;
\tobjects = {{

/* Begin PBXContainerItemProxy section */
\t\t{ID['proxy']} /* PBXContainerItemProxy */ = {{
\t\t\tisa = PBXContainerItemProxy;
\t\t\tcontainerPortal = {ID['project']} /* Project object */;
\t\t\tproxyType = 1;
\t\t\tremoteGlobalIDString = {ID['apptarget']};
\t\t\tremoteInfo = NethraVazhi;
\t\t}};
/* End PBXContainerItemProxy section */

/* Begin PBXFileReference section */
\t\t{ID['appproduct']} /* NethraVazhi.app */ = {{isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = NethraVazhi.app; sourceTree = BUILT_PRODUCTS_DIR; }};
\t\t{ID['testproduct']} /* NethraVazhiTests.xctest */ = {{isa = PBXFileReference; explicitFileType = wrapper.cfbundle; includeInIndex = 0; path = NethraVazhiTests.xctest; sourceTree = BUILT_PRODUCTS_DIR; }};
/* End PBXFileReference section */

/* Begin PBXFileSystemSynchronizedRootGroup section */
\t\t{ID['appgroup']} /* NethraVazhi */ = {{
\t\t\tisa = PBXFileSystemSynchronizedRootGroup;
\t\t\tpath = NethraVazhi;
\t\t\tsourceTree = "<group>";
\t\t}};
\t\t{ID['testgroup']} /* NethraVazhiTests */ = {{
\t\t\tisa = PBXFileSystemSynchronizedRootGroup;
\t\t\tpath = NethraVazhiTests;
\t\t\tsourceTree = "<group>";
\t\t}};
/* End PBXFileSystemSynchronizedRootGroup section */

/* Begin PBXFrameworksBuildPhase section */
{phase('appframeworks', 'PBXFrameworksBuildPhase', 'Frameworks')}{phase('testframeworks', 'PBXFrameworksBuildPhase', 'Frameworks')}/* End PBXFrameworksBuildPhase section */

/* Begin PBXGroup section */
\t\t{ID['maingroup']} = {{
\t\t\tisa = PBXGroup;
\t\t\tchildren = (
\t\t\t\t{ID['appgroup']} /* NethraVazhi */,
\t\t\t\t{ID['testgroup']} /* NethraVazhiTests */,
\t\t\t\t{ID['products']} /* Products */,
\t\t\t);
\t\t\tsourceTree = "<group>";
\t\t}};
\t\t{ID['products']} /* Products */ = {{
\t\t\tisa = PBXGroup;
\t\t\tchildren = (
\t\t\t\t{ID['appproduct']} /* NethraVazhi.app */,
\t\t\t\t{ID['testproduct']} /* NethraVazhiTests.xctest */,
\t\t\t);
\t\t\tname = Products;
\t\t\tsourceTree = "<group>";
\t\t}};
/* End PBXGroup section */

/* Begin PBXNativeTarget section */
\t\t{ID['apptarget']} /* NethraVazhi */ = {{
\t\t\tisa = PBXNativeTarget;
\t\t\tbuildConfigurationList = {ID['appcfg']} /* Build configuration list for PBXNativeTarget "NethraVazhi" */;
\t\t\tbuildPhases = (
\t\t\t\t{ID['appsources']} /* Sources */,
\t\t\t\t{ID['appframeworks']} /* Frameworks */,
\t\t\t\t{ID['appresources']} /* Resources */,
\t\t\t);
\t\t\tbuildRules = (
\t\t\t);
\t\t\tdependencies = (
\t\t\t);
\t\t\tfileSystemSynchronizedGroups = (
\t\t\t\t{ID['appgroup']} /* NethraVazhi */,
\t\t\t);
\t\t\tname = NethraVazhi;
\t\t\tpackageProductDependencies = (
\t\t\t);
\t\t\tproductName = NethraVazhi;
\t\t\tproductReference = {ID['appproduct']} /* NethraVazhi.app */;
\t\t\tproductType = "com.apple.product-type.application";
\t\t}};
\t\t{ID['testtarget']} /* NethraVazhiTests */ = {{
\t\t\tisa = PBXNativeTarget;
\t\t\tbuildConfigurationList = {ID['testcfg']} /* Build configuration list for PBXNativeTarget "NethraVazhiTests" */;
\t\t\tbuildPhases = (
\t\t\t\t{ID['testsources']} /* Sources */,
\t\t\t\t{ID['testframeworks']} /* Frameworks */,
\t\t\t\t{ID['testresources']} /* Resources */,
\t\t\t);
\t\t\tbuildRules = (
\t\t\t);
\t\t\tdependencies = (
\t\t\t\t{ID['dependency']} /* PBXTargetDependency */,
\t\t\t);
\t\t\tfileSystemSynchronizedGroups = (
\t\t\t\t{ID['testgroup']} /* NethraVazhiTests */,
\t\t\t);
\t\t\tname = NethraVazhiTests;
\t\t\tpackageProductDependencies = (
\t\t\t);
\t\t\tproductName = NethraVazhiTests;
\t\t\tproductReference = {ID['testproduct']} /* NethraVazhiTests.xctest */;
\t\t\tproductType = "com.apple.product-type.bundle.unit-test";
\t\t}};
/* End PBXNativeTarget section */

/* Begin PBXProject section */
\t\t{ID['project']} /* Project object */ = {{
\t\t\tisa = PBXProject;
\t\t\tattributes = {{
\t\t\t\tBuildIndependentTargetsInParallel = 1;
\t\t\t\tLastSwiftUpdateCheck = 1600;
\t\t\t\tLastUpgradeCheck = 1600;
\t\t\t\tTargetAttributes = {{
\t\t\t\t\t{ID['apptarget']} = {{
\t\t\t\t\t\tCreatedOnToolsVersion = 16.0;
\t\t\t\t\t}};
\t\t\t\t\t{ID['testtarget']} = {{
\t\t\t\t\t\tCreatedOnToolsVersion = 16.0;
\t\t\t\t\t\tTestTargetID = {ID['apptarget']};
\t\t\t\t\t}};
\t\t\t\t}};
\t\t\t}};
\t\t\tbuildConfigurationList = {ID['projcfg']} /* Build configuration list for PBXProject "NethraVazhi" */;
\t\t\tdevelopmentRegion = en;
\t\t\thasScannedForEncodings = 0;
\t\t\tknownRegions = (
\t\t\t\ten,
\t\t\t\tBase,
\t\t\t);
\t\t\tmainGroup = {ID['maingroup']};
\t\t\tminimizedProjectReferenceProxies = 1;
\t\t\tpreferredProjectObjectVersion = 77;
\t\t\tproductRefGroup = {ID['products']} /* Products */;
\t\t\tprojectDirPath = "";
\t\t\tprojectRoot = "";
\t\t\ttargets = (
\t\t\t\t{ID['apptarget']} /* NethraVazhi */,
\t\t\t\t{ID['testtarget']} /* NethraVazhiTests */,
\t\t\t);
\t\t}};
/* End PBXProject section */

/* Begin PBXResourcesBuildPhase section */
{phase('appresources', 'PBXResourcesBuildPhase', 'Resources')}{phase('testresources', 'PBXResourcesBuildPhase', 'Resources')}/* End PBXResourcesBuildPhase section */

/* Begin PBXSourcesBuildPhase section */
{phase('appsources', 'PBXSourcesBuildPhase', 'Sources')}{phase('testsources', 'PBXSourcesBuildPhase', 'Sources')}/* End PBXSourcesBuildPhase section */

/* Begin PBXTargetDependency section */
\t\t{ID['dependency']} /* PBXTargetDependency */ = {{
\t\t\tisa = PBXTargetDependency;
\t\t\ttarget = {ID['apptarget']} /* NethraVazhi */;
\t\t\ttargetProxy = {ID['proxy']} /* PBXContainerItemProxy */;
\t\t}};
/* End PBXTargetDependency section */

/* Begin XCBuildConfiguration section */
{cfg('projdebug', 'Debug', proj_debug)}{cfg('projrelease', 'Release', proj_release)}{cfg('appdebug', 'Debug', app)}{cfg('apprelease', 'Release', app)}{cfg('testdebug', 'Debug', test)}{cfg('testrelease', 'Release', test)}/* End XCBuildConfiguration section */

/* Begin XCConfigurationList section */
{cfglist('projcfg', 'projdebug', 'projrelease', 'PBXProject "NethraVazhi"')}{cfglist('appcfg', 'appdebug', 'apprelease', 'PBXNativeTarget "NethraVazhi"')}{cfglist('testcfg', 'testdebug', 'testrelease', 'PBXNativeTarget "NethraVazhiTests"')}/* End XCConfigurationList section */
\t}};
\trootObject = {ID['project']} /* Project object */;
}}
"""

proj = root / "NethraVazhi.xcodeproj"
(proj / "project.xcworkspace").mkdir(parents=True, exist_ok=True)
(proj / "project.pbxproj").write_text(pbx)
(proj / "project.xcworkspace" / "contents.xcworkspacedata").write_text(
    '<?xml version="1.0" encoding="UTF-8"?>\n<Workspace\n   version = "1.0">\n   <FileRef\n      location = "self:">\n   </FileRef>\n</Workspace>\n')
schemes = proj / "xcshareddata" / "xcschemes"
schemes.mkdir(parents=True, exist_ok=True)
ref = lambda t, name, product: f'''<BuildableReference
               BuildableIdentifier = "primary"
               BlueprintIdentifier = "{ID[t]}"
               BuildableName = "{product}"
               BlueprintName = "{name}"
               ReferencedContainer = "container:NethraVazhi.xcodeproj">
            </BuildableReference>'''
(schemes / "NethraVazhi.xcscheme").write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme
   LastUpgradeVersion = "1600"
   version = "1.7">
   <BuildAction
      parallelizeBuildables = "YES"
      buildImplicitDependencies = "YES">
      <BuildActionEntries>
         <BuildActionEntry
            buildForTesting = "YES"
            buildForRunning = "YES"
            buildForProfiling = "YES"
            buildForArchiving = "YES"
            buildForAnalyzing = "YES">
            {ref('apptarget', 'NethraVazhi', 'NethraVazhi.app')}
         </BuildActionEntry>
      </BuildActionEntries>
   </BuildAction>
   <TestAction
      buildConfiguration = "Debug"
      selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
      selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
      shouldUseLaunchSchemeArgsEnv = "YES"
      shouldAutocreateTestPlan = "YES">
      <Testables>
         <TestableReference
            skipped = "NO">
            {ref('testtarget', 'NethraVazhiTests', 'NethraVazhiTests.xctest')}
         </TestableReference>
      </Testables>
   </TestAction>
   <LaunchAction
      buildConfiguration = "Debug"
      selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
      selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
      launchStyle = "0"
      useCustomWorkingDirectory = "NO"
      ignoresPersistentStateOnLaunch = "NO"
      debugDocumentVersioning = "YES"
      debugServiceExtension = "internal"
      allowLocationSimulation = "YES">
      <BuildableProductRunnable
         runnableDebuggingMode = "0">
         {ref('apptarget', 'NethraVazhi', 'NethraVazhi.app')}
      </BuildableProductRunnable>
   </LaunchAction>
   <ProfileAction
      buildConfiguration = "Release"
      shouldUseLaunchSchemeArgsEnv = "YES"
      savedToolIdentifier = ""
      useCustomWorkingDirectory = "NO"
      debugDocumentVersioning = "YES">
      <BuildableProductRunnable
         runnableDebuggingMode = "0">
         {ref('apptarget', 'NethraVazhi', 'NethraVazhi.app')}
      </BuildableProductRunnable>
   </ProfileAction>
   <AnalyzeAction
      buildConfiguration = "Debug">
   </AnalyzeAction>
   <ArchiveAction
      buildConfiguration = "Release"
      revealArchiveInOrganizer = "YES">
   </ArchiveAction>
</Scheme>
''')
print("wrote", proj)
