"""Re-create the three CoreML models in NethraVazhi/Models (only needed if you retrain or swap a model).

    pip install ultralytics coremltools "numpy<=2.3.5"
    python3 export_models.py --pothole path/to/pothole_yolo26/weights/best.pt

Options:
    --hazard-model yoloe-26s-seg.pt   (default; open-vocabulary YOLOE, text encoder downloads from GitHub)
    --hazard-model yolov8s-worldv2.pt (the YOLO-World model your Python app used; needs OpenAI CLIP weights)
All models are exported for a portrait input (default 320x416; see --imgsz) with end-to-end output [1, N, 6],
which is what the app's decoder expects (it also accepts the classic [1, 4+C, A] layout).
"""
import argparse, shutil
from pathlib import Path
from ultralytics import YOLO, YOLOE, YOLOWorld

PROMPTS = ["staircase or steps", "road curb", "ramp", "traffic cone", "bollard", "road barrier",
           "open doorway", "glass door", "street pole", "wall directly in front of the camera"]

ap = argparse.ArgumentParser()
ap.add_argument("--coco", default="yolo26n.pt", help="use yolo26s.pt for better accuracy (slower)")
ap.add_argument("--imgsz", type=int, nargs=2, metavar=("H", "W"), default=[416, 320],
                help="portrait input size, e.g. --imgsz 640 480 for noticeably better small/far objects")
ap.add_argument("--pothole", required=True)
ap.add_argument("--hazard-model", default="yoloe-26s-seg.pt")
ap.add_argument("--out", default=str(Path(__file__).resolve().parent.parent / "NethraVazhi" / "Models"))
a = ap.parse_args()
IMGSZ = a.imgsz  # height, width (phone held upright); the app reads this from the model
out = Path(a.out)
out.mkdir(parents=True, exist_ok=True)

def export(model, name):
    path = Path(model.export(format="coreml", imgsz=IMGSZ, half=True, nms=False))
    dest = out / f"{name}.mlpackage"
    if dest.exists():
        shutil.rmtree(dest)
    shutil.move(str(path), dest)
    print("->", dest)

export(YOLO(a.coco), "COCODetector")
export(YOLO(a.pothole), "PotholeDetector")
if "world" in a.hazard_model:
    m = YOLOWorld(a.hazard_model)
else:
    m = YOLOE(a.hazard_model.replace("-seg", "").replace(".pt", ".yaml")).load(a.hazard_model)
m.set_classes(PROMPTS)  # class order must match DetectionConfig.openVocabLabels in the app
export(m, "HazardDetector")
