import XCTest
@testable import NethraVazhi

/// STOP distance threshold and slope warnings (added on top of nethracam.py).
final class StopAndSlopeTests: XCTestCase {
    private func hazard(_ label: String, x1: Double, y1: Double, x2: Double, y2: Double,
                        pothole: Bool = false, open: Bool = false) -> Hazard {
        Hazard(label: label, box: Box(x1: x1, y1: y1, x2: x2, y2: y2), frameWidth: 320, frameHeight: 416,
               confidence: 0.9, isPothole: pothole, openVocab: open)
    }

    private func guidance(for hazards: [Hazard]) -> Guidance {
        HazardLogic.applyStopThreshold(HazardLogic.chooseGuidance(HazardLogic.aggregate(hazards)))
    }

    func testFarObjectIsSilent() {
        // Small object high in the frame = far away.
        let g = guidance(for: [hazard("car", x1: 140, y1: 100, x2: 170, y2: 140)])
        XCTAssertEqual(g.key, "far")
    }

    func testApproachingObjectAheadIsCautionNotStop() {
        // Lower edge at 65 % of the frame: approaching, not yet near.
        let g = guidance(for: [hazard("car", x1: 110, y1: 150, x2: 210, y2: 270)])
        XCTAssertEqual(g.key, "caution_ahead")
        XCTAssertTrue(g.display.hasPrefix("CAUTION"))
        XCTAssertEqual(Messages(language: .english).spoken(for: g),
                       "Caution. Car ahead. Slow down and check left and right with your cane.")
        XCTAssertFalse(AlertArbiter.isUrgent(g.key))
    }

    func testNearObjectAheadIsStop() {
        // Lower edge at 90 % and large: near -> STOP (nethracam.py sentence).
        let g = guidance(for: [hazard("car", x1: 90, y1: 200, x2: 230, y2: 375)])
        XCTAssertEqual(g.key, "front_blocked")
        XCTAssertTrue(g.display.hasPrefix("STOP"))
        XCTAssertTrue(AlertArbiter.isUrgent(g.key))
        XCTAssertEqual(Messages(language: .malayalam).spoken(for: g), Messages(language: .malayalam).frontAlert(label: "car"))
    }

    func testApproachingOnLeftTellsUserToMoveRight() {
        let g = guidance(for: [hazard("bench", x1: 0, y1: 150, x2: 80, y2: 260)])
        XCTAssertEqual(g.key, "caution_left")
        XCTAssertEqual(Messages(language: .english).spoken(for: g),
                       "Caution. Bench ahead on your left. Check the right side with your cane and keep to the right.")
        XCTAssertEqual(Messages(language: .malayalam).spoken(for: g),
                       "ശ്രദ്ധിക്കുക. ഇടത് വശത്ത് ബെഞ്ച്. വലത് വശം ചൂരൽ കൊണ്ട് പരിശോധിച്ച് വലത്തേക്ക് മാറി നടക്കുക.")
    }

    func testNearOnRightIsStopAndMoveLeft() {
        let g = guidance(for: [hazard("motorcycle", x1: 240, y1: 180, x2: 320, y2: 400)])
        XCTAssertEqual(g.key, "obstacle_right")
        XCTAssertTrue(Messages(language: .english).spoken(for: g).hasPrefix("Stop. Motorcycle on your right. Check the left side"))
    }

    func testStairsStayStopEvenWhenApproaching() {
        let g = guidance(for: [hazard("stairs", x1: 80, y1: 150, x2: 240, y2: 260, open: true)])
        XCTAssertEqual(g.key, "stairs_ahead")
    }

    func testRampAheadIsSlowDownWarning() {
        let g = guidance(for: [hazard("ramp", x1: 60, y1: 200, x2: 260, y2: 400, open: true)])
        XCTAssertEqual(g.key, "ramp_ahead")
        XCTAssertEqual(Messages(language: .english).spoken(for: g), Messages(language: .english).rampAhead)
    }

    func testStopInterruptsCautionButCautionDoesNotInterruptStop() {
        var a = AlertArbiter()
        XCTAssertEqual(a.decide(key: "caution_ahead", text: "c", explicit: false, now: 0, audioBusy: false, safetyStopText: "S"),
                       .speak(key: "caution_ahead", text: "c"))
        XCTAssertEqual(a.decide(key: "front_blocked", text: "f", explicit: false, now: 0.5, audioBusy: true, safetyStopText: "S"),
                       .speak(key: "front_blocked", text: "f"))
        XCTAssertEqual(a.decide(key: "caution_ahead", text: "c", explicit: false, now: 1.0, audioBusy: true, safetyStopText: "S"), .skip)
    }

    // MARK: Slope tracker
    private func walk(_ tracker: inout SlopeTracker, meters: Double, grade: Double, from start: (d: Double, a: Double, t: Double))
        -> (events: [SlopeEvent], end: (d: Double, a: Double, t: Double)) {
        var events: [SlopeEvent] = []
        var d = start.d, a = start.a, t = start.t
        var walked = 0.0
        while walked < meters {
            d += 1.5; a += 1.5 * grade / 100; t += 1.2; walked += 1.5   // a pedometer update every ~2 steps
            if let e = tracker.add(distance: d, altitude: a, time: t) { events.append(e) }
        }
        return (events, (d, a, t))
    }

    func testLevelGroundNoWarning() {
        var tr = SlopeTracker()
        let r = walk(&tr, meters: 60, grade: 1, from: (0, 0, 0))
        XCTAssertEqual(r.events, [])
    }

    func testUphillThenLevel() {
        var tr = SlopeTracker()
        let flat = walk(&tr, meters: 10, grade: 0, from: (0, 0, 0))
        let up = walk(&tr, meters: 15, grade: 10, from: flat.end)
        XCTAssertEqual(up.events.first, .uphill(gradePercent: 10))
        XCTAssertEqual(up.events.count, 1, "warned once, not every step: \(up.events)")
        let level = walk(&tr, meters: 15, grade: 0, from: up.end)
        XCTAssertEqual(level.events, [.level])
    }

    func testDownhillDetected() {
        var tr = SlopeTracker()
        let flat = walk(&tr, meters: 10, grade: 0, from: (0, 0, 0))
        let down = walk(&tr, meters: 15, grade: -12, from: flat.end)
        XCTAssertEqual(down.events.first, .downhill(gradePercent: 12))
    }

    func testGentleSlopeBelowThresholdIgnored() {
        var tr = SlopeTracker()
        let r = walk(&tr, meters: 40, grade: 6, from: (0, 0, 0))
        XCTAssertEqual(r.events, [])
    }

    func testSlopeMessages() {
        XCTAssertEqual(Messages(language: .english).slope(uphill: true, gradePercent: 9),
                       "Caution. Uphill slope, about 9 percent. Walk slowly and check with your cane.")
        XCTAssertTrue(Messages(language: .malayalam).slope(uphill: false, gradePercent: 9).contains("താഴേക്കുള്ള ചരിവ്"))
    }
}
