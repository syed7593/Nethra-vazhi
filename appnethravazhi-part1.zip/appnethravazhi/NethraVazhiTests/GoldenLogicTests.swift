import XCTest
@testable import NethraVazhi

/// Replays test vectors generated from the ORIGINAL Python code
/// (tools/make_golden_tests.py on nethracam.py / osmmap.py).
/// Every assertion checks that the iPhone port gives the same answer as Python.
final class GoldenLogicTests: XCTestCase {
    private static var cache: [String: Any]?

    private func golden() throws -> [String: Any] {
        if let c = GoldenLogicTests.cache { return c }
        let url = try XCTUnwrap(Bundle(for: GoldenLogicTests.self).url(forResource: "golden_logic", withExtension: "json"),
                                "golden_logic.json missing from test bundle")
        let obj = try XCTUnwrap(try JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
        GoldenLogicTests.cache = obj
        return obj
    }

    private func dbl(_ v: Any?) -> Double { RouteLogic.number(v) ?? .nan }

    func testCocoReliabilityThresholds() throws {
        let cases = try XCTUnwrap(golden()["reliable"] as? [[String: Any]])
        for c in cases {
            let name = c["name"] as! String
            let conf = dbl(c["conf"])
            XCTAssertEqual(HazardLogic.isReliableCocoDetection(name, confidence: conf), c["ok"] as! Bool, "\(name) \(conf)")
        }
    }

    func testDetectionSequencesMatchPython() throws {
        let g = try golden()
        let frame = g["frame"] as! [Any]
        let fw = dbl(frame[0]), fh = dbl(frame[1])
        let sequences = try XCTUnwrap(g["detection"] as? [[[String: Any]]])
        let ml = Messages(language: .malayalam)
        var checkedFrames = 0
        for (s, seq) in sequences.enumerated() {
            var tracks: [Track] = []
            for (f, fr) in seq.enumerated() {
                let ctx = "seq \(s) frame \(f)"
                let inputs = fr["inputs"] as! [[String: Any]]
                let hazards: [Hazard] = inputs.map { i in
                    let b = i["box"] as! [Any]
                    return Hazard(label: i["label"] as! String,
                                  box: Box(x1: dbl(b[0]), y1: dbl(b[1]), x2: dbl(b[2]), y2: dbl(b[3])),
                                  frameWidth: fw, frameHeight: fh, confidence: dbl(i["conf"]),
                                  isPothole: i["pothole"] as! Bool, openVocab: i["open"] as! Bool)
                }
                let r = HazardLogic.confirm(hazards, previous: tracks)
                tracks = r.tracks
                XCTAssertEqual(r.all.map { $0.framesSeen }, (fr["frames_seen"] as! [Any]).map { Int(dbl($0)) }, ctx)
                XCTAssertEqual(r.all.map { $0.confirmed }, fr["confirmed"] as! [Bool], ctx)

                let objects = HazardLogic.aggregate(r.confirmed)
                let expected = fr["objects"] as! [[String: Any]]
                XCTAssertEqual(objects.count, expected.count, ctx)
                for (o, e) in zip(objects, expected) {
                    XCTAssertEqual(o.label, e["label"] as? String, ctx)
                    XCTAssertEqual(o.side.rawValue, e["side"] as? String, ctx)
                    XCTAssertEqual(o.proximity.rawValue, e["proximity"] as? String, ctx)
                    XCTAssertEqual(o.priority, dbl(e["priority"]), accuracy: 1e-9, ctx)
                }
                let guidance = HazardLogic.chooseGuidance(objects)
                XCTAssertEqual(guidance.key, fr["key"] as? String, ctx)
                XCTAssertEqual(guidance.display, fr["display"] as? String, ctx)
                XCTAssertEqual(guidance.label, fr["alert_label"] as? String, ctx)
                XCTAssertEqual(ml.spoken(for: guidance), fr["spoken_ml"] as? String, ctx)
                checkedFrames += 1
            }
        }
        XCTAssertGreaterThan(checkedFrames, 400)
    }

    func testSpeechArbitrationMatchesPython() throws {
        let cases = try XCTUnwrap(golden()["arbiter"] as? [[[String: Any]]])
        for (c, events) in cases.enumerated() {
            var arbiter = AlertArbiter()
            for (i, e) in events.enumerated() {
                let decision = arbiter.decide(key: e["key"] as! String, text: e["text"] as! String,
                                              explicit: e["explicit"] as! Bool, now: dbl(e["now"]),
                                              audioBusy: e["busy"] as! Bool, safetyStopText: "SAFETY")
                if let spoke = e["spoke"] as? [String] {
                    XCTAssertEqual(decision, .speak(key: spoke[0], text: spoke[1]), "case \(c) event \(i)")
                } else {
                    XCTAssertEqual(decision, .skip, "case \(c) event \(i)")
                }
            }
        }
    }

    func testMalayalamMessagesMatchPython() throws {
        let m = try XCTUnwrap(golden()["messages"] as? [String: Any])
        let ml = Messages(language: .malayalam)
        for s in m["side"] as! [[String: Any]] {
            let side: Side = (s["side"] as! String) == "left" ? .left : .right
            XCTAssertEqual(ml.sideAlert(label: s["label"] as! String, blocked: side), s["text"] as? String)
        }
        for f in m["front"] as! [[String: Any]] {
            XCTAssertEqual(ml.frontAlert(label: f["label"] as! String), f["text"] as? String)
        }
        let core = m["core"] as! [String: String]
        XCTAssertEqual(ml.safetyStop, core["safety_stop"])
        XCTAssertEqual(ml.safeCaution, core["caution"])
        XCTAssertEqual(ml.safeClear, core["clear"])
        XCTAssertEqual(ml.paused, core["pause"])
        XCTAssertEqual(ml.resumed, core["resume"])
    }

    func testRouteParsingAndProgressMatchPython() throws {
        let routes = try XCTUnwrap(golden()["routes"] as? [[String: Any]])
        for (r, item) in routes.enumerated() {
            let data = try JSONSerialization.data(withJSONObject: item["ors"]!)
            let route = try RouteLogic.parseORSRoute(data)
            XCTAssertEqual(route.geometry.count, Int(dbl(item["points"])))
            XCTAssertEqual(route.distanceM, dbl(item["distance_m"]), accuracy: 1e-9)
            XCTAssertEqual(route.durationS, dbl(item["duration_s"]), accuracy: 1e-9)
            let steps = item["steps"] as! [[String: Any]]
            XCTAssertEqual(route.steps.count, steps.count)
            for (a, b) in zip(route.steps, steps) {
                XCTAssertEqual(a.instruction, b["instruction"] as? String)
                XCTAssertEqual(a.startIndex, Int(dbl(b["start_index"])))
                XCTAssertEqual(a.endIndex, Int(dbl(b["end_index"])))
                XCTAssertEqual(a.type, Int(dbl(b["type"])))
            }
            for (p, probe) in (item["probes"] as! [[String: Any]]).enumerated() {
                let progress = RouteLogic.progress(route: route, at: Coordinate(lat: dbl(probe["lat"]), lon: dbl(probe["lon"])),
                                                   lastIndex: Int(dbl(probe["last"])))
                let ctx = "route \(r) probe \(p)"
                XCTAssertEqual(progress.geometryIndex, Int(dbl(probe["geometry_index"])), ctx)
                XCTAssertEqual(progress.stepIndex, Int(dbl(probe["step_index"])), ctx)
                XCTAssertEqual(progress.distanceToStepM, dbl(probe["distance_to_step_m"]), accuracy: 1e-6, ctx)
                XCTAssertEqual(progress.announceDistanceM, dbl(probe["announce_distance_m"]), accuracy: 1e-6, ctx)
            }
        }
    }

    func testInstructionTranslationMatchesPython() throws {
        let items = try XCTUnwrap(golden()["instructions"] as? [[String: Any]])
        for i in items {
            XCTAssertEqual(RouteLogic.instructionMalayalam(i["text"] as! String, distanceM: dbl(i["d"])), i["ml"] as? String,
                           "\(i["text"]!) \(i["d"]!)")
        }
    }

    func testHaversineMatchesPython() throws {
        for h in try XCTUnwrap(golden()["haversine"] as? [[String: Any]]) {
            let a = h["a"] as! [Any], b = h["b"] as! [Any]
            XCTAssertEqual(RouteLogic.haversineM(Coordinate(lat: dbl(a[0]), lon: dbl(a[1])), Coordinate(lat: dbl(b[0]), lon: dbl(b[1]))),
                           dbl(h["m"]), accuracy: 1e-6)
        }
    }
}
