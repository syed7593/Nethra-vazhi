import XCTest
import UIKit
@testable import NethraVazhi

final class DecoderAndModelTests: XCTestCase {
    /// Raw model outputs captured from the real YOLO model on bus.jpg; expected boxes from Python.
    func testDecoderMatchesPythonOnRealModelOutput() throws {
        let url = try XCTUnwrap(Bundle(for: DecoderAndModelTests.self).url(forResource: "golden_decoder", withExtension: "json"))
        let root = try XCTUnwrap(try JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
        let input = root["input"] as! [Any]
        let w = RouteLogic.number(input[0])!, h = RouteLogic.number(input[1])!
        for c in root["cases"] as! [[String: Any]] {
            let name = c["name"] as! String
            let shape = (c["shape"] as! [Any]).map { Int(RouteLogic.number($0)!) }
            let bytes = try XCTUnwrap(Data(base64Encoded: c["data"] as! String))
            var values = [Float](repeating: 0, count: bytes.count / 4)
            _ = values.withUnsafeMutableBytes { bytes.copyBytes(to: $0) }
            let got = YOLODecoder.decode(values: values, shape: shape, inputWidth: w, inputHeight: h,
                                         minConfidence: RouteLogic.number(c["min_conf"])!)
            let expected = c["expected"] as! [[String: Any]]
            XCTAssertEqual(got.count, expected.count, name)
            for (g, e) in zip(got, expected) {
                XCTAssertEqual(g.classIndex, Int(RouteLogic.number(e["cls"])!), name)
                XCTAssertEqual(g.confidence, RouteLogic.number(e["conf"])!, accuracy: 1e-4, name)
                let box = (e["box"] as! [Any]).map { RouteLogic.number($0)! }
                XCTAssertEqual(g.x1, box[0], accuracy: 1e-4, name)
                XCTAssertEqual(g.y1, box[1], accuracy: 1e-4, name)
                XCTAssertEqual(g.x2, box[2], accuracy: 1e-4, name)
                XCTAssertEqual(g.y2, box[3], accuracy: 1e-4, name)
            }
        }
    }

    func testParseUltralyticsNames() {
        XCTAssertEqual(DetectorService.parseNames("{0: 'person', 1: 'bicycle', 2: 'traffic light'}") ?? [],
                       ["person", "bicycle", "traffic light"])
        XCTAssertEqual(DetectorService.parseNames("{0: 'pothole'}") ?? [], ["pothole"])
        XCTAssertNil(DetectorService.parseNames(nil))
    }

    /// Runs the three bundled CoreML models (the real app files) on bus.jpg.
    func testBundledModelsLoadAndDetect() throws {
        let detector = DetectorService()
        detector.load()
        XCTAssertEqual(detector.loadErrors, [], "Model load errors: \(detector.loadErrors)")
        XCTAssertEqual(detector.loadedModelNames, ["COCO", "Pothole", "Hazards"])

        let url = try XCTUnwrap(Bundle(for: DecoderAndModelTests.self).url(forResource: "bus", withExtension: "jpg"))
        let image = try XCTUnwrap(UIImage(contentsOfFile: url.path)?.cgImage)
        let coco = try detector.detect(model: "coco", cgImage: image, minConfidence: 0.5)
        let labels = coco.map { $0.0 }
        XCTAssertTrue(labels.contains("person"), "COCO model should see people: \(coco)")
        XCTAssertTrue(labels.contains("bus"), "COCO model should see the bus: \(coco)")
        XCTAssertGreaterThanOrEqual(labels.filter { $0 == "person" }.count, 3, "\(coco)")

        // The pothole model must not report a confident pothole on a city bus photo.
        let potholes = try detector.detect(model: "pothole", cgImage: image, minConfidence: DetectionConfig.potholeConfidence)
        XCTAssertTrue(potholes.isEmpty, "Unexpected pothole: \(potholes)")
        _ = try detector.detect(model: "hazard", cgImage: image, minConfidence: 0.25)
    }

    func testVoiceAnswers() {
        XCTAssertTrue(RouteLogic.isYes("Yes"))
        XCTAssertTrue(RouteLogic.isYes("yes please"))
        XCTAssertTrue(RouteLogic.isYes("അതെ"))
        XCTAssertFalse(RouteLogic.isYes("no"))
        XCTAssertFalse(RouteLogic.isYes("not this one"))
        XCTAssertTrue(RouteLogic.isNo("No"))
        XCTAssertTrue(RouteLogic.isNo("ഇല്ല"))
        XCTAssertTrue(RouteLogic.isCancel("cancel"))
        XCTAssertTrue(RouteLogic.isYes("Athe"))
        XCTAssertTrue(RouteLogic.isYes("shari"))
        XCTAssertTrue(RouteLogic.isNo("illa"))
        XCTAssertFalse(RouteLogic.isNo("Yes, Pallimukku"))   // place names must not count as "no"
    }

    func testEnglishMessages() {
        let en = Messages(language: .english)
        XCTAssertEqual(en.sideAlert(label: "car", blocked: .left),
                       "Stop. Car on your left. Check the right side with your cane. Move right only after your cane confirms it is safe.")
        XCTAssertEqual(en.frontAlert(label: "stairs"),
                       "Stop. Possible stairs ahead. Check left and right with your cane. Move only toward a side your cane confirms is safe.")
        XCTAssertEqual(RouteLogic.instructionEnglish("Turn left onto MG Road", distanceM: 37.5),
                       "In 38 meters, turn left onto MG Road.")
        XCTAssertEqual(RouteLogic.instructionEnglish("Arrive at destination", distanceM: 5),
                       "You have arrived at your destination.")
    }
}
