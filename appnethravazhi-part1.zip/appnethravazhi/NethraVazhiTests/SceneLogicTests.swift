import XCTest
@testable import NethraVazhi

/// Multi-object handling: stable identities, class voting, closest-first, grouping.
final class SceneLogicTests: XCTestCase {
    private func hazard(_ label: String, _ x1: Double, _ y1: Double, _ x2: Double, _ y2: Double,
                        conf: Double = 0.9) -> Hazard {
        Hazard(label: label, box: Box(x1: x1, y1: y1, x2: x2, y2: y2), frameWidth: 320, frameHeight: 416, confidence: conf)
    }

    private func idsLeftToRight(_ hazards: [Hazard]) -> [Int] {
        hazards.sorted { $0.box.centerX < $1.box.centerX }.map { $0.trackId }
    }

    func testThreeChairsKeepSeparateIdentitiesAndConfirm() {
        var tracker = SceneTracker()
        let a = hazard("chair", 10, 150, 70, 270)
        let b = hazard("chair", 125, 150, 195, 270)
        let c = hazard("chair", 250, 150, 310, 270)
        let first = tracker.update([a, b, c], ranOpenVocab: false)
        let second = tracker.update([c, a, b], ranOpenVocab: false)   // different order
        XCTAssertEqual(idsLeftToRight(first.all), idsLeftToRight(second.all))
        XCTAssertEqual(Set(idsLeftToRight(second.all)).count, 3)
        XCTAssertEqual(second.confirmed.count, 3)
        XCTAssertTrue(first.confirmed.isEmpty)       // needs 2 frames
    }

    func testConfirmedObjectSurvivesDroppedFramesThenDisappears() {
        var tracker = SceneTracker()
        let chair = hazard("chair", 100, 150, 200, 270)
        _ = tracker.update([chair], ranOpenVocab: false)
        _ = tracker.update([chair], ranOpenVocab: false)
        XCTAssertEqual(tracker.update([], ranOpenVocab: false).confirmed.count, 1)
        _ = tracker.update([], ranOpenVocab: false)
        XCTAssertEqual(tracker.update([], ranOpenVocab: false).confirmed.count, 1)
        XCTAssertTrue(tracker.update([], ranOpenVocab: false).all.isEmpty)
    }

    func testOneFlickerFrameDoesNotConfirm() {
        var tracker = SceneTracker()
        let chair = hazard("chair", 100, 150, 200, 270)
        _ = tracker.update([chair], ranOpenVocab: false)
        _ = tracker.update([], ranOpenVocab: false)
        _ = tracker.update([], ranOpenVocab: false)                    // unconfirmed track is gone
        XCTAssertTrue(tracker.update([chair], ranOpenVocab: false).confirmed.isEmpty)
    }

    func testClassStaysChairWhenOneFrameSaysCouch() {
        var tracker = SceneTracker()
        let box = (x1: 100.0, y1: 150.0, x2: 200.0, y2: 270.0)
        for _ in 0..<3 { _ = tracker.update([hazard("chair", box.x1, box.y1, box.x2, box.y2)], ranOpenVocab: false) }
        let result = tracker.update([hazard("couch", box.x1, box.y1, box.x2, box.y2, conf: 0.6)], ranOpenVocab: false)
        XCTAssertEqual(result.confirmed.count, 1)
        XCTAssertEqual(result.confirmed.first?.label, "chair")
    }

    func testChairAndCouchOnSameObjectAreMerged() {
        let kept = SceneLogic.suppressDuplicates([
            hazard("couch", 100, 150, 200, 270, conf: 0.6),
            hazard("chair", 102, 152, 198, 268, conf: 0.8),
        ])
        XCTAssertEqual(kept.count, 1)
        XCTAssertEqual(kept.first?.label, "chair")
    }

    func testTwoSeparateChairsAreNotMerged() {
        let kept = SceneLogic.suppressDuplicates([
            hazard("chair", 10, 150, 70, 270), hazard("chair", 80, 150, 140, 270),
        ])
        XCTAssertEqual(kept.count, 2)
    }

    func testClosestObjectIsAnnouncedFirst() {
        var far = hazard("chair", 125, 150, 195, 250);  far.trackId = 1     // lower edge 60 %
        var near = hazard("person", 0, 230, 70, 395);    near.trackId = 2    // lower edge 95 %, left
        let objects = SceneLogic.aggregate([far, near])
        XCTAssertEqual(objects.first?.trackId, 2)
        let choice = SceneLogic.chooseGuidance(objects, previousLead: nil)
        XCTAssertEqual(choice.leadId, 2)
        XCTAssertEqual(choice.guidance.label, "person")
        XCTAssertEqual(choice.guidance.alsoLabel, "chair")
    }

    func testLeadDoesNotFlipBetweenSimilarObjects() {
        var a = hazard("car", 125, 150, 195, 270); a.trackId = 1
        var b = hazard("car", 125, 150, 195, 275); b.trackId = 2
        let objects = SceneLogic.aggregate([a, b])
        let previous = objects[1].trackId
        let choice = SceneLogic.chooseGuidance(objects, previousLead: previous)
        XCTAssertEqual(choice.leadId, previous)
    }

    func testLeadSwitchesWhenAnotherObjectBecomesNear() {
        var approaching = hazard("chair", 125, 150, 195, 270); approaching.trackId = 1
        var near = hazard("chair", 20, 200, 90, 395);          near.trackId = 2
        let objects = SceneLogic.aggregate([approaching, near])
        let choice = SceneLogic.chooseGuidance(objects, previousLead: 1)
        XCTAssertEqual(choice.leadId, 2)
    }

    func testGroupOfChairsIsCountedInSpeech() {
        var chairs: [Hazard] = []
        for (i, x) in [0.0, 35.0, 70.0].enumerated() {
            var c = hazard("chair", x, 150, x + 30, 270); c.trackId = i + 1; chairs.append(c)
        }
        let choice = SceneLogic.chooseGuidance(SceneLogic.aggregate(chairs), previousLead: nil)
        XCTAssertEqual(choice.guidance.count, 3)
        let text = Messages(language: .english).spokenScene(for: SceneLogic.applyThreshold(choice.guidance))
        XCTAssertTrue(text.hasPrefix("Caution. Chair ahead on your left."))
        XCTAssertTrue(text.contains("There are 3 chairs here."))
    }

    func testPlurals() {
        XCTAssertEqual(Messages.plural("person"), "people")
        XCTAssertEqual(Messages.plural("bench"), "benches")
        XCTAssertEqual(Messages.plural("chair"), "chairs")
        XCTAssertEqual(Messages.plural("couch"), "couches")
    }

    func testFarObjectsStaySilent() {
        var far = hazard("chair", 140, 100, 170, 140); far.trackId = 1
        let choice = SceneLogic.chooseGuidance(SceneLogic.aggregate([far]), previousLead: nil)
        XCTAssertEqual(choice.guidance.key, "far")
        XCTAssertNil(choice.leadId)
    }

    // MARK: STOP only in the walking lane

    private func finalGuidance(_ h: Hazard) -> Guidance {
        var h = h; h.trackId = 1
        let choice = SceneLogic.chooseGuidance(SceneLogic.aggregate([h]), previousLead: nil)
        return SceneLogic.applyThreshold(choice.guidance)
    }

    func testNearObjectOnSideSaysSlowDownNotStop() {
        let left = finalGuidance(hazard("car", 0, 200, 70, 395))
        XCTAssertEqual(left.key, "slow_left")
        XCTAssertTrue(left.display.hasPrefix("SLOW DOWN"))
        let text = Messages(language: .english).spokenScene(for: left)
        XCTAssertTrue(text.hasPrefix("Slow down. Car close on your left. Check the right side"))
        XCTAssertFalse(text.contains("Stop"))
        XCTAssertFalse(AlertArbiter.isUrgent(left.key))

        let right = finalGuidance(hazard("chair", 250, 200, 320, 395))
        XCTAssertEqual(right.key, "slow_right")
        XCTAssertTrue(Messages(language: .english).spokenScene(for: right).contains("keep to the left"))
    }

    func testNearObjectInCentreStillSaysStop() {
        let g = finalGuidance(hazard("car", 90, 200, 230, 375))
        XCTAssertEqual(g.key, "front_blocked")
        XCTAssertTrue(Messages(language: .english).spokenScene(for: g).hasPrefix("Stop. Car ahead."))
        XCTAssertTrue(AlertArbiter.isUrgent(g.key))
    }

    func testApproachingInCentreSaysSlowDown() {
        let g = finalGuidance(hazard("chair", 110, 150, 210, 270))
        XCTAssertEqual(g.key, "caution_ahead")
        XCTAssertTrue(Messages(language: .english).spokenScene(for: g).contains("Slow down"))
    }
}
