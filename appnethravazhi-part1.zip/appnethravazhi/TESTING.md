# Nethra Vazhi – on-device test checklist

This app has **no Python server**: all three models run on the iPhone (CoreML / Neural Engine).
Items from a server-based checklist ("POST /detect", "server disconnect", "reconnects to server")
are replaced by their on-device equivalents below.

The bottom of the screen shows two diagnostic lines:
`10.0 detections/s · last result 0.1 s ago · errors 0`
`Models: COCO, Pothole, Hazards · Voice: <voice name> (<language>)`

Status key: ✅ = verified before shipping (on Linux, see README) · 📱 = you need to check on the iPhone

## 1. Mac and Xcode
| # | Test | How | Expected | Status |
|---|---|---|---|---|
| 1.1 | Build succeeds | Select iPhone, press ▶ Run | Builds without errors, app opens on the camera | 📱 (all code type-checked; core compiled & tested) |
| 1.2 | Debug configuration | Product → Scheme → Edit Scheme → Run → Info | Build Configuration = **Debug** | ✅ set in the shared scheme |
| 1.3 | Unit tests | Choose an iPhone simulator, press ⌘U | 25 tests pass (incl. the 3 real models on a photo) | 📱 (24 of 25 already pass on Linux; the model test needs a Mac) |
| 1.4 | Models loaded *(replaces "Python server starts")* | Look at the bottom line | `Models: COCO, Pothole, Hazards` | 📱 |

## 2. Camera
| # | Test | How | Expected | Status |
|---|---|---|---|---|
| 2.1 | Camera permission | Allow when asked | Live preview appears | 📱 |
| 2.2 | Camera stability | Keep app open 60 s | `detections/s` stays ~8–10, `last result` stays < 0.5 s | 📱 (the app now restarts the camera itself if frames stop for 4 s) |
| 2.3 | Detection running *(replaces "POST /detect returns 200")* | Watch the stats line | `errors 0`, detections/s not 0 | 📱 |
| 2.4 | Stall recovery *(replaces "disconnect test")* | Cover the camera / take a phone call, then return | App says "Stop…" while stalled, then recovers by itself, no crash | 📱 |

## 3. Detection
| # | Test | How | Expected | Status |
|---|---|---|---|---|
| 3.1 | Ordinary object | Point at a chair or bag, walk slowly closer | Yellow box → green, then spoken warning once "approaching/near" | ✅ simulated with real model output · 📱 |
| 3.2 | Pothole model | Point at a pothole photo on a screen / printout | `pothole` box at ≥ 0.70 confidence, "Stop. Pothole ahead…" | ✅ matches PyTorch on real pothole photos · 📱 |
| 3.3 | Stairs / curb | Point at steps or a curb, standing still | May show "possible stairs?" — the open-vocabulary model misses many scenes | 📱 (known weak spot, see README) |
| 3.4 | Poor lighting | Repeat 3.1 in dim light | Stable; fewer detections is normal (low-light boost is on) | 📱 |

## 3b. STOP threshold and slopes
| # | Test | How | Expected | Status |
|---|---|---|---|---|
| 3b.1 | Far object | Chair 4–5 m away, centre | Box appears, nothing spoken | ✅ unit test · 📱 |
| 3b.2 | Approaching | Walk slowly toward it | "Caution. Chair ahead. Slow down…" (screen shows CAUTION) | ✅ unit test + simulation · 📱 |
| 3b.3 | Near = STOP | Keep walking until ~1 m | "Stop. Chair ahead…" interrupts any caution | ✅ unit test · 📱 |
| 3b.4 | Left / right | Object in the left third of the view | "…on your left. Check the right side… keep to the right" | ✅ unit test · 📱 |
| 3b.5 | Tune distance | If STOP comes too early/late, change `closeBottomRatio` (README) | STOP moves closer/farther | 📱 |
| 3b.6 | Slope underfoot | Walk 10–15 m up a steep ramp or sloped road | "Caution. Uphill slope, about N percent…", diagnostics line shows "uphill N%" | ✅ simulated walks · 📱 |
| 3b.7 | Gentle slope | Walk on a mild slope (< 8 %) | No slope warning | ✅ simulated · 📱 |

## 4. Voice
| # | Test | How | Expected | Status |
|---|---|---|---|---|
| 4.1 | Malayalam pronunciation | Install Malayalam voice (Settings → Accessibility → Spoken Content → Voices), reopen app, trigger a warning | Bottom line shows a Malayalam voice; full warning audible | 📱 |
| 4.2 | Repeated warnings | Keep one object in view 10 s | Sentence finishes, repeats only after a pause, never overlaps | ✅ simulated: 2 sentences in 10 s, 0 overlaps |
| 4.3 | Urgent priority | Routine alert, then pothole/stairs ahead | Urgent alert interrupts routine; routine never interrupts urgent; left/right conflict → "Stop" | ✅ simulated |
| 4.4 | Audio interruption | Lock/unlock, or Siri / a call, then return | Speech works again, no crash | 📱 (audio session is now re-activated after interruptions and on resume) |

## 5. Stability
| # | Test | How | Expected | Status |
|---|---|---|---|---|
| 5.1 | Continuous run | 5–10 min stationary | No crash; stats line keeps updating; phone may get warm | 📱 |
| 5.2 | Background & resume | Switch to another app and back | Camera and speech resume (navigation stops and must be restarted with triple tap) | 📱 |
| 5.3 | Restart | Stop and run again from Xcode | Starts straight into detection, says the startup message | 📱 |

## 6. Navigation (triple tap)
| # | Test | How | Expected | Status |
|---|---|---|---|---|
| 6.1 | Voice destination | Triple tap, say a nearby place after the beep | Reads results; "yes" picks one | 📱 |
| 6.2 | Route | Outdoors with GPS | "Route ready, N meters…", then turn instructions | ✅ route maths matches osmmap.py · 📱 |
| 6.3 | Stop | Triple tap again | "Navigation stopped" | 📱 |
