# Nethra Vazhi for iPhone

An iPhone app built from your `nethracam.py` and `osmmap.py`. It opens straight into the camera in **detection mode**, where three on-device models (COCO objects, your pothole model, and street hazards) warn you by voice. **Triple tap** anywhere to switch to **navigation + detection**. The app asks by voice where you want to go, uses your current GPS location as the starting point, and gives OpenStreetMap walking directions. Camera warnings keep running and always take priority over directions.

It speaks English by default. If the iPhone has a Malayalam voice installed, it speaks Malayalam automatically.

---

## 1. Build and install (on a Mac)

You need:
* A Mac with **Xcode 16 or newer** (free from the Mac App Store).
* Your iPhone 15 Pro with iOS 17 or later.
* A USB-C cable.
* An Apple ID. A free one works, but the app then expires after 7 days and you re-run step 6 to reinstall it.

Steps:
1. Unzip `NethraVazhi.zip` and double-click **`NethraVazhi.xcodeproj`**.
2. In Xcode, click the blue **NethraVazhi** project at the top-left, select the **NethraVazhi** target, and open the **Signing & Capabilities** tab.
3. Under **Team**, choose your Apple ID. If it isn't listed, use *Add an Account…* to sign in.
   If Xcode says the bundle identifier is unavailable, change `com.nethravazhi.NethraVazhi` to something unique, such as `com.yourname.nethravazhi`.
4. On the iPhone, turn on **Settings → Privacy & Security → Developer Mode** (the iPhone restarts). Then connect it to the Mac and tap **Trust**.
5. At the top of Xcode, choose your iPhone as the run destination.
6. Press **▶ Run** (⌘R). The first build takes a minute while Xcode compiles the models.
7. The first time only, open **Settings → General → VPN & Device Management** on the iPhone, tap your Apple ID and choose **Trust**. Then open the app.
8. Allow **Camera**, **Microphone**, **Speech Recognition**, **Location** and **Motion & Fitness** when the app asks.

### Run the tests (optional)
Choose any iPhone **simulator** as the destination and press **⌘U**. There are 25 tests:
* Replays of your original Python code's behaviour: detection confirmation, left/right/centre, near/approaching, which alert wins, cooldowns, Malayalam sentences, route progress, and turn translations. The Swift code must produce identical answers.
* The YOLO output decoder checked against real model outputs.
* The three bundled CoreML models loaded and run on a photo; they must find the people and the bus.
* STOP-threshold bands (far / caution / stop, left / right / ahead) and slope detection on simulated walks.

---

## 2. Using the app

| Gesture (anywhere on screen) | What it does |
|---|---|
| **Triple tap** | Switch from DETECTION to NAVIGATION + DETECTION (asks "Where do you want to go?"). Triple tap again to go back to DETECTION only. |

There are no buttons. The screen shows only the mode badge, the route status (while navigating) and the current warning. If a model cannot be loaded, a red box shows the exact error.

The gesture also works with VoiceOver on, because the camera view allows direct touch.

**Detection mode** works like your Python app:
* An object must be seen in 2 frames in a row (3 for people and street hazards) before it's announced.
* It only alerts when an object is *approaching* or *near*, and names the object and its side ("Stop. Car on your left. Check the right side with your cane…").
* Potholes and stairs ahead get the strongest warning.
* "Nothing detected" is repeated at most every 15 seconds.
* If detection stalls for more than 1.5 seconds, it says STOP.
* Boxes on screen are **yellow** while still being checked and **green** once confirmed.

**Distance bands (STOP threshold):** each confirmed object is put in one of three bands using where its lower edge sits in the picture.

| Band | When | What is spoken |
|---|---|---|
| far | lower edge above 58 % of the frame and small | nothing |
| approaching | lower edge between 58 % and 82 % (or medium size) | **"Caution. Car ahead on your left. Check the right side with your cane and keep to the right."** |
| near (STOP) | lower edge below 82 % **and** large enough | **"Stop. Car on your left. Check the right side with your cane. Move right only after…"** (your Malayalam sentences from nethracam.py) |

Left = left 30 % of the frame, right = right 30 %, centre = the middle 40 % walking lane. A STOP always interrupts a caution; a caution never interrupts a STOP. Stairs ahead are always STOP.
To change where STOP starts, edit `DetectionConfig.closeBottomRatio` in `NethraVazhi/Core/HazardLogic.swift`: **0.82** is the default; lower it (e.g. 0.75) to say STOP earlier/farther away, raise it (e.g. 0.88) to say STOP later. `approachBottomRatio` (0.58) controls where "Caution" starts.

**Multiple objects (e.g. several chairs):**
* Every object gets its own tracker id (shown on the boxes as `chair #1`, `chair #2`). Matching is done globally, best pairs first, so neighbouring chairs can no longer swap identities, and an object survives a few dropped frames instead of restarting its confirmation.
* Look-alike classes (chair / couch / bench / table, car / truck / bus, bicycle / motorcycle) are merged when they sit on the same object, and the final class is decided by a vote over several frames, so a chair is not announced as a couch for one frame.
* An object is confirmed only after enough frames **and** a stable class **and** enough average confidence. Chair, couch, bench, table and plant also need a slightly higher minimum confidence (`SceneConfig.sceneMinConfidence`).
* **Closest first:** objects are ranked by how near they are (lower edge of the box, size, walking lane, moving things like people and vehicles). The closest one is announced first; a second, different close object is added as "Also person on your right."
* Same objects on the same side are grouped: "Caution. Chair ahead on your left. ... There are 3 chairs here."
* The lead object only changes when another one is clearly more important (15 % higher score) or becomes "near", so the voice does not jump between two similar objects. Settings are in `NethraVazhi/Core/SceneLogic.swift` (`SceneConfig`).
* The Malayalam wording for the count and "also" sentences is new (not from nethracam.py); please have a Malayalam speaker check it.

**Making the models themselves more accurate:** the logic above removes many false and duplicate detections, but it cannot add accuracy the models do not have. For that, re-export with a bigger model and larger input, for example
`python3 tools/export_models.py --coco yolo26s.pt --imgsz 640 480 --pothole best.pt`
(the app reads the input size from the model). For your own surroundings, fine-tune the COCO model on photos from your street / home with chairs, steps and poles.

**Slope warnings:**
* *Ahead (camera):* if the ramp detector sees a ramp: "Caution. Possible ramp or slope ahead. Walk slowly…".
* *Underfoot (sensors):* the barometer measures height change and the step counter measures distance. If the slope over the last 6 m is **8 % or steeper** (the steepest a wheelchair ramp is allowed to be): "Caution. Uphill/Downhill slope, about 10 percent…", then "The slope has ended" on level ground. Thresholds are in `NethraVazhi/Core/SlopeLogic.swift` (`warnGradePercent`, `windowMeters`). The current slope also shows on the diagnostics line. iOS asks for **Motion & Fitness** permission the first time.

**Navigation + detection mode:**
1. After the beep, say your destination, e.g. "Lulu Mall Kochi" or "Ernakulam South railway station".
2. The app reads out search results one by one. Say **yes** (or *athe* / *shari*) to choose one, or **no** (*illa*) for the next. "Cancel" stops.
3. Your **current GPS location** is the starting point. If GPS isn't ready within about 20 seconds, the app asks *"Where are you now?"* and you can say your starting place.
4. Turn-by-turn directions are spoken only when the camera reports no close obstacle. If you go more than 45 m off the route, it warns you and fetches a new route. Within 15 m of the destination it says you have arrived.

### Malayalam voice
iOS has a Malayalam voice, but you have to download it: **Settings → Accessibility → Spoken Content → Voices → Malayalam**. Download a voice, then fully close and reopen Nethra Vazhi. All warnings and directions then switch to Malayalam, using the exact sentences from your Python code.
Apple speech recognition doesn't support Malayalam, so destinations are always *heard* with the Indian-English recogniser. Place names work fine, and yes/no can be said in English or Malayalam.

---

## 3. What's inside

```
NethraVazhi.xcodeproj
NethraVazhi/
  App/        NethraVazhiApp, ContentView (camera + gestures), AppModel, Navigator (voice navigation), AppConfig
  Core/       HazardLogic, AlertArbiter, Messages, RouteLogic, YOLODecoder   ← ported 1:1 from your Python
  Services/   Camera, Detector (3 CoreML models), Speech, VoiceInput, Location, Routing (ORS + Apple Maps fallback)
  Models/     COCODetector, PotholeDetector (your best.pt), HazardDetector   ← CoreML, 320x416 portrait
NethraVazhiTests/   unit tests + golden data generated from your Python code
tools/      export_models.py, make_golden_tests.py, make_xcodeproj.py
```

### Notes
* **Third model:** your Python used YOLO-World (`yolov8s-worldv2.pt`), which needs OpenAI's CLIP weights to learn the prompts. I couldn't download those, so the app uses **YOLOE-26s**, Ultralytics' newer open-vocabulary model, with the same 10 prompts (stairs, curb, ramp, traffic cone, bollard, barrier, doorway, glass door, pole, wall).
  In tests it detected walls reliably but was weak on thin street objects like poles and curbs; YOLO-World tends to have the same weakness. To try YOLO-World instead, run `tools/export_models.py --hazard-model yolov8s-worldv2.pt --pothole <best.pt>` on a machine that can download CLIP.
* **Routing** uses the OpenRouteService key from `osmmap.py` (in `App/AppConfig.swift`). If it stops working, get a free key at openrouteservice.org and paste it there. If ORS fails, the app falls back to Apple Maps for place search and walking routes.
* The phone must be held **upright (portrait)** with the back camera facing forward, at chest height.
* As in your original app, the camera never says a path is safe. It's an aid alongside the cane, not a replacement for it.
