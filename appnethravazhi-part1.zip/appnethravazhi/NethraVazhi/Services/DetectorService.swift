import CoreML
import Vision
import ImageIO

/// Result of one detection cycle.
struct DetectionFrame {
    /// All candidates this cycle (confirmed ones are flagged) for drawing boxes.
    var candidates: [Hazard]
    /// Confirmed objects with side / proximity / priority, highest first.
    var objects: [Hazard]
    var guidance: Guidance
    var frameWidth: Double
    var frameHeight: Double
}

/// Runs the three models from nethracam.py on the iPhone Neural Engine:
///  1. COCO objects   (yolo26n)
///  2. Potholes       (your trained pothole_yolo26 best.pt)
///  3. Open-vocabulary street hazards (stairs, curb, pole, ...) every 3rd cycle
final class DetectorService {
    private struct LoadedModel {
        let request: VNCoreMLRequest
        let names: [String]
        let width: Double
        let height: Double
    }

    private var coco: LoadedModel?
    private var pothole: LoadedModel?
    private var hazard: LoadedModel?
    private var scene = SceneTracker()
    private var leadId: Int?
    private var cycle = 0
    private(set) var loadErrors: [String] = []
    private(set) var loadNotes: [String] = []

    var isReady: Bool { coco != nil || pothole != nil || hazard != nil }
    var loadedModelNames: [String] {
        var n: [String] = []
        if coco != nil { n.append("COCO") }
        if pothole != nil { n.append("Pothole") }
        if hazard != nil { n.append("Hazards") }
        return n
    }

    func load() {
        coco = loadModel(AppConfig.cocoModelName, fallbackNames: DetectorService.cocoNames)
        pothole = loadModel(AppConfig.potholeModelName, fallbackNames: ["pothole"])
        hazard = loadModel(AppConfig.hazardModelName, fallbackNames: DetectionConfig.openVocabLabels.map { $0.prompt })
    }

    /// Finds the model in the app bundle. Xcode normally compiles the .mlpackage into a .mlmodelc;
    /// if it was only copied as a .mlpackage, it is compiled here on first launch and cached.
    private func compiledModelURL(_ name: String) -> URL? {
        if let url = Bundle.main.url(forResource: name, withExtension: "mlmodelc") { return url }
        guard let package = Bundle.main.url(forResource: name, withExtension: "mlpackage") else { return nil }
        let fm = FileManager.default
        do {
            let cacheDir = try fm.url(for: .applicationSupportDirectory, in: .userDomainMask,
                                      appropriateFor: nil, create: true).appendingPathComponent("CompiledModels", isDirectory: true)
            try fm.createDirectory(at: cacheDir, withIntermediateDirectories: true)
            let cached = cacheDir.appendingPathComponent("\(name).mlmodelc", isDirectory: true)
            if fm.fileExists(atPath: cached.path) { return cached }
            let temp = try MLModel.compileModel(at: package)
            try? fm.removeItem(at: cached)
            try fm.copyItem(at: temp, to: cached)
            return cached
        } catch {
            loadErrors.append("\(name): could not compile .mlpackage (\(error.localizedDescription))")
            return nil
        }
    }

    private func loadModel(_ name: String, fallbackNames: [String]) -> LoadedModel? {
        guard let url = compiledModelURL(name) else {
            if !loadErrors.contains(where: { $0.hasPrefix(name) }) {
                loadErrors.append("\(name): not found in the app bundle (check Target Membership)")
            }
            return nil
        }
        // Neural Engine first; some models fail to load there, so retry on GPU and then CPU.
        let attempts: [(MLComputeUnits, String)] = [(.all, "Neural Engine"), (.cpuAndGPU, "GPU"), (.cpuOnly, "CPU")]
        var lastError = "unknown error"
        for (units, unitName) in attempts {
            do {
                let config = MLModelConfiguration()
                config.computeUnits = units
                let model = try MLModel(contentsOf: url, configuration: config)
                let vnModel = try VNCoreMLModel(for: model)
                let request = VNCoreMLRequest(model: vnModel)
                request.imageCropAndScaleOption = .scaleFill
                var width = 320.0, height = 416.0
                if let input = model.modelDescription.inputDescriptionsByName.values.first,
                   let constraint = input.imageConstraint {
                    width = Double(constraint.pixelsWide)
                    height = Double(constraint.pixelsHigh)
                }
                let metadata = model.modelDescription.metadata[MLModelMetadataKey.creatorDefinedKey] as? [String: String]
                let names = DetectorService.parseNames(metadata?["names"]) ?? fallbackNames
                if units != .all { loadNotes.append("\(name) runs on \(unitName)") }
                return LoadedModel(request: request, names: names, width: width, height: height)
            } catch {
                lastError = "\(unitName): \(error.localizedDescription)"
            }
        }
        loadErrors.append("\(name): \(lastError)")
        // A cached compiled copy might be damaged; remove it so the next launch compiles again.
        if url.path.contains("CompiledModels") { try? FileManager.default.removeItem(at: url) }
        return nil
    }

    static func parseNames(_ text: String?) -> [String]? { YOLODecoder.parseNames(text) }

    /// One detection cycle on a camera frame (phone held upright, back camera).
    func process(_ pixelBuffer: CVPixelBuffer) throws -> DetectionFrame {
        cycle += 1
        var requests: [VNCoreMLRequest] = []
        if let m = coco { requests.append(m.request) }
        if let m = pothole { requests.append(m.request) }
        let runHazard = hazard != nil && cycle % DetectionConfig.openVocabEveryNCycles == 0
        if runHazard, let m = hazard { requests.append(m.request) }

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .right, options: [:])
        try handler.perform(requests)

        // Work in the model's pixel space (320 x 416) like the Python frame pixels.
        let frameW = coco?.width ?? pothole?.width ?? 320
        let frameH = coco?.height ?? pothole?.height ?? 416
        var candidates: [Hazard] = []

        if let m = coco {
            for d in decode(m, minConfidence: DetectionConfig.cocoModelConfidence) {
                let name = d.classIndex < m.names.count ? m.names[d.classIndex].lowercased() : "\(d.classIndex)"
                guard HazardLogic.isReliableCocoDetection(name, confidence: d.confidence) else { continue }
                guard d.confidence >= (SceneConfig.sceneMinConfidence[name] ?? 0) else { continue }
                candidates.append(makeHazard(d, label: name, frameW: frameW, frameH: frameH))
            }
        }
        if let m = pothole {
            for d in decode(m, minConfidence: DetectionConfig.potholeConfidence) {
                var h = makeHazard(d, label: "pothole", frameW: frameW, frameH: frameH)
                h.isPothole = true
                candidates.append(h)
            }
        }
        if runHazard, let m = hazard {
            for d in decode(m, minConfidence: DetectionConfig.openVocabMinConfidence) {
                guard d.classIndex >= 0 && d.classIndex < DetectionConfig.openVocabLabels.count else { continue }
                var h = makeHazard(d, label: DetectionConfig.openVocabLabels[d.classIndex].label, frameW: frameW, frameH: frameH)
                h.openVocab = true
                candidates.append(h)
            }
        }

        // Remove duplicate boxes (chair/couch on the same object), then track every object
        // separately so three chairs stay three chairs, then announce the closest first.
        let cleaned = SceneLogic.suppressDuplicates(candidates)
        let result = scene.update(cleaned, ranOpenVocab: runHazard)
        let objects = SceneLogic.aggregate(result.confirmed)
        let choice = SceneLogic.chooseGuidance(objects, previousLead: leadId)
        leadId = choice.leadId
        let guidance = choice.guidance
        return DetectionFrame(candidates: result.all, objects: objects, guidance: guidance,
                              frameWidth: frameW, frameHeight: frameH)
    }

    /// For tests and diagnostics: run one bundled model on an upright image.
    /// `which` is "coco", "pothole" or "hazard". Returns (label, confidence) pairs.
    func detect(model which: String, cgImage: CGImage, minConfidence: Double) throws -> [(String, Double)] {
        let chosen: LoadedModel?
        switch which {
        case "coco": chosen = coco
        case "pothole": chosen = pothole
        default: chosen = hazard
        }
        guard let m = chosen else { return [] }
        let handler = VNImageRequestHandler(cgImage: cgImage, orientation: .up, options: [:])
        try handler.perform([m.request])
        return decode(m, minConfidence: minConfidence).map { d in
            (d.classIndex < m.names.count ? m.names[d.classIndex] : "\(d.classIndex)", d.confidence)
        }
    }

    func resetTracking() {
        scene = SceneTracker()
        leadId = nil
    }

    private func makeHazard(_ d: RawDetection, label: String, frameW: Double, frameH: Double) -> Hazard {
        Hazard(label: label,
               box: Box(x1: (d.x1 * frameW).rounded(.towardZero), y1: (d.y1 * frameH).rounded(.towardZero),
                        x2: (d.x2 * frameW).rounded(.towardZero), y2: (d.y2 * frameH).rounded(.towardZero)),
               frameWidth: frameW, frameHeight: frameH, confidence: d.confidence)
    }

    private func decode(_ m: LoadedModel, minConfidence: Double) -> [RawDetection] {
        guard let observations = m.request.results as? [VNCoreMLFeatureValueObservation] else { return [] }
        // Use the largest multi-array output (the detection tensor).
        var best: MLMultiArray?
        for o in observations {
            if let a = o.featureValue.multiArrayValue, a.count > (best?.count ?? 0) { best = a }
        }
        guard let array = best else { return [] }
        let (values, shape) = DetectorService.floats(array)
        return YOLODecoder.decode(values: values, shape: shape, inputWidth: m.width, inputHeight: m.height,
                                  minConfidence: minConfidence)
    }

    /// Reads any MLMultiArray (Float16/32/Double, any strides) into a flat Float array.
    static func floats(_ a: MLMultiArray) -> ([Float], [Int]) {
        let shape = a.shape.map { $0.intValue }
        let total = shape.reduce(1, *)
        var out = [Float]()
        out.reserveCapacity(total)
        var index = [Int](repeating: 0, count: shape.count)
        for _ in 0..<total {
            out.append(a[index.map { NSNumber(value: $0) }].floatValue)
            var d = shape.count - 1
            while d >= 0 {
                index[d] += 1
                if index[d] < shape[d] { break }
                index[d] = 0
                d -= 1
            }
        }
        return (out, shape)
    }

    static let cocoNames = ["person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat",
        "traffic light", "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep",
        "cow", "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
        "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard",
        "tennis racket", "bottle", "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich",
        "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant", "bed",
        "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone", "microwave", "oven",
        "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush"]
}
