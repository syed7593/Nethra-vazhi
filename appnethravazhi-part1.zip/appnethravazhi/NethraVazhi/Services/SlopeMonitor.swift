import CoreMotion
import Foundation

/// Measures the slope the user is walking on with the barometer (CMAltimeter)
/// and step distance (CMPedometer). Works without GPS, indoors and outdoors.
final class SlopeMonitor: @unchecked Sendable {
    private let altimeter = CMAltimeter()
    private let pedometer = CMPedometer()
    private let queue: OperationQueue = {
        let q = OperationQueue()
        q.maxConcurrentOperationCount = 1
        q.name = "nethra.slope"
        return q
    }()
    private var tracker = SlopeTracker()
    private var altitude: Double?
    private var running = false
    /// Called on the slope queue when the user should be told about a slope.
    var onEvent: (@Sendable (SlopeEvent) -> Void)?

    static var isAvailable: Bool { CMAltimeter.isRelativeAltitudeAvailable() && CMPedometer.isDistanceAvailable() }

    func start() {
        guard !running, SlopeMonitor.isAvailable else { return }
        running = true
        tracker = SlopeTracker()
        altitude = nil
        altimeter.startRelativeAltitudeUpdates(to: queue) { [weak self] data, _ in
            guard let self = self, let data = data else { return }
            self.altitude = data.relativeAltitude.doubleValue
        }
        pedometer.startUpdates(from: Date()) { [weak self] data, _ in
            guard let self = self, let distance = data?.distance?.doubleValue else { return }
            self.queue.addOperation {
                guard let altitude = self.altitude else { return }
                if let event = self.tracker.add(distance: distance, altitude: altitude,
                                                time: ProcessInfo.processInfo.systemUptime) {
                    self.onEvent?(event)
                }
            }
        }
    }

    func stop() {
        guard running else { return }
        running = false
        altimeter.stopRelativeAltitudeUpdates()
        pedometer.stopUpdates()
    }
}
