import AVFoundation

/// Back camera feed. Uses a 4:3 (640x480) stream, which matches the models'
/// 320x416 portrait input with almost no stretching.
final class CameraService: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate, @unchecked Sendable {
    let session = AVCaptureSession()
    private let output = AVCaptureVideoDataOutput()
    private let queue = DispatchQueue(label: "nethra.camera", qos: .userInitiated)
    private var configured = false
    private var observers: [NSObjectProtocol] = []
    /// What the app wants (the session itself can stop on errors / interruptions).
    private var wantsRunning = false
    /// Called on the camera queue for every frame. Blocking here drops late frames.
    var onFrame: (@Sendable (CVPixelBuffer) -> Void)?

    static func requestPermission() async -> Bool {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: return true
        case .notDetermined: return await AVCaptureDevice.requestAccess(for: .video)
        default: return false
        }
    }

    func configure() throws {
        guard !configured else { return }
        session.beginConfiguration()
        defer { session.commitConfiguration() }
        if session.canSetSessionPreset(.vga640x480) {
            session.sessionPreset = .vga640x480
        } else {
            session.sessionPreset = .high
        }
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            throw NSError(domain: "Nethra", code: 1, userInfo: [NSLocalizedDescriptionKey: "No back camera"])
        }
        let input = try AVCaptureDeviceInput(device: device)
        guard session.canAddInput(input) else {
            throw NSError(domain: "Nethra", code: 2, userInfo: [NSLocalizedDescriptionKey: "Cannot use camera"])
        }
        session.addInput(input)
        output.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
        output.alwaysDiscardsLateVideoFrames = true
        output.setSampleBufferDelegate(self, queue: queue)
        guard session.canAddOutput(output) else {
            throw NSError(domain: "Nethra", code: 3, userInfo: [NSLocalizedDescriptionKey: "Cannot read camera frames"])
        }
        session.addOutput(output)
        if let connection = output.connection(with: .video), connection.isVideoStabilizationSupported {
            connection.preferredVideoStabilizationMode = .standard
        }
        do {
            try device.lockForConfiguration()
            if device.isFocusModeSupported(.continuousAutoFocus) { device.focusMode = .continuousAutoFocus }
            if device.isExposureModeSupported(.continuousAutoExposure) { device.exposureMode = .continuousAutoExposure }
            device.activeVideoMaxFrameDuration = CMTime(value: 1, timescale: 30)
            if device.isLowLightBoostSupported { device.automaticallyEnablesLowLightBoostWhenAvailable = true }
            device.unlockForConfiguration()
        } catch {
            print("Camera config warning: \(error)")
        }
        configured = true
        // Restart automatically after camera runtime errors (e.g. media services reset).
        observers.append(NotificationCenter.default.addObserver(
            forName: AVCaptureSession.runtimeErrorNotification, object: session, queue: nil) { [weak self] _ in
            print("Camera runtime error - restarting")
            guard let camera = self else { return }
            camera.queue.asyncAfter(deadline: .now() + 0.5) { camera.startIfWanted() }
        })
        observers.append(NotificationCenter.default.addObserver(
            forName: AVCaptureSession.interruptionEndedNotification, object: session, queue: nil) { [weak self] _ in
            guard let camera = self else { return }
            camera.queue.async { camera.startIfWanted() }
        })
    }

    private func startIfWanted() {
        if wantsRunning && !session.isRunning { session.startRunning() }
    }

    func start() {
        wantsRunning = true
        queue.async { self.startIfWanted() }
    }

    func stop() {
        wantsRunning = false
        queue.async { if self.session.isRunning { self.session.stopRunning() } }
    }

    /// Stop and start again (used when frames stop arriving).
    func restart() {
        queue.async {
            if self.session.isRunning { self.session.stopRunning() }
            self.startIfWanted()
        }
    }

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let buffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        onFrame?(buffer)
    }
}
