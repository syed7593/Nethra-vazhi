import Foundation
import MapKit

/// Place search and walking routes.
/// Primary: OpenRouteService (OpenStreetMap data), exactly as osmmap.py.
/// Fallback: Apple Maps (MapKit) if ORS fails or finds nothing.
final class RoutingService {
    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = AppConfig.requestTimeoutSeconds
        return URLSession(configuration: config)
    }()

    // MARK: Place search
    func searchPlaces(_ query: String, near: Coordinate?) async -> [PlaceResult] {
        if let coordinate = RouteLogic.parseCoordinate(query) {
            return [PlaceResult(label: query, coordinate: coordinate)]
        }
        var results: [PlaceResult] = []
        do {
            results = try await orsGeocode(query, near: near)
        } catch {
            print("ORS place search failed: \(error)")
        }
        if results.isEmpty {
            results = await appleSearch(query, near: near)
        }
        return Array(results.prefix(5))
    }

    private func orsGeocode(_ query: String, near: Coordinate?) async throws -> [PlaceResult] {
        guard !AppConfig.orsApiKey.isEmpty else { return [] }
        var components = URLComponents(string: AppConfig.orsGeocodeURL)!
        var items = [URLQueryItem(name: "text", value: query), URLQueryItem(name: "size", value: "5")]
        if let near = near {
            items.append(URLQueryItem(name: "focus.point.lat", value: String(near.lat)))
            items.append(URLQueryItem(name: "focus.point.lon", value: String(near.lon)))
        }
        components.queryItems = items
        var request = URLRequest(url: components.url!)
        request.setValue(AppConfig.orsApiKey, forHTTPHeaderField: "Authorization")
        let (data, response) = try await session.data(for: request)
        try check(response, data)
        return try RouteLogic.parseGeocode(data, fallbackLabel: query)
    }

    private func appleSearch(_ query: String, near: Coordinate?) async -> [PlaceResult] {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query
        if let near = near {
            request.region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: near.lat, longitude: near.lon),
                                                latitudinalMeters: 30_000, longitudinalMeters: 30_000)
        }
        do {
            let response = try await MKLocalSearch(request: request).start()
            return response.mapItems.map { item in
                let c = item.placemark.coordinate
                var label = item.name ?? query
                if let locality = item.placemark.locality, !label.contains(locality) { label += ", \(locality)" }
                return PlaceResult(label: label, coordinate: Coordinate(lat: c.latitude, lon: c.longitude))
            }
        } catch {
            print("Apple place search failed: \(error)")
            return []
        }
    }

    // MARK: Walking route
    func walkingRoute(from start: Coordinate, to destination: Coordinate) async throws -> WalkingRoute {
        do {
            return try await orsRoute(from: start, to: destination)
        } catch {
            print("ORS route failed, trying Apple Maps: \(error)")
            return try await appleRoute(from: start, to: destination)
        }
    }

    private func orsRoute(from start: Coordinate, to destination: Coordinate) async throws -> WalkingRoute {
        guard !AppConfig.orsApiKey.isEmpty else { throw RouteError.badResponse("No ORS API key") }
        var request = URLRequest(url: URL(string: AppConfig.orsDirectionsURL)!)
        request.httpMethod = "POST"
        request.setValue(AppConfig.orsApiKey, forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let payload: [String: Any] = [
            "coordinates": [[start.lon, start.lat], [destination.lon, destination.lat]],
            "instructions": true,
            "language": "en",
            "units": "m",
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: payload)
        let (data, response) = try await session.data(for: request)
        try check(response, data)
        return try RouteLogic.parseORSRoute(data)
    }

    private func appleRoute(from start: Coordinate, to destination: Coordinate) async throws -> WalkingRoute {
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: start.lat, longitude: start.lon)))
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: destination.lat, longitude: destination.lon)))
        request.transportType = .walking
        let response = try await MKDirections(request: request).calculate()
        guard let route = response.routes.first else { throw RouteError.badResponse("No walking route found") }
        var geometry: [Coordinate] = []
        var steps: [RouteStep] = []
        for step in route.steps {
            let count = step.polyline.pointCount
            guard count > 0 else { continue }
            var coords = [CLLocationCoordinate2D](repeating: CLLocationCoordinate2D(), count: count)
            step.polyline.getCoordinates(&coords, range: NSRange(location: 0, length: count))
            let startIndex = max(0, geometry.count - 1)
            for (i, c) in coords.enumerated() {
                // Consecutive steps share their joining point.
                if i == 0 && !geometry.isEmpty { continue }
                geometry.append(Coordinate(lat: c.latitude, lon: c.longitude))
            }
            let text = step.instructions.isEmpty ? (steps.isEmpty ? "Head straight" : "Continue") : step.instructions
            steps.append(RouteStep(instruction: text, distanceM: step.distance, durationS: step.distance / 1.3,
                                   startIndex: startIndex, endIndex: max(startIndex, geometry.count - 1), type: -1))
        }
        guard !geometry.isEmpty, !steps.isEmpty else { throw RouteError.badResponse("Empty walking route") }
        steps.append(RouteStep(instruction: "Arrive at your destination", distanceM: 0, durationS: 0,
                               startIndex: geometry.count - 1, endIndex: geometry.count - 1, type: 10))
        return WalkingRoute(geometry: geometry, steps: steps, distanceM: route.distance, durationS: route.expectedTravelTime)
    }

    private func check(_ response: URLResponse, _ data: Data) throws {
        if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            let detail = String(data: data.prefix(300), encoding: .utf8) ?? ""
            throw RouteError.badResponse("HTTP \(http.statusCode): \(detail)")
        }
    }
}
