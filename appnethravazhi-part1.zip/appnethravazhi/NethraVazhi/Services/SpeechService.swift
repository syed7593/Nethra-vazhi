import AVFoundation
import UIKit

/// Text-to-speech. English by default; if the iPhone has a Malayalam voice
/// installed (Settings > Accessibility > Spoken Content > Voices), Malayalam is used.
final class SpeechService: NSObject, AVSpeechSynthesizerDelegate {
    private let synthesizer = AVSpeechSynthesizer()
    private(set) var language: AppLanguage = .english
    private var voice: AVSpeechSynthesisVoice?
    private var arbiter = AlertArbiter()
    private let lock = NSLock()
    /// True from the moment a sentence is started until it finishes (or the safety timeout passes).
    private var speaking = false
    private var busyUntil: Double = 0
    private var currentUtterance: ObjectIdentifier?
    /// One sentence waiting for the current one to end (used for one-shot events such as slope warnings).
    private var pending: (key: String, text: String)?
    private var finishHandlers: [ObjectIdentifier: () -> Void] = [:]
    var messages: Messages { Messages(language: language) }
    /// Last sentence actually spoken (for "repeat").
    private(set) var lastSpokenText: String?

    override init() {
        super.init()
        synthesizer.delegate = self
        synthesizer.usesApplicationAudioSession = true
        chooseVoice()
    }

    /// Malayalam if a ml voice exists on this iPhone, otherwise English (Indian English preferred).
    func chooseVoice() {
        let voices = AVSpeechSynthesisVoice.speechVoices()
        func best(_ prefix: String) -> AVSpeechSynthesisVoice? {
            let matches = voices.filter { $0.language.lowercased().hasPrefix(prefix) }
            return matches.max { $0.quality.rawValue < $1.quality.rawValue }
        }
        if let ml = best("ml") {
            language = .malayalam
            voice = ml
        } else {
            language = .english
            voice = best("en-in") ?? AVSpeechSynthesisVoice(language: "en-IN") ?? best("en-gb") ?? AVSpeechSynthesisVoice(language: "en-US")
        }
    }

    var voiceDescription: String {
        guard let voice = voice else { return language == .malayalam ? "Malayalam" : "English" }
        return "\(voice.name) (\(voice.language))"
    }

    static func configureAudioSession() {
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(.playAndRecord, mode: .default,
                                    options: [.defaultToSpeaker, .duckOthers, .allowBluetoothA2DP])
            try session.setActive(true)
        } catch {
            print("Audio session error: \(error)")
        }
    }

    var isSpeaking: Bool { synthesizer.isSpeaking }

    /// Arbitrated speech for alerts (same rules as play_tts in nethracam.py).
    /// Returns true when this sentence was started (false if skipped or replaced by a safety stop).
    @discardableResult
    func speakAlert(key: String, text: String, explicit: Bool = false, queueIfBusy: Bool = false,
                    completion: (() -> Void)? = nil) -> Bool {
        lock.lock()
        // One dialogue is always completed before the next starts. Camera alerts are repeated every
        // cycle, so the newest one is spoken as soon as the current sentence ends. Only direct
        // user gestures (explicit) may cut in.
        if AppConfig.finishSentenceBeforeNext && !explicit
            && speaking && ProcessInfo.processInfo.systemUptime < busyUntil {
            if queueIfBusy { pending = (key, text) }
            lock.unlock()
            return false
        }
        let decision = arbiter.decide(key: key, text: text, explicit: explicit,
                                      now: ProcessInfo.processInfo.systemUptime,
                                      audioBusy: synthesizer.isSpeaking,
                                      safetyStopText: messages.safetyStop)
        lock.unlock()
        switch decision {
        case .skip:
            return false
        case .speak(let spokenKey, let spokenText):
            if AlertArbiter.isUrgent(spokenKey) {
                DispatchQueue.main.async {
                    UINotificationFeedbackGenerator().notificationOccurred(.warning)
                }
            }
            start(spokenText, completion: completion)
            return spokenKey == key
        }
    }

    /// Unconditional speech for conversation prompts (interrupts anything).
    func say(_ text: String, completion: (() -> Void)? = nil) {
        lock.lock()
        _ = arbiter.decide(key: "nav_prompt", text: text, explicit: true,
                           now: ProcessInfo.processInfo.systemUptime, audioBusy: false,
                           safetyStopText: messages.safetyStop)
        lock.unlock()
        start(text, completion: completion)
    }

    /// Speak and wait until finished (used by the navigation conversation).
    func sayAndWait(_ text: String) async {
        let once = OneShot()
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            say(text) { if once.fire() { continuation.resume() } }
            // Safety net in case the synthesizer never reports completion.
            let limit = 4.0 + Double(text.count) * 0.12
            DispatchQueue.main.asyncAfter(deadline: .now() + limit) {
                if once.fire() { continuation.resume() }
            }
        }
    }

    func stop() {
        DispatchQueue.main.async { self.synthesizer.stopSpeaking(at: .immediate) }
    }

    private func start(_ text: String, completion: (() -> Void)?) {
        lock.lock()
        speaking = true
        busyUntil = ProcessInfo.processInfo.systemUptime + 3.0 + Double(text.count) * 0.12
        lock.unlock()
        DispatchQueue.main.async {
            if self.synthesizer.isSpeaking { self.synthesizer.stopSpeaking(at: .immediate) }
            let utterance = AVSpeechUtterance(string: text)
            utterance.voice = self.voice
            utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 1.02
            utterance.prefersAssistiveTechnologySettings = true
            self.lastSpokenText = text
            self.currentUtterance = ObjectIdentifier(utterance)
            if let completion = completion {
                self.finishHandlers[ObjectIdentifier(utterance)] = completion
            }
            self.synthesizer.speak(utterance)
        }
    }

    private func finish(_ utterance: AVSpeechUtterance) {
        DispatchQueue.main.async {
            // A cancelled older sentence must not mark the new one as finished.
            if self.currentUtterance == ObjectIdentifier(utterance) {
                self.currentUtterance = nil
                self.lock.lock()
                self.speaking = false
                let next = self.pending
                self.pending = nil
                self.lock.unlock()
                if let next = next { self.speakAlert(key: next.key, text: next.text) }
            }
            if let handler = self.finishHandlers.removeValue(forKey: ObjectIdentifier(utterance)) { handler() }
        }
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        finish(utterance)
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        finish(utterance)
    }

    /// Short tone-like cue before listening (uses a system sound).
    func beep() {
        AudioServicesPlaySystemSound(1113)
    }
}

/// Lets exactly one caller win (used to resume a continuation once).
final class OneShot {
    private let lock = NSLock()
    private var fired = false
    func fire() -> Bool {
        lock.lock(); defer { lock.unlock() }
        if fired { return false }
        fired = true
        return true
    }
}
