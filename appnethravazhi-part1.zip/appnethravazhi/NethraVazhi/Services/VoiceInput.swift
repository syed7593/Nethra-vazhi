import AVFoundation
import Speech

/// Listens for one spoken answer using Apple speech recognition.
/// Malayalam recognition is used when the voice language is Malayalam and the
/// iPhone supports it; otherwise Indian English (falls back to US English).
final class VoiceInput {
    private let audioEngine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var session: ListenSession?

    /// Mutable state of one listening attempt (a class so closures share it).
    private final class ListenSession {
        let lock = NSLock()
        var finished = false
        var bestText = ""
        var lastChange = Date()
        let started = Date()
        var continuation: CheckedContinuation<String, Never>?

        /// Returns true only the first time.
        func markFinished() -> Bool {
            lock.lock(); defer { lock.unlock() }
            if finished { return false }
            finished = true
            return true
        }
        var isFinished: Bool { lock.lock(); defer { lock.unlock() }; return finished }
        func update(_ text: String) {
            lock.lock(); defer { lock.unlock() }
            if text != bestText { bestText = text; lastChange = Date() }
        }
        var snapshot: (text: String, lastChange: Date) {
            lock.lock(); defer { lock.unlock() }
            return (bestText, lastChange)
        }
    }

    static func requestPermissions() async -> Bool {
        let speechOK: Bool = await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
        let micOK = await AVAudioApplication.requestRecordPermission()
        return speechOK && micOK
    }

    static func recognizer(for language: AppLanguage) -> SFSpeechRecognizer? {
        if language == .malayalam, let ml = SFSpeechRecognizer(locale: Locale(identifier: "ml-IN")), ml.isAvailable {
            return ml
        }
        if let enIN = SFSpeechRecognizer(locale: Locale(identifier: "en-IN")), enIN.isAvailable { return enIN }
        return SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    }

    /// Returns the recognized text ("" if nothing was heard). Call on the main thread.
    func listen(language: AppLanguage, maxSeconds: Double = 8, silence: Double = 1.8) async -> String {
        guard let recognizer = VoiceInput.recognizer(for: language), recognizer.isAvailable else { return "" }
        if let old = self.session { finish(old) }
        stop()
        let session = ListenSession()
        self.session = session
        return await withCheckedContinuation { (continuation: CheckedContinuation<String, Never>) in
            session.continuation = continuation
            let request = SFSpeechAudioBufferRecognitionRequest()
            request.shouldReportPartialResults = true
            request.taskHint = .search
            self.request = request

            let input = self.audioEngine.inputNode
            let format = input.outputFormat(forBus: 0)
            input.removeTap(onBus: 0)
            input.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in
                request.append(buffer)
            }
            self.audioEngine.prepare()
            do {
                try self.audioEngine.start()
            } catch {
                print("Audio engine error: \(error)")
                self.finish(session)
                return
            }
            self.task = recognizer.recognitionTask(with: request) { [weak self] result, error in
                if let result = result {
                    session.update(result.bestTranscription.formattedString)
                    if result.isFinal { self?.finish(session) }
                }
                if error != nil { self?.finish(session) }
            }
            self.watch(session, maxSeconds: maxSeconds, silence: silence)
        }
    }

    private func watch(_ session: ListenSession, maxSeconds: Double, silence: Double) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { [weak self] in
            guard let self = self, !session.isFinished else { return }
            let now = Date()
            let snap = session.snapshot
            if now.timeIntervalSince(session.started) > maxSeconds ||
                (!snap.text.isEmpty && now.timeIntervalSince(snap.lastChange) > silence) {
                self.finish(session)
            } else {
                self.watch(session, maxSeconds: maxSeconds, silence: silence)
            }
        }
    }

    private func finish(_ session: ListenSession) {
        guard session.markFinished() else { return }
        DispatchQueue.main.async {
            if self.session === session { self.stop() }
            let text = session.snapshot.text.trimmingCharacters(in: .whitespacesAndNewlines)
            session.continuation?.resume(returning: text)
            session.continuation = nil
        }
    }

    /// Stop listening. Any pending listen() returns what it heard so far.
    func cancel() {
        if let session = session { finish(session) }
    }

    private func stop() {
        if audioEngine.isRunning { audioEngine.stop() }
        audioEngine.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        task?.cancel()
        request = nil
        task = nil
    }
}
