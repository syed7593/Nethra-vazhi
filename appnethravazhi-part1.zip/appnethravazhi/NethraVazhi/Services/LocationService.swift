import CoreLocation

/// iPhone GPS (Core Location). Only real device fixes are used, never IP location.
final class LocationService: NSObject, CLLocationManagerDelegate {
    private let manager = CLLocationManager()
    private let lock = NSLock()
    private var latest: CLLocation?
    var onAuthorizationChange: ((CLAuthorizationStatus) -> Void)?

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.activityType = .fitness
        manager.distanceFilter = kCLDistanceFilterNone
    }

    var authorization: CLAuthorizationStatus { manager.authorizationStatus }

    func requestPermission() {
        if manager.authorizationStatus == .notDetermined {
            manager.requestWhenInUseAuthorization()
        }
    }

    func start() {
        requestPermission()
        manager.startUpdatingLocation()
    }

    func stop() {
        manager.stopUpdatingLocation()
    }

    /// (coordinate, horizontal accuracy in meters) if a fresh fix exists.
    func currentFix() -> (Coordinate, Double)? {
        lock.lock(); defer { lock.unlock() }
        guard let loc = latest, loc.horizontalAccuracy >= 0 else { return nil }
        if Date().timeIntervalSince(loc.timestamp) > RouteConfig.gpsFixMaxAgeSeconds { return nil }
        return (Coordinate(lat: loc.coordinate.latitude, lon: loc.coordinate.longitude), loc.horizontalAccuracy)
    }

    /// A fix that is accurate enough to route with.
    func reliableFix() -> Coordinate? {
        guard let fix = currentFix(), fix.1 <= RouteConfig.gpsMaxAccuracyMeters else { return nil }
        return fix.0
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let last = locations.last else { return }
        lock.lock()
        latest = last
        lock.unlock()
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location error: \(error)")
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        onAuthorizationChange?(manager.authorizationStatus)
    }
}
