import Foundation

/// Slope (gradient) warning from the iPhone's barometer + step counter.
/// grade % = height change / distance walked × 100, measured over the last few meters.
enum SlopeConfig {
    /// Warn at this gradient. 8 % ≈ the steepest allowed wheelchair ramp (1:12).
    static let warnGradePercent = 8.0
    /// Slope is considered over when the gradient falls below this.
    static let levelGradePercent = 4.0
    /// Distance window used to measure the gradient (meters walked).
    static let windowMeters = 6.0
    /// Ignore windows longer than this (e.g. after standing still for a long time).
    static let maxWindowMeters = 15.0
    /// Number of consecutive steep readings before warning (reduces barometer noise).
    static let confirmReadings = 2
    /// Don't repeat the same slope warning more often than this.
    static let repeatSeconds = 20.0
}

enum SlopeEvent: Equatable {
    case uphill(gradePercent: Int)
    case downhill(gradePercent: Int)
    case level
}

struct SlopeTracker {
    struct Sample { var distance: Double; var altitude: Double; var time: Double }
    private(set) var samples: [Sample] = []
    private var steepCount = 0
    private var onSlope: Bool = false
    private var lastWarnTime = -1e9
    private var lastDirectionUp: Bool?
    private(set) var lastGrade: Double?

    /// Add a reading: cumulative distance walked (m), relative altitude (m), time (s).
    /// Returns an event when the user should be told something.
    mutating func add(distance: Double, altitude: Double, time: Double) -> SlopeEvent? {
        samples.append(Sample(distance: distance, altitude: altitude, time: time))
        // Keep only what is needed for the window.
        while samples.count > 2, distance - samples[1].distance >= SlopeConfig.windowMeters {
            samples.removeFirst()
        }
        guard let first = samples.first else { return nil }
        let run = distance - first.distance
        guard run >= SlopeConfig.windowMeters, run <= SlopeConfig.maxWindowMeters else { return nil }
        let grade = (altitude - first.altitude) / run * 100
        lastGrade = grade
        let up = grade > 0

        if abs(grade) >= SlopeConfig.warnGradePercent {
            steepCount += 1
            guard steepCount >= SlopeConfig.confirmReadings else { return nil }
            let changedDirection = lastDirectionUp != nil && lastDirectionUp != up
            if !onSlope || changedDirection || time - lastWarnTime >= SlopeConfig.repeatSeconds {
                onSlope = true
                lastDirectionUp = up
                lastWarnTime = time
                let pct = Int(abs(grade).rounded())
                return up ? .uphill(gradePercent: pct) : .downhill(gradePercent: pct)
            }
            return nil
        }
        steepCount = 0
        if onSlope && abs(grade) < SlopeConfig.levelGradePercent {
            onSlope = false
            lastDirectionUp = nil
            return .level
        }
        return nil
    }
}
