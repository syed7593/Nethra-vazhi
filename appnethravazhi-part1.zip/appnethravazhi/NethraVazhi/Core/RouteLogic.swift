import Foundation

// Port of the walking-route logic in osmmap.py (OpenRouteService / OSM).

enum RouteConfig {
    static let gpsMaxAccuracyMeters = 35.0
    static let announceStepWithinMeters = 35.0
    static let gpsFixMaxAgeSeconds = 30.0
    static let offRouteMeters = 45.0
    static let offRouteHits = 3
    static let arrivalMeters = 15.0
}

struct Coordinate: Equatable {
    var lat: Double
    var lon: Double
}

struct RouteStep: Equatable {
    var instruction: String
    var distanceM: Double
    var durationS: Double
    var startIndex: Int
    var endIndex: Int
    var type: Int
}

struct WalkingRoute: Equatable {
    var geometry: [Coordinate]
    var steps: [RouteStep]
    var distanceM: Double
    var durationS: Double
}

struct RouteProgress: Equatable {
    var geometryIndex: Int
    var stepIndex: Int
    var distanceToStepM: Double
    var announceDistanceM: Double
}

struct PlaceResult: Equatable {
    var label: String
    var coordinate: Coordinate
}

enum RouteError: Error, LocalizedError {
    case badResponse(String)
    var errorDescription: String? {
        switch self { case .badResponse(let m): return m }
    }
}

enum RouteLogic {
    static func haversineM(_ a: Coordinate, _ b: Coordinate) -> Double {
        let lat1 = a.lat * .pi / 180, lon1 = a.lon * .pi / 180
        let lat2 = b.lat * .pi / 180, lon2 = b.lon * .pi / 180
        let dlat = lat2 - lat1, dlon = lon2 - lon1
        let h = pow(sin(dlat / 2), 2) + cos(lat1) * cos(lat2) * pow(sin(dlon / 2), 2)
        return 6_371_000 * 2 * asin(sqrt(min(1.0, h)))
    }

    static func parseCoordinate(_ text: String) -> Coordinate? {
        let parts = text.split(separator: ",", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
        guard parts.count == 2, let lat = Double(parts[0]), let lon = Double(parts[1]) else { return nil }
        guard (-90...90).contains(lat), (-180...180).contains(lon) else { return nil }
        return Coordinate(lat: lat, lon: lon)
    }

    /// Parse ORS /geocode/search GeoJSON.
    static func parseGeocode(_ data: Data, fallbackLabel: String) throws -> [PlaceResult] {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw RouteError.badResponse("Place search returned unexpected data")
        }
        let features = root["features"] as? [[String: Any]] ?? []
        var results: [PlaceResult] = []
        for feature in features {
            guard let geometry = feature["geometry"] as? [String: Any],
                  let coords = geometry["coordinates"] as? [Any], coords.count >= 2,
                  let lon = number(coords[0]), let lat = number(coords[1]) else { continue }
            let props = feature["properties"] as? [String: Any] ?? [:]
            let label = (props["label"] as? String) ?? (props["name"] as? String) ?? fallbackLabel
            results.append(PlaceResult(label: label, coordinate: Coordinate(lat: lat, lon: lon)))
        }
        return results
    }

    /// parse_ors_route: normalize ORS JSON into geometry and ordered steps.
    static func parseORSRoute(_ data: Data) throws -> WalkingRoute {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let features = root["features"] as? [[String: Any]], let feature = features.first,
              let geometry = feature["geometry"] as? [String: Any],
              let coordinates = geometry["coordinates"] as? [[Any]],
              let properties = feature["properties"] as? [String: Any],
              let segments = properties["segments"] as? [[String: Any]],
              let summary = properties["summary"] as? [String: Any] else {
            throw RouteError.badResponse("Unexpected ORS walking-route response")
        }
        var steps: [RouteStep] = []
        for segment in segments {
            for raw in segment["steps"] as? [[String: Any]] ?? [] {
                guard let wp = raw["way_points"] as? [Any], wp.count == 2,
                      let s = number(wp[0]), let e = number(wp[1]),
                      let instruction = raw["instruction"] as? String else {
                    throw RouteError.badResponse("Unexpected ORS step")
                }
                steps.append(RouteStep(instruction: instruction.trimmingCharacters(in: .whitespacesAndNewlines),
                                       distanceM: number(raw["distance"]) ?? 0,
                                       durationS: number(raw["duration"]) ?? 0,
                                       startIndex: Int(s), endIndex: Int(e),
                                       type: Int(number(raw["type"]) ?? -1)))
            }
        }
        var points: [Coordinate] = []
        for p in coordinates where p.count >= 2 {
            guard let lon = number(p[0]), let lat = number(p[1]) else { continue }
            points.append(Coordinate(lat: lat, lon: lon))
        }
        if points.isEmpty || steps.isEmpty { throw RouteError.badResponse("No route geometry or turn instructions") }
        return WalkingRoute(geometry: points, steps: steps,
                            distanceM: number(summary["distance"]) ?? 0,
                            durationS: number(summary["duration"]) ?? 0)
    }

    static func number(_ v: Any?) -> Double? {
        if let d = v as? Double { return d }
        if let i = v as? Int { return Double(i) }
        if let n = v as? NSNumber { return n.doubleValue }
        return nil
    }

    /// progress_for_location: nearest forward route point and next maneuver distance.
    static func progress(route: WalkingRoute, at here: Coordinate, lastIndex: Int) -> RouteProgress {
        let geometry = route.geometry
        guard !geometry.isEmpty, !route.steps.isEmpty else {
            return RouteProgress(geometryIndex: 0, stepIndex: 0, distanceToStepM: 0, announceDistanceM: 0)
        }
        let low = max(0, lastIndex - 2)
        let high = min(geometry.count, max(low + 80, lastIndex + 80))
        var nearest = low
        var nearestDistance = Double.infinity
        if low < high {
            for i in low..<high {
                let d = haversineM(here, geometry[i])
                if d < nearestDistance { nearestDistance = d; nearest = i }
            }
        }
        let steps = route.steps
        var currentStep = steps.count - 1
        for (i, step) in steps.enumerated() where nearest <= step.endIndex {
            currentStep = i
            break
        }
        var stepIndex = currentStep
        let endIndex = max(0, min(geometry.count - 1, steps[currentStep].endIndex))
        let distanceToBoundary = haversineM(here, geometry[endIndex])
        let turnDistance: Double
        let announceDistance: Double
        if currentStep + 1 < steps.count && distanceToBoundary <= RouteConfig.announceStepWithinMeters {
            stepIndex = currentStep + 1
            let turnIndex = max(0, min(geometry.count - 1, steps[stepIndex].startIndex))
            turnDistance = haversineM(here, geometry[turnIndex])
            announceDistance = turnDistance
        } else {
            turnDistance = distanceToBoundary
            announceDistance = 0
        }
        return RouteProgress(geometryIndex: max(lastIndex, nearest), stepIndex: stepIndex,
                             distanceToStepM: turnDistance, announceDistanceM: announceDistance)
    }

    /// instruction_malayalam from osmmap.py.
    static func instructionMalayalam(_ english: String, distanceM: Double = 0) -> String {
        let text = english.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let prefix = distanceM >= 10 ? "\(pyRound(distanceM)) മീറ്റർ കഴിഞ്ഞ് " : ""
        func has(_ words: [String]) -> Bool { words.contains { text.contains($0) } }
        if has(["arrive", "destination reached", "you have reached"]) { return "നിങ്ങൾ ലക്ഷ്യസ്ഥാനത്ത് എത്തി." }
        if has(["u-turn", "uturn"]) { return prefix + "യു-ടേൺ എടുക്കുക. ചൂരൽ ഉപയോഗിച്ച് വഴി ഉറപ്പാക്കുക." }
        if text.contains("sharp left") { return prefix + "കഠിനമായി ഇടത്തേക്ക് തിരിയുക." }
        if text.contains("sharp right") { return prefix + "കഠിനമായി വലത്തേക്ക് തിരിയുക." }
        if has(["slight left", "keep left"]) { return prefix + "ഇടത്തേക്ക് അല്പം തിരിഞ്ഞ് ഇടത് വശത്ത് തുടരുക." }
        if has(["slight right", "keep right"]) { return prefix + "വലത്തേക്ക് അല്പം തിരിഞ്ഞ് വലത് വശത്ത് തുടരുക." }
        if text.contains("left") { return prefix + "ഇടത്തേക്ക് തിരിയുക." }
        if text.contains("right") { return prefix + "വലത്തേക്ക് തിരിയുക." }
        if text.contains("north") { return "വടക്കോട്ട് നേരെ നടക്കുക." }
        if text.contains("south") { return "തെക്കോട്ട് നേരെ നടക്കുക." }
        if text.contains("east") { return "കിഴക്കോട്ട് നേരെ നടക്കുക." }
        if text.contains("west") { return "പടിഞ്ഞാറോട്ട് നേരെ നടക്കുക." }
        if has(["continue", "straight", "head", "follow", "walk"]) { return prefix + "നേരെ മുന്നോട്ട് നടക്കുക." }
        return "റൂട്ട് നിർദ്ദേശം വ്യക്തമായില്ല. നിൽക്കുക; സുരക്ഷിതമായ വഴി സ്ഥിരീകരിക്കുക."
    }

    /// English: ORS already gives English steps; add the distance like the Malayalam version.
    static func instructionEnglish(_ english: String, distanceM: Double = 0) -> String {
        var text = english.trimmingCharacters(in: .whitespacesAndNewlines)
        if text.isEmpty { return "Route instruction unclear. Stop and confirm a safe path." }
        if !text.hasSuffix(".") { text += "." }
        let lower = text.lowercased()
        if lower.contains("arrive") || lower.contains("destination reached") { return "You have arrived at your destination." }
        if distanceM >= 10 {
            return "In \(pyRound(distanceM)) meters, " + text.prefix(1).lowercased() + String(text.dropFirst())
        }
        return text
    }

    static func instruction(_ english: String, distanceM: Double, language: AppLanguage) -> String {
        language == .malayalam ? instructionMalayalam(english, distanceM: distanceM)
                               : instructionEnglish(english, distanceM: distanceM)
    }

    /// Python's round(): banker's rounding to nearest even.
    static func pyRound(_ v: Double) -> Int {
        Int(v.rounded(.toNearestOrEven))
    }

    // MARK: Voice answer helpers
    /// Lowercased latin words of an answer (speech recognition output).
    static func words(_ answer: String) -> [String] {
        answer.lowercased().components(separatedBy: CharacterSet.letters.inverted).filter { !$0.isEmpty }
    }

    /// "yes" in English, Malayalam script, or romanized Malayalam (Apple recognizes
    /// Malayalam answers with the Indian-English recognizer, e.g. "athe", "shari").
    static func isYes(_ answer: String) -> Bool {
        let yesWords: Set<String> = ["yes", "yeah", "yep", "ya", "yah", "ok", "okay", "correct", "right", "sure", "go",
                                     "athe", "adhe", "ate", "aathe", "shari", "sari", "seri", "uvvu", "aam"]
        let malayalam = ["അതെ", "ശരി", "ഉവ്വ്", "യെസ്"]
        let hit = words(answer).contains { yesWords.contains($0) } || malayalam.contains { answer.contains($0) }
        return hit && !isNo(answer)
    }

    static func isNo(_ answer: String) -> Bool {
        let noWords: Set<String> = ["no", "nope", "nah", "next", "wrong", "not", "illa", "ella", "venda", "vendaa", "alla"]
        let malayalam = ["ഇല്ല", "വേണ്ട", "അല്ല", "അടുത്തത്", "നോ"]
        return words(answer).contains { noWords.contains($0) } || malayalam.contains { answer.contains($0) }
    }

    static func isCancel(_ answer: String) -> Bool {
        let a = answer.lowercased()
        return ["cancel", "stop navigation", "exit", "റദ്ദാക്കുക", "നിർത്തുക"].contains { a.contains($0) }
    }
}
