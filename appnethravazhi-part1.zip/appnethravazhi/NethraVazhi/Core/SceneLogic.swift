import Foundation

// Multi-object handling added on top of nethracam.py.
//
// Problems this fixes:
//  * Two or three chairs were confused: tracks were matched one detection at a time and
//    lost after a single missed frame, so identities swapped and "frames seen" restarted.
//  * Chair / couch / bench (and car / truck / bus) flip between classes on the same object.
//  * Only the single highest-scoring object was ever considered, and the lead object could
//    flip back and forth between two similar objects, causing repeated announcements.
//
// The original functions in HazardLogic.swift are left untouched (the golden tests compare
// them with the Python code). The detector now uses SceneTracker + SceneLogic instead.

enum SceneConfig {
    /// Classes the model often mixes up. Duplicate boxes within a group are merged and
    /// the class of a track is decided by a vote over several frames.
    static let confusableGroups: [Set<String>] = [
        ["chair", "couch", "bench", "dining table"],
        ["car", "truck", "bus"],
        ["bicycle", "motorcycle"],
        ["traffic light", "stop sign"],
    ]
    /// Extra minimum confidence for classes that produce many false positives.
    static let sceneMinConfidence: [String: Double] = [
        "chair": 0.50, "couch": 0.55, "bench": 0.55, "dining table": 0.55, "potted plant": 0.55,
    ]

    static let sameClassDuplicateIou = 0.70
    static let crossClassDuplicateIou = 0.50
    static let minBoxAreaRatio = 0.0015

    /// Tracking: a detection may continue a track if the boxes overlap or the centres are close.
    static let matchIouMin = 0.12
    static let matchCenterMax = 0.10        // fraction of the frame diagonal-ish (normalised x/y)
    static let boxSmoothing = 0.6           // weight of the newest box
    static let confidenceSmoothing = 0.5
    static let voteDecay = 0.9
    static let labelStability = 0.6         // the winning class needs 60 % of the votes
    static let confirmMinAverageConfidence = 0.42

    /// Detection cycles a track survives without a matching detection.
    static let confirmedCoastCycles = 3
    static let unconfirmedCoastCycles = 1
    static let openVocabCoastRuns = 2       // counted only on cycles where that model ran
    static let missedConfidenceDecay = 0.9

    /// The current lead object is kept unless another one scores 15 % higher.
    static let leadSwitchMargin = 1.15
}

struct SceneTrack {
    var id: Int
    var label: String
    var votes: [String: Double]
    var box: Box
    var framesSeen: Int
    var missed: Int
    var confidence: Double
    var openVocab: Bool
    var isPothole: Bool
    var confirmed: Bool
    var template: Hazard
}

enum SceneLogic {
    // MARK: Label groups and duplicate removal

    static func group(of label: String) -> Int? {
        SceneConfig.confusableGroups.firstIndex { $0.contains(label) }
    }

    static func compatible(_ a: String, _ b: String) -> Bool {
        if a == b { return true }
        guard let ga = group(of: a), let gb = group(of: b) else { return false }
        return ga == gb
    }

    /// Removes duplicate boxes: the same object reported twice, or as two similar classes
    /// (chair + couch). Higher confidence wins. Tiny boxes are ignored.
    static func suppressDuplicates(_ items: [Hazard]) -> [Hazard] {
        let sorted = items.enumerated().sorted { a, b in
            if a.element.confidence != b.element.confidence { return a.element.confidence > b.element.confidence }
            return a.offset < b.offset
        }.map { $0.element }
        var kept: [Hazard] = []
        for h in sorted {
            if !h.isPothole && h.areaRatio < SceneConfig.minBoxAreaRatio { continue }
            var duplicate = false
            for k in kept where k.isPothole == h.isPothole && k.openVocab == h.openVocab {
                let iou = HazardLogic.boxIoU(k.box, h.box)
                if k.trackLabel == h.trackLabel {
                    if iou > SceneConfig.sameClassDuplicateIou { duplicate = true; break }
                } else if compatible(k.trackLabel, h.trackLabel) && iou > SceneConfig.crossClassDuplicateIou {
                    duplicate = true
                    break
                }
            }
            if !duplicate { kept.append(h) }
        }
        return kept
    }

    // MARK: Priority: closest and most dangerous first

    static func scenePriority(_ h: Hazard) -> Double {
        var p = HazardLogic.priority(h)                 // proximity band, pothole, lower edge, size, confidence
        if h.side == .center { p += 25 }                // inside the walking lane
        p += 35 * h.bottomRatio                         // lower in the picture = closer to the user
        switch h.label {
        case "person", "car", "bus", "truck", "motorcycle", "bicycle": p += 15   // they move
        case "stairs": p += 60
        default: break
        }
        return p
    }

    /// Side, proximity and priority for each confirmed object; highest priority first.
    static func aggregate(_ hazards: [Hazard]) -> [Hazard] {
        var items: [(Int, Hazard)] = []
        for (i, var h) in hazards.enumerated() {
            h.label = h.trackLabel
            h.side = h.frameWidth > 0 ? HazardLogic.sideOf(h) : .center
            h.proximity = HazardLogic.proximityBand(h)
            h.priority = scenePriority(h)
            items.append((i, h))
        }
        items.sort { a, b in
            if a.1.priority != b.1.priority { return a.1.priority > b.1.priority }
            return a.0 < b.0
        }
        return items.map { $0.1 }
    }

    // MARK: Choosing what to say

    /// Picks the closest / most important object. `previousLead` is the track id spoken about
    /// last time; it is kept unless something clearly more important appears.
    static func chooseGuidance(_ objects: [Hazard], previousLead: Int?) -> (guidance: Guidance, leadId: Int?) {
        let close = objects.filter { $0.proximity == .near || $0.proximity == .approaching }
        guard var lead = close.first else {
            return (HazardLogic.chooseGuidance(objects), nil)
        }
        if let prevId = previousLead, prevId != lead.trackId,
           let prev = close.first(where: { $0.trackId == prevId }) {
            let escalates = lead.proximity == .near && prev.proximity != .near
            if !escalates && prev.priority * SceneConfig.leadSwitchMargin >= lead.priority { lead = prev }
        }
        var g = HazardLogic.chooseGuidance([lead])
        g.count = close.filter { $0.label == lead.label && $0.side == lead.side }.count
        if let other = close.first(where: { $0.trackId != lead.trackId && !($0.label == lead.label && $0.side == lead.side) }) {
            g.alsoLabel = other.label
            g.alsoSide = other.side
        }
        return (g, lead.trackId)
    }

    /// STOP / SLOW DOWN / CAUTION wording. STOP is only for objects in the centre (walking) lane;
    /// a close object on the left or right gives "Slow down" plus which side to keep to.
    /// The count and "also" fields are kept.
    static func applyThreshold(_ g: Guidance) -> Guidance {
        var out = HazardLogic.applyStopThreshold(g)
        if out.key == "obstacle_left" || out.key == "obstacle_right", let label = out.label, let side = out.side {
            let name = HazardLogic.titleCase(label)
            let sideName = side == .left ? "left" : "right"
            let opposite = side == .left ? "right" : "left"
            out = Guidance(key: "slow_\(sideName)",
                           display: "SLOW DOWN - Close \(name) on \(sideName); cane-check \(opposite), keep \(opposite)",
                           label: label, side: side, proximity: out.proximity)
        }
        out.count = g.count
        out.alsoLabel = g.alsoLabel
        out.alsoSide = g.alsoSide
        return out
    }
}

// MARK: - Tracker

/// Keeps one track per physical object. Detections are matched to tracks globally (best pairs
/// first), tracks survive a few missed frames, boxes are smoothed and the class is decided by
/// voting, so neighbouring chairs keep their own identity and confirmation.
struct SceneTracker {
    private(set) var tracks: [SceneTrack] = []
    private var nextId = 1

    private static func centerY(_ b: Box) -> Double { (b.y1 + b.y2) / 2 }

    mutating func update(_ detections: [Hazard], ranOpenVocab: Bool) -> (all: [Hazard], confirmed: [Hazard]) {
        // 1. Score every possible detection <-> track pair.
        var pairs: [(score: Double, d: Int, t: Int)] = []
        for (di, d) in detections.enumerated() {
            for (ti, t) in tracks.enumerated() {
                guard t.isPothole == d.isPothole, t.openVocab == d.openVocab,
                      SceneLogic.compatible(t.label, d.trackLabel) else { continue }
                let w = max(1, d.frameWidth), h = max(1, d.frameHeight)
                let dx = (d.box.centerX - t.box.centerX) / w
                let dy = (SceneTracker.centerY(d.box) - SceneTracker.centerY(t.box)) / h
                let dist = (dx * dx + dy * dy).squareRoot()
                let iou = HazardLogic.boxIoU(d.box, t.box)
                guard iou >= SceneConfig.matchIouMin || dist <= SceneConfig.matchCenterMax else { continue }
                let score = (1 - iou) + dist + (t.label == d.trackLabel ? 0 : 0.25)
                pairs.append((score, di, ti))
            }
        }
        pairs.sort { $0.score < $1.score }

        // 2. One-to-one assignment, best pairs first.
        var usedDetections = Set<Int>()
        var usedTracks = Set<Int>()
        for p in pairs where !usedDetections.contains(p.d) && !usedTracks.contains(p.t) {
            usedDetections.insert(p.d)
            usedTracks.insert(p.t)
            apply(detections[p.d], toTrack: p.t)
        }

        // 3. New objects start new tracks.
        let oldCount = tracks.count
        for (di, d) in detections.enumerated() where !usedDetections.contains(di) {
            tracks.append(SceneTrack(id: nextId, label: d.trackLabel, votes: [d.trackLabel: d.confidence],
                                     box: d.box, framesSeen: 1, missed: 0, confidence: d.confidence,
                                     openVocab: d.openVocab, isPothole: d.isPothole, confirmed: false, template: d))
            nextId += 1
        }

        // 4. Tracks with no detection this cycle coast for a few cycles, then disappear.
        var survivors: [SceneTrack] = []
        for (i, var t) in tracks.enumerated() {
            if i < oldCount && !usedTracks.contains(i) {
                if t.openVocab && !ranOpenVocab {
                    survivors.append(t)         // that model did not run this cycle: no evidence either way
                    continue
                }
                t.missed += 1
                t.confidence *= SceneConfig.missedConfidenceDecay
                let limit = t.openVocab ? SceneConfig.openVocabCoastRuns
                    : (t.confirmed ? SceneConfig.confirmedCoastCycles : SceneConfig.unconfirmedCoastCycles)
                if t.missed > limit { continue }
            }
            survivors.append(t)
        }
        tracks = survivors

        // 5. Confirmation: enough frames, a stable class and enough average confidence. Sticky once set.
        for i in tracks.indices {
            var t = tracks[i]
            if !t.confirmed && t.missed == 0 {
                let required: Int
                if t.openVocab { required = DetectionConfig.openVocabConfirmFrames }
                else if t.label == "person" { required = DetectionConfig.personConfirmFrames }
                else { required = DetectionConfig.minConfirmFrames }
                let total = t.votes.values.reduce(0, +)
                let share = total > 0 ? (t.votes[t.label] ?? 0) / total : 1
                if t.framesSeen >= required
                    && share >= SceneConfig.labelStability
                    && t.confidence >= SceneConfig.confirmMinAverageConfidence {
                    t.confirmed = true
                }
            }
            tracks[i] = t
        }

        // 6. Output.
        var all: [Hazard] = []
        var confirmed: [Hazard] = []
        for t in tracks {
            var h = t.template
            h.label = t.label
            h.box = t.box
            h.confidence = t.confidence
            h.framesSeen = t.framesSeen
            h.confirmed = t.confirmed
            h.trackId = t.id
            all.append(h)
            if t.confirmed { confirmed.append(h) }
        }
        return (all, confirmed)
    }

    private mutating func apply(_ d: Hazard, toTrack index: Int) {
        var t = tracks[index]
        let a = SceneConfig.boxSmoothing
        t.box = Box(x1: a * d.box.x1 + (1 - a) * t.box.x1, y1: a * d.box.y1 + (1 - a) * t.box.y1,
                    x2: a * d.box.x2 + (1 - a) * t.box.x2, y2: a * d.box.y2 + (1 - a) * t.box.y2)
        t.framesSeen += 1
        t.missed = 0
        let c = SceneConfig.confidenceSmoothing
        t.confidence = c * d.confidence + (1 - c) * t.confidence
        for key in t.votes.keys { t.votes[key] = (t.votes[key] ?? 0) * SceneConfig.voteDecay }
        t.votes[d.trackLabel, default: 0] += d.confidence
        if let best = t.votes.sorted(by: { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }).first {
            t.label = best.key
        }
        t.template = d
        tracks[index] = t
    }
}

// MARK: - Spoken text for groups

extension Messages {
    /// The normal sentence, plus "There are 3 chairs here." and one "Also ..." for the next closest object.
    func spokenScene(for g: Guidance) -> String {
        var text = spoken(for: g)
        guard let label = g.label else { return text }
        if g.count > 1 { text += " " + countPhrase(label: label, count: g.count) }
        if let other = g.alsoLabel, let side = g.alsoSide { text += " " + alsoPhrase(label: other, side: side) }
        return text
    }

    func countPhrase(label: String, count: Int) -> String {
        if isMalayalam { return "ഇവിടെ \(count) \(objectName(label))." }
        return "There are \(count) \(Messages.plural(objectName(label))) here."
    }

    func alsoPhrase(label: String, side: Side) -> String {
        let name = objectName(label)
        let uncertain = Messages.isUncertain(label)
        if isMalayalam {
            let place = side == .left ? "ഇടത് വശത്ത്" : (side == .right ? "വലത് വശത്ത്" : "മുന്നിൽ")
            return "കൂടാതെ \(place) \(name)\(uncertain ? " ഉണ്ടായേക്കാം" : "")."
        }
        let place = side == .left ? "on your left" : (side == .right ? "on your right" : "ahead")
        return "Also \(uncertain ? "possible " : "")\(name) \(place)."
    }

    static func plural(_ name: String) -> String {
        let irregular = ["person": "people", "tv": "TVs", "goat or sheep": "goats or sheep", "bus": "buses", "stairs": "stairs"]
        if let p = irregular[name] { return p }
        if name.hasSuffix("s") || name.hasSuffix("x") || name.hasSuffix("ch") || name.hasSuffix("sh") { return name + "es" }
        if name.hasSuffix("y"), let last = name.dropLast().last, !"aeiou".contains(last) { return String(name.dropLast()) + "ies" }
        return name + "s"
    }
}
