import Foundation

/// Spoken language. English is the default; Malayalam is used when the iPhone
/// has a Malayalam text-to-speech voice installed (see SpeechService).
enum AppLanguage: String {
    case english = "en"
    case malayalam = "ml"
}

/// All sentences the app speaks. Malayalam safety sentences are copied
/// verbatim from nethracam.py; English versions say the same thing.
struct Messages {
    let language: AppLanguage
    var isMalayalam: Bool { language == .malayalam }

    static let malayalamNames: [String: String] = [
        "person": "ആൾ", "bicycle": "സൈക്കിൾ", "motorcycle": "മോട്ടോർ സൈക്കിൾ",
        "car": "കാർ", "bus": "ബസ്", "truck": "ട്രക്ക്",
        "traffic light": "ട്രാഫിക് ലൈറ്റ്", "stop sign": "സ്റ്റോപ്പ് ബോർഡ്",
        "bench": "ബെഞ്ച്", "chair": "കസേര", "couch": "സോഫ",
        "dining table": "മേശ", "potted plant": "ചെടിച്ചട്ടി", "dog": "നായ",
        "cat": "പൂച്ച", "backpack": "ബാക്ക്പാക്ക്", "umbrella": "കുട",
        "handbag": "ഹാൻഡ് ബാഗ്", "suitcase": "സ്യൂട്ട്കേസ്",
        "skateboard": "സ്കേറ്റ്ബോർഡ്", "fire hydrant": "ഫയർ ഹൈഡ്രന്റ്",
        "pothole": "കുഴി", "obstacle": "തടസ്സം",
        "stairs": "പടികൾ", "curb": "റോഡിന്റെ അരിക്", "ramp": "ചരിവുള്ള പാത",
        "traffic cone": "ട്രാഫിക് കോൺ", "bollard": "തടയുതൂൺ",
        "road barrier": "വഴി തടയണ", "doorway": "വാതിൽപ്പടി",
        "glass door": "ഗ്ലാസ് വാതിൽ", "pole": "തൂൺ", "wall": "മതിൽ",
        "parking meter": "പാർക്കിംഗ് മീറ്റർ", "sports ball": "പന്ത്",
        "vase": "പൂച്ചട്ടി", "refrigerator": "ഫ്രിഡ്ജ്", "oven": "ഓവൻ",
        "sink": "സിങ്ക്", "toilet": "ടോയ്ലറ്റ്", "tv": "ടിവി", "laptop": "ലാപ്ടോപ്പ്",
        "cow": "പശു", "horse": "കുതിര", "sheep": "ആട്", "elephant": "ആന",
    ]

    static let englishNames: [String: String] = [
        "tv": "TV", "sheep": "goat or sheep", "doorway": "doorway", "curb": "curb",
    ]

    /// Labels whose detection is less certain; speech says "possible".
    static func isUncertain(_ label: String) -> Bool {
        label == "person" || label == "traffic light" || DetectionConfig.openVocabLabelSet.contains(label)
    }

    static func capitalizeFirst(_ s: String) -> String {
        guard let first = s.first else { return s }
        return String(first).uppercased() + String(s.dropFirst())
    }

    func objectName(_ label: String) -> String {
        if isMalayalam { return Messages.malayalamNames[label] ?? Messages.malayalamNames["obstacle"]! }
        if label.isEmpty { return "obstacle" }
        return Messages.englishNames[label] ?? label
    }

    // MARK: Fixed safety sentences
    var startup: String {
        isMalayalam ? "നെത്രവഴി പ്രവർത്തനം തുടങ്ങി. മുന്നറിയിപ്പുകൾ ശ്രദ്ധിക്കുക. നാവിഗേഷനായി സ്ക്രീനിൽ മൂന്ന് തവണ തട്ടുക."
                    : "Nethra Vazhi started. Listen for warnings. Triple tap the screen for navigation."
    }
    var safetyStop: String {
        isMalayalam ? "നിൽക്കൂ. മുന്നോട്ട് പോകരുത്. ചൂരൽ ഉപയോഗിച്ച് വഴി പരിശോധിക്കുക."
                    : "Stop. Do not move forward. Check the path with your cane."
    }
    var safeCaution: String {
        isMalayalam ? "നിൽക്കൂ. മുന്നിൽ ഒരു തടസ്സം കണ്ടെത്തി. ചൂരൽ ഉപയോഗിച്ച് പരിശോധിക്കുക."
                    : "Stop. An obstacle was detected ahead. Check with your cane."
    }
    var safeClear: String {
        isMalayalam ? "പിന്തുണയ്ക്കുന്ന തടസ്സം കണ്ടെത്തിയില്ല.ചൂരൽ ഉപയോഗിച്ച് പരിശോധിച്ച് മാത്രം നീങ്ങുക."
                    : "No supported obstacle detected. Move only after checking with your cane."
    }
    var help: String {
        isMalayalam ? "നാവിഗേഷൻ തുടങ്ങാനോ നിർത്തി കണ്ടെത്തലിലേക്ക് മടങ്ങാനോ സ്ക്രീനിൽ മൂന്ന് തവണ തട്ടുക."
                    : "Triple tap the screen to start navigation with detection. Triple tap again to go back to detection only."
    }
    var paused: String { isMalayalam ? "സാധാരണ ശബ്ദ അറിയിപ്പുകൾ നിർത്തി." : "Routine announcements paused. Urgent warnings will still be spoken." }
    var resumed: String { isMalayalam ? "സാധാരണ ശബ്ദ അറിയിപ്പുകൾ വീണ്ടും തുടങ്ങി." : "Routine announcements resumed." }
    var cameraDenied: String {
        isMalayalam ? "ക്യാമറ അനുമതി ഇല്ല. സെറ്റിംഗ്സിൽ ക്യാമറ അനുവദിക്കുക."
                    : "Camera permission is off. Please allow camera access in Settings."
    }
    var modelsMissing: String {
        isMalayalam ? "കണ്ടെത്തൽ മോഡലുകൾ ലോഡ് ചെയ്യാൻ കഴിഞ്ഞില്ല. ചൂരൽ ഉപയോഗിക്കുക."
                    : "Detection models could not be loaded. Rely on your cane."
    }

    // MARK: Named object alerts (side_alert_message / front_alert_message)
    func sideAlert(label: String, blocked: Side) -> String {
        let name = objectName(label)
        let uncertain = Messages.isUncertain(label)
        if isMalayalam {
            let (blockedMl, otherMl, moveMl) = blocked == .left
                ? ("ഇടത്", "വലത്", "വലത്തേക്ക്") : ("വലത്", "ഇടത്", "ഇടത്തേക്ക്")
            let maybe = uncertain ? " ഉണ്ടായേക്കാം" : ""
            return "നിൽക്കൂ. \(blockedMl) വശത്ത് \(name)\(maybe). "
                + "\(otherMl) വശം ചൂരൽ കൊണ്ട് പരിശോധിക്കുക. "
                + "ചൂരൽ വഴി സുരക്ഷിതമാണെന്ന് ഉറപ്പാക്കിയാൽ മാത്രം \(moveMl) നീങ്ങുക."
        }
        let side = blocked == .left ? "left" : "right"
        let other = blocked == .left ? "right" : "left"
        let what = uncertain ? "Possible \(name)" : Messages.capitalizeFirst(name)
        return "Stop. \(what) on your \(side). Check the \(other) side with your cane. Move \(other) only after your cane confirms it is safe."
    }

    func frontAlert(label: String) -> String {
        let name = objectName(label)
        let uncertain = Messages.isUncertain(label)
        if isMalayalam {
            let maybe = uncertain ? " ഉണ്ടായേക്കാം" : ""
            return "നിൽക്കൂ. മുന്നിൽ \(name)\(maybe). ഇടത്തും വലത്തും ചൂരൽ കൊണ്ട് പരിശോധിക്കുക. "
                + "ചൂരൽ വഴി സുരക്ഷിതമാണെന്ന് ഉറപ്പാക്കിയ വശത്തേക്ക് മാത്രം നീങ്ങുക."
        }
        let what = uncertain ? "Possible \(name)" : Messages.capitalizeFirst(name)
        return "Stop. \(what) ahead. Check left and right with your cane. Move only toward a side your cane confirms is safe."
    }

    /// make_spoken_message: the sentence for a guidance key.
    func spoken(for guidance: Guidance) -> String {
        let label = guidance.label ?? "obstacle"
        switch guidance.key {
        case "clear": return safeClear
        case "obstacle_left": return sideAlert(label: label, blocked: .left)
        case "obstacle_right": return sideAlert(label: label, blocked: .right)
        case "front_blocked": return frontAlert(label: label)
        case "stairs_ahead": return frontAlert(label: "stairs")
        case "pothole_ahead": return frontAlert(label: "pothole")
        case "slow_left": return slowSide(label: label, side: .left)
        case "slow_right": return slowSide(label: label, side: .right)
        case "caution_ahead": return cautionAhead(label: label)
        case "caution_left": return cautionSide(label: label, side: .left)
        case "caution_right": return cautionSide(label: label, side: .right)
        case "ramp_ahead": return rampAhead
        default: return safeCaution
        }
    }

    // MARK: Close object on the left / right: slow down (STOP is only for objects in the walking lane)
    func slowSide(label: String, side: Side) -> String {
        let name = objectName(label)
        let uncertain = Messages.isUncertain(label)
        if isMalayalam {
            let (sideMl, otherMl, moveMl) = side == .left
                ? ("ഇടത്", "വലത്", "വലത്തേക്ക്") : ("വലത്", "ഇടത്", "ഇടത്തേക്ക്")
            let maybe = uncertain ? " ഉണ്ടായേക്കാം" : ""
            return "വേഗത കുറയ്ക്കുക. \(sideMl) വശത്ത് അടുത്ത് \(name)\(maybe). "
                + "\(otherMl) വശം ചൂരൽ കൊണ്ട് പരിശോധിച്ച് \(moveMl) മാറി നടക്കുക."
        }
        let s = side == .left ? "left" : "right"
        let other = side == .left ? "right" : "left"
        let what = uncertain ? "Possible \(name)" : Messages.capitalizeFirst(name)
        return "Slow down. \(what) close on your \(s). Check the \(other) side with your cane and keep to the \(other)."
    }

    // MARK: Approaching (before the STOP threshold)
    func cautionSide(label: String, side: Side) -> String {
        let name = objectName(label)
        let uncertain = Messages.isUncertain(label)
        if isMalayalam {
            let (sideMl, otherMl, moveMl) = side == .left
                ? ("ഇടത്", "വലത്", "വലത്തേക്ക്") : ("വലത്", "ഇടത്", "ഇടത്തേക്ക്")
            let maybe = uncertain ? " ഉണ്ടായേക്കാം" : ""
            return "ശ്രദ്ധിക്കുക. \(sideMl) വശത്ത് \(name)\(maybe). "
                + "\(otherMl) വശം ചൂരൽ കൊണ്ട് പരിശോധിച്ച് \(moveMl) മാറി നടക്കുക."
        }
        let s = side == .left ? "left" : "right"
        let other = side == .left ? "right" : "left"
        let what = uncertain ? "Possible \(name)" : Messages.capitalizeFirst(name)
        return "Caution. \(what) ahead on your \(s). Check the \(other) side with your cane and keep to the \(other)."
    }

    func cautionAhead(label: String) -> String {
        let name = objectName(label)
        let uncertain = Messages.isUncertain(label)
        if isMalayalam {
            let maybe = uncertain ? " ഉണ്ടായേക്കാം" : ""
            return "ശ്രദ്ധിക്കുക. മുന്നിൽ \(name)\(maybe). വേഗത കുറച്ച് ഇടത്തും വലത്തും ചൂരൽ കൊണ്ട് പരിശോധിക്കുക."
        }
        let what = uncertain ? "Possible \(name)" : Messages.capitalizeFirst(name)
        return "Caution. \(what) ahead. Slow down and check left and right with your cane."
    }

    // MARK: Slopes
    var rampAhead: String {
        isMalayalam ? "ശ്രദ്ധിക്കുക. മുന്നിൽ ചരിവുള്ള പാത ഉണ്ടായേക്കാം. പതുക്കെ നടന്ന് ചൂരൽ ഉപയോഗിച്ച് പരിശോധിക്കുക."
                    : "Caution. Possible ramp or slope ahead. Walk slowly and check with your cane."
    }
    func slope(uphill: Bool, gradePercent: Int) -> String {
        if isMalayalam {
            return uphill
                ? "ശ്രദ്ധിക്കുക. മുകളിലേക്കുള്ള ചരിവ്, ഏകദേശം \(gradePercent) ശതമാനം. പതുക്കെ നടന്ന് ചൂരൽ ഉപയോഗിച്ച് പരിശോധിക്കുക."
                : "ശ്രദ്ധിക്കുക. താഴേക്കുള്ള ചരിവ്, ഏകദേശം \(gradePercent) ശതമാനം. ചെറിയ ചുവടുകൾ വെച്ച് ചൂരൽ ഉപയോഗിച്ച് പരിശോധിക്കുക."
        }
        return uphill
            ? "Caution. Uphill slope, about \(gradePercent) percent. Walk slowly and check with your cane."
            : "Caution. Downhill slope, about \(gradePercent) percent. Take small steps and check with your cane."
    }
    var slopeEnded: String { isMalayalam ? "ചരിവ് അവസാനിച്ചു. നിരപ്പായ വഴി." : "The slope has ended. Level ground." }

    // MARK: Navigation conversation
    var navStart: String {
        isMalayalam ? "നാവിഗേഷൻ മോഡ്. ക്യാമറ മുന്നറിയിപ്പുകൾ തുടരും. നിങ്ങൾക്ക് എവിടേക്ക് പോകണം? ബീപ്പിന് ശേഷം സ്ഥലത്തിന്റെ പേര് പറയുക."
                    : "Navigation mode. Camera warnings continue. Where do you want to go? Say the place name after the beep."
    }
    var askDestinationAgain: String {
        isMalayalam ? "കേട്ടില്ല. എവിടേക്ക് പോകണം എന്ന് വീണ്ടും പറയുക." : "I did not catch that. Please say where you want to go."
    }
    var askCurrentLocation: String {
        isMalayalam ? "ജിപിഎസ് ലഭ്യമല്ല. നിങ്ങൾ ഇപ്പോൾ എവിടെയാണ്? ആരംഭ സ്ഥലം പറയുക."
                    : "GPS is not available yet. Where are you now? Say your starting place."
    }
    func searching(_ place: String) -> String {
        isMalayalam ? "\(place) തിരയുന്നു." : "Searching for \(place)."
    }
    func confirmPlace(_ label: String, index: Int, total: Int) -> String {
        if isMalayalam {
            return "ഫലം \(index) / \(total): \(label). ഇവിടേക്ക് പോകാൻ അതെ എന്നോ യെസ് എന്നോ പറയുക. അടുത്തതിന് ഇല്ല എന്ന് പറയുക."
        }
        return "Result \(index) of \(total): \(label). Say yes to go there, or no for the next result."
    }
    func confirmStart(_ label: String) -> String {
        isMalayalam ? "ആരംഭ സ്ഥലം: \(label). ശരിയാണെങ്കിൽ അതെ എന്ന് പറയുക." : "Starting point: \(label). Say yes if that is right."
    }
    var noPlaceFound: String {
        isMalayalam ? "സ്ഥലം കണ്ടെത്താനായില്ല. വീണ്ടും ശ്രമിക്കാൻ മൂന്ന് തവണ തട്ടുക."
                    : "I could not find that place. Triple tap to try again."
    }
    var noMoreResults: String {
        isMalayalam ? "കൂടുതൽ ഫലങ്ങളില്ല. നാവിഗേഷൻ റദ്ദാക്കി. വീണ്ടും ശ്രമിക്കാൻ മൂന്ന് തവണ തട്ടുക."
                    : "No more results. Navigation cancelled. Triple tap to try again."
    }
    var waitingForGPS: String {
        isMalayalam ? "ജിപിഎസ് ലഭിക്കാൻ കാത്തിരിക്കുന്നു. നിശ്ചലമായി നിൽക്കുക." : "Waiting for a reliable GPS fix. Please stand still."
    }
    var poorGPS: String {
        isMalayalam ? "ജിപിഎസ് കൃത്യത കുറവാണ്. റൂട്ട് പിന്തുടരും മുമ്പ് കാത്തിരിക്കുക." : "GPS accuracy is low. Wait before following the route."
    }
    var gettingRoute: String { isMalayalam ? "നടപ്പാത കണ്ടെത്തുന്നു." : "Getting a walking route." }
    func routeReady(distanceM: Double, durationS: Double) -> String {
        let meters = Int(distanceM.rounded())
        let minutes = max(1, Int((durationS / 60).rounded()))
        return isMalayalam ? "റൂട്ട് തയ്യാർ. \(meters) മീറ്റർ, ഏകദേശം \(minutes) മിനിറ്റ്. ക്യാമറ മുന്നറിയിപ്പുകൾക്ക് മുൻഗണന."
                           : "Route ready. \(meters) meters, about \(minutes) minutes. Camera warnings take priority."
    }
    var routeError: String {
        isMalayalam ? "റൂട്ട് ലഭ്യമല്ല. ക്യാമറ കണ്ടെത്തൽ തുടരുന്നു. വീണ്ടും ശ്രമിക്കുന്നു."
                    : "Route unavailable. Camera detection continues. Trying again."
    }
    var offRoute: String {
        isMalayalam ? "റൂട്ടിൽ നിന്ന് മാറിയിരിക്കാം. നിൽക്കുക. പുതിയ റൂട്ട് കണ്ടെത്തുന്നു."
                    : "You may be off the route. Stop and check your surroundings. Finding a new route."
    }
    var arrived: String {
        isMalayalam ? "നിങ്ങൾ ലക്ഷ്യസ്ഥാനത്ത് എത്തി. നാവിഗേഷൻ അവസാനിച്ചു." : "You have arrived at your destination. Navigation ended."
    }
    var navStopped: String {
        isMalayalam ? "നാവിഗേഷൻ നിർത്തി. കണ്ടെത്തൽ മോഡ് മാത്രം." : "Navigation stopped. Detection mode only."
    }
    var micDenied: String {
        isMalayalam ? "മൈക്രോഫോൺ അല്ലെങ്കിൽ സംസാരം തിരിച്ചറിയൽ അനുമതി ഇല്ല. സെറ്റിംഗ്സിൽ അനുവദിക്കുക."
                    : "Microphone or speech recognition permission is off. Please allow it in Settings."
    }
    var locationDenied: String {
        isMalayalam ? "ലൊക്കേഷൻ അനുമതി ഇല്ല. സെറ്റിംഗ്സിൽ ലൊക്കേഷൻ അനുവദിക്കുക."
                    : "Location permission is off. Please allow location access in Settings."
    }
}
