import Foundation

/// One raw detection in normalized image coordinates (0...1, origin top-left,
/// upright portrait image).
struct RawDetection: Equatable {
    var classIndex: Int
    var confidence: Double
    var x1: Double
    var y1: Double
    var x2: Double
    var y2: Double
}

/// Decodes YOLO CoreML outputs. Supports both layouts Ultralytics exports:
///  - end-to-end (YOLO26 / YOLOE-26):  [1, N, 6]  rows = x1,y1,x2,y2,score,class (input pixels)
///  - classic (YOLOv8/11, nms=False):   [1, 4+C, A] columns = cx,cy,w,h,class scores
enum YOLODecoder {
    static func decode(values: [Float], shape: [Int], inputWidth: Double, inputHeight: Double,
                       minConfidence: Double, iouThreshold: Double = 0.45, maxDetections: Int = 30) -> [RawDetection] {
        let dims = shape.filter { $0 != 1 }
        guard dims.count == 2 else { return [] }
        if dims[1] == 6 && dims[0] != 6 {
            return decodeEndToEnd(values: values, rows: dims[0], inputWidth: inputWidth, inputHeight: inputHeight,
                                  minConfidence: minConfidence, maxDetections: maxDetections)
        }
        // Classic layout: the smaller dimension is channels (4 + classes).
        let channels = min(dims[0], dims[1])
        let anchors = max(dims[0], dims[1])
        let channelsFirst = dims[0] == channels
        return decodeClassic(values: values, channels: channels, anchors: anchors, channelsFirst: channelsFirst,
                             inputWidth: inputWidth, inputHeight: inputHeight, minConfidence: minConfidence,
                             iouThreshold: iouThreshold, maxDetections: maxDetections)
    }

    static func decodeEndToEnd(values: [Float], rows: Int, inputWidth: Double, inputHeight: Double,
                               minConfidence: Double, maxDetections: Int) -> [RawDetection] {
        var out: [RawDetection] = []
        for r in 0..<rows {
            let base = r * 6
            guard base + 5 < values.count else { break }
            let score = Double(values[base + 4])
            if score < minConfidence || !score.isFinite { continue }
            let det = RawDetection(classIndex: Int(values[base + 5].rounded()), confidence: score,
                                   x1: clamp01(Double(values[base]) / inputWidth),
                                   y1: clamp01(Double(values[base + 1]) / inputHeight),
                                   x2: clamp01(Double(values[base + 2]) / inputWidth),
                                   y2: clamp01(Double(values[base + 3]) / inputHeight))
            if det.x2 > det.x1 && det.y2 > det.y1 { out.append(det) }
        }
        out.sort { $0.confidence > $1.confidence }
        return Array(out.prefix(maxDetections))
    }

    static func decodeClassic(values: [Float], channels: Int, anchors: Int, channelsFirst: Bool,
                              inputWidth: Double, inputHeight: Double, minConfidence: Double,
                              iouThreshold: Double, maxDetections: Int) -> [RawDetection] {
        guard channels > 4, values.count >= channels * anchors else { return [] }
        func at(_ c: Int, _ a: Int) -> Double {
            Double(channelsFirst ? values[c * anchors + a] : values[a * channels + c])
        }
        var candidates: [RawDetection] = []
        for a in 0..<anchors {
            var bestClass = 0
            var best = -Double.infinity
            for c in 4..<channels {
                let s = at(c, a)
                if s > best { best = s; bestClass = c - 4 }
            }
            if best < minConfidence { continue }
            let cx = at(0, a), cy = at(1, a), w = at(2, a), h = at(3, a)
            candidates.append(RawDetection(classIndex: bestClass, confidence: best,
                                           x1: clamp01((cx - w / 2) / inputWidth), y1: clamp01((cy - h / 2) / inputHeight),
                                           x2: clamp01((cx + w / 2) / inputWidth), y2: clamp01((cy + h / 2) / inputHeight)))
        }
        return nonMaxSuppression(candidates, iouThreshold: iouThreshold, maxDetections: maxDetections)
    }

    static func nonMaxSuppression(_ detections: [RawDetection], iouThreshold: Double, maxDetections: Int) -> [RawDetection] {
        let sorted = detections.sorted { $0.confidence > $1.confidence }
        var kept: [RawDetection] = []
        for d in sorted {
            var suppressed = false
            for k in kept where k.classIndex == d.classIndex && iou(k, d) > iouThreshold {
                suppressed = true
                break
            }
            if !suppressed { kept.append(d) }
            if kept.count >= maxDetections { break }
        }
        return kept
    }

    static func iou(_ a: RawDetection, _ b: RawDetection) -> Double {
        HazardLogic.boxIoU(Box(x1: a.x1, y1: a.y1, x2: a.x2, y2: a.y2), Box(x1: b.x1, y1: b.y1, x2: b.x2, y2: b.y2))
    }

    static func clamp01(_ v: Double) -> Double { max(0, min(1, v)) }

    /// Parses Ultralytics metadata like "{0: 'person', 1: 'bicycle'}".
    static func parseNames(_ text: String?) -> [String]? {
        guard let text = text else { return nil }
        guard let regex = try? NSRegularExpression(pattern: "(\\d+)\\s*:\\s*['\"]([^'\"]*)['\"]") else { return nil }
        let ns = text as NSString
        var dict: [Int: String] = [:]
        for m in regex.matches(in: text, range: NSRange(location: 0, length: ns.length)) {
            if let i = Int(ns.substring(with: m.range(at: 1))) { dict[i] = ns.substring(with: m.range(at: 2)) }
        }
        guard !dict.isEmpty, let maxKey = dict.keys.max() else { return nil }
        return (0...maxKey).map { dict[$0] ?? "\($0)" }
    }
}
