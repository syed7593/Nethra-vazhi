import Foundation

// Port of the detection / guidance logic in nethracam.py.
// Everything here is pure Swift (Foundation only) so it can be unit-tested
// without a camera. Image ratios are visual cues only, never real distances.

enum DetectionConfig {
    static let cocoModelConfidence = 0.15
    static let cocoConfidence = 0.55
    static let personConfidence = 0.78
    static let chairMinConfidence = 0.45
    static let potholeConfidence = 0.70
    static let minConfirmFrames = 2
    static let personConfirmFrames = 3
    static let openVocabConfirmFrames = 3
    static let openVocabMinConfidence = 0.45
    static let openVocabEveryNCycles = 3
    static let trackIouMin = 0.12
    static let trackCenterMax = 0.035

    static let centerLeftRatio = 0.30
    static let centerRightRatio = 0.70
    static let centerOverlapMin = 0.40
    static let closeBottomRatio = 0.82
    static let closeObjectAreaRatio = 0.035
    static let closePotholeAreaRatio = 0.010
    static let approachBottomRatio = 0.58
    static let approachAreaFactor = 0.45

    /// (short label, prompt given to the open-vocabulary model). Order = model class index.
    static let openVocabLabels: [(label: String, prompt: String)] = [
        ("stairs", "staircase or steps"),
        ("curb", "road curb"),
        ("ramp", "ramp"),
        ("traffic cone", "traffic cone"),
        ("bollard", "bollard"),
        ("road barrier", "road barrier"),
        ("doorway", "open doorway"),
        ("glass door", "glass door"),
        ("pole", "street pole"),
        ("wall", "wall directly in front of the camera"),
    ]
    static var openVocabLabelSet: Set<String> { Set(openVocabLabels.map { $0.label }) }

    static let cocoHazardClasses: Set<String> = [
        "person", "bicycle", "motorcycle", "car", "bus", "truck",
        "traffic light", "stop sign", "bench", "chair", "couch",
        "dining table", "potted plant", "dog", "cat", "backpack", "umbrella",
        "handbag", "suitcase", "skateboard", "fire hydrant", "parking meter",
        "sports ball", "vase", "refrigerator", "oven", "sink", "toilet", "tv", "laptop",
        "cow", "horse", "sheep", "elephant",
    ]
}

struct Box: Equatable {
    var x1: Double
    var y1: Double
    var x2: Double
    var y2: Double
    var width: Double { max(0, x2 - x1) }
    var height: Double { max(0, y2 - y1) }
    var centerX: Double { (x1 + x2) / 2 }
}

enum Side: String { case left, center, right }
enum Proximity: String { case near, approaching, visible }

struct Hazard {
    var label: String
    var box: Box
    var frameWidth: Double
    var frameHeight: Double
    var confidence: Double
    var isPothole: Bool = false
    var openVocab: Bool = false
    var framesSeen: Int = 1
    var confirmed: Bool = false
    var side: Side = .center
    var proximity: Proximity = .visible
    var priority: Double = 0
    /// Stable id given by SceneTracker so two chairs are never confused with each other.
    var trackId: Int = 0

    var bottomRatio: Double { max(0, min(1, box.y2 / max(1e-9, frameHeight))) }
    var areaRatio: Double { box.width * box.height / max(1e-9, frameWidth * frameHeight) }
    /// Same label rule as the Python code: potholes are always "pothole".
    var trackLabel: String { isPothole ? "pothole" : label.lowercased() }
}

struct Track {
    var label: String
    var box: Box
    var framesSeen: Int
    var openVocab: Bool
    var missed: Int
}

enum HazardLogic {
    static func isReliableCocoDetection(_ name: String, confidence: Double) -> Bool {
        let label = name.trimmingCharacters(in: .whitespaces).lowercased()
        guard DetectionConfig.cocoHazardClasses.contains(label) else { return false }
        let threshold: Double
        if label == "person" { threshold = DetectionConfig.personConfidence }
        else if label == "chair" { threshold = DetectionConfig.chairMinConfidence }
        else { threshold = DetectionConfig.cocoConfidence }
        return confidence >= threshold
    }

    static func boxIoU(_ a: Box, _ b: Box) -> Double {
        let left = max(a.x1, b.x1), top = max(a.y1, b.y1)
        let right = min(a.x2, b.x2), bottom = min(a.y2, b.y2)
        let inter = max(0, right - left) * max(0, bottom - top)
        let union = a.width * a.height + b.width * b.height - inter
        return union > 0 ? inter / union : 0
    }

    /// Only report an object after stable, one-to-one matches across frames.
    static func confirm(_ hazards: [Hazard], previous: [Track]) -> (all: [Hazard], confirmed: [Hazard], tracks: [Track]) {
        var nextTracks: [Track] = []
        var used = Set<Int>()
        var all: [Hazard] = []
        var confirmed: [Hazard] = []

        for var hazard in hazards {
            let label = hazard.trackLabel
            let box = hazard.box
            var best: (score: Double, index: Int)? = nil
            for (index, track) in previous.enumerated() {
                if used.contains(index) || track.label != label { continue }
                let centerDelta = abs(box.centerX - track.box.centerX) / max(1, hazard.frameWidth)
                let overlap = boxIoU(box, track.box)
                if overlap >= DetectionConfig.trackIouMin || centerDelta <= DetectionConfig.trackCenterMax {
                    let score = 1.0 - overlap + centerDelta
                    // Python min() keeps the first of equal scores.
                    if best == nil || score < best!.score { best = (score, index) }
                }
            }
            let framesSeen: Int
            if let best = best {
                used.insert(best.index)
                framesSeen = previous[best.index].framesSeen + 1
            } else {
                framesSeen = 1
            }
            nextTracks.append(Track(label: label, box: box, framesSeen: framesSeen,
                                    openVocab: hazard.openVocab, missed: 0))
            let required: Int
            if hazard.openVocab { required = DetectionConfig.openVocabConfirmFrames }
            else if label == "person" { required = DetectionConfig.personConfirmFrames }
            else { required = DetectionConfig.minConfirmFrames }
            hazard.framesSeen = framesSeen
            hazard.confirmed = framesSeen >= required
            if hazard.confirmed { confirmed.append(hazard) }
            all.append(hazard)
        }

        // Open-vocabulary detections run every few cycles; keep their tracks alive in between.
        for (index, track) in previous.enumerated() where !used.contains(index) && track.openVocab {
            let missed = track.missed + 1
            if missed < DetectionConfig.openVocabEveryNCycles {
                var kept = track
                kept.missed = missed
                nextTracks.append(kept)
            }
        }
        return (all, confirmed, nextTracks)
    }

    static func proximityBand(_ h: Hazard) -> Proximity {
        let closeArea = h.isPothole ? DetectionConfig.closePotholeAreaRatio : DetectionConfig.closeObjectAreaRatio
        if h.bottomRatio >= DetectionConfig.closeBottomRatio && h.areaRatio >= closeArea { return .near }
        if h.bottomRatio >= DetectionConfig.approachBottomRatio || h.areaRatio >= closeArea * DetectionConfig.approachAreaFactor {
            return .approaching
        }
        return .visible
    }

    static func priority(_ h: Hazard) -> Double {
        let bonus: Double
        switch h.proximity {
        case .near: bonus = 120
        case .approaching: bonus = 45
        case .visible: bonus = 0
        }
        return bonus + (h.isPothole ? 100 : 0) + 45 * h.bottomRatio + 30 * h.areaRatio + 10 * h.confidence
    }

    /// A wide object covering the walking lane counts as "center".
    static func sideOf(_ h: Hazard) -> Side {
        let laneLeft = h.frameWidth * DetectionConfig.centerLeftRatio
        let laneRight = h.frameWidth * DetectionConfig.centerRightRatio
        let inside = min(h.box.x2, laneRight) - max(h.box.x1, laneLeft)
        if inside >= DetectionConfig.centerOverlapMin * max(1, h.box.x2 - h.box.x1) { return .center }
        return h.box.centerX < h.frameWidth / 2 ? .left : .right
    }

    /// Adds side, proximity and priority; highest priority first (stable, like Python's sort).
    static func aggregate(_ hazards: [Hazard]) -> [Hazard] {
        var items: [(Int, Hazard)] = []
        for (i, var h) in hazards.enumerated() {
            h.label = h.trackLabel
            h.side = h.frameWidth > 0 ? sideOf(h) : .center
            h.proximity = proximityBand(h)
            h.priority = priority(h)
            items.append((i, h))
        }
        items.sort { a, b in
            if a.1.priority != b.1.priority { return a.1.priority > b.1.priority }
            return a.0 < b.0
        }
        return items.map { $0.1 }
    }

    static func titleCase(_ s: String) -> String { s.capitalized }

    /// Pick the one thing to say. Only near/approaching objects alert.
    static func chooseGuidance(_ objects: [Hazard]) -> Guidance {
        let close = objects.filter { $0.proximity == .near || $0.proximity == .approaching }
        if close.isEmpty {
            if !objects.isEmpty { return Guidance(key: "far", display: "Object seen but still far - no alert", label: nil, side: nil) }
            return Guidance(key: "clear", display: "No supported obstacle detected; check with cane; route is not confirmed clear", label: nil, side: nil)
        }
        var lead = close[0]
        for item in close.dropFirst() where item.priority > lead.priority { lead = item }
        var g = chooseCloseGuidance(lead)
        g.proximity = lead.proximity
        return g
    }

    private static func chooseCloseGuidance(_ lead: Hazard) -> Guidance {
        let label = lead.label
        let cue = lead.proximity == .near ? "Near" : "Approaching"
        switch lead.side {
        case .center:
            if label == "pothole" && lead.proximity == .near {
                return Guidance(key: "pothole_ahead", display: "STOP - Close pothole ahead; cane-check", label: label, side: .center)
            }
            if label == "stairs" {
                return Guidance(key: "stairs_ahead", display: "STOP - Possible stairs ahead; confirm with cane/guide", label: label, side: .center)
            }
            return Guidance(key: "front_blocked", display: "STOP - \(cue) \(titleCase(label)) ahead; cane-check both sides", label: label, side: .center)
        case .left, .right:
            let side = lead.side.rawValue
            let opposite = lead.side == .left ? "right" : "left"
            return Guidance(key: "obstacle_\(side)",
                            display: "STOP - \(cue) \(titleCase(label)) on \(side); cane-check \(opposite), move only if verified clear",
                            label: label, side: lead.side)
        }
    }
}

struct Guidance: Equatable {
    var key: String
    var display: String
    var label: String?
    var side: Side?
    /// Proximity of the object that caused the alert (nil for clear / far).
    var proximity: Proximity? = nil
    /// How many confirmed objects of the same kind are close together on the same side ("3 chairs").
    var count: Int = 1
    /// Next most important close object (different kind or side), mentioned briefly after the main alert.
    var alsoLabel: String? = nil
    var alsoSide: Side? = nil
}

// MARK: - STOP distance threshold (added on top of nethracam.py)
//
// nethracam.py says "Stop" for every *approaching* object. The app now uses
// three distance bands from the same image cues:
//   visible      -> silent (far away)
//   approaching  -> "Caution": name the object, move to the opposite side after a cane check
//   near         -> "Stop"   (object's lower edge below DetectionConfig.closeBottomRatio = 82 %
//                             of the frame AND it fills enough of the image)
// To make STOP trigger earlier (farther away) lower closeBottomRatio, e.g. 0.75;
// to trigger later raise it, e.g. 0.88.
extension HazardLogic {
    static func applyStopThreshold(_ g: Guidance) -> Guidance {
        // Possible ramp / slope ahead: always a slow-down warning, never a hard stop.
        if g.label == "ramp", g.proximity != nil {
            return Guidance(key: "ramp_ahead", display: "CAUTION - Possible ramp / slope ahead; walk slowly, cane-check",
                            label: "ramp", side: g.side, proximity: g.proximity)
        }
        guard g.proximity == .approaching, let label = g.label else { return g }
        let name = titleCase(label)
        switch g.key {
        case "front_blocked":
            return Guidance(key: "caution_ahead", display: "CAUTION - Approaching \(name) ahead; slow down, cane-check both sides",
                            label: label, side: .center, proximity: .approaching)
        case "obstacle_left":
            return Guidance(key: "caution_left", display: "CAUTION - Approaching \(name) on left; cane-check right, keep right",
                            label: label, side: .left, proximity: .approaching)
        case "obstacle_right":
            return Guidance(key: "caution_right", display: "CAUTION - Approaching \(name) on right; cane-check left, keep left",
                            label: label, side: .right, proximity: .approaching)
        default:
            return g   // stairs stay STOP even when approaching; potholes only alert when near
        }
    }
}
