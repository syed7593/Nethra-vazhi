import Foundation

/// Port of play_tts / select_alert_during_playback from nethracam.py:
/// routine audio is not cut off; only STOP-level alerts or conflicting
/// directions interrupt, and repeats are rate limited.
struct AlertArbiter {
    static let alertCooldown = 0.35
    static let repeatCooldown = 3.0
    static let urgentRepeatCooldown = 0.75
    static let clearRepeatCooldown = 15.0
    /// "Caution" (approaching) sentences repeat less often than STOP.
    static let cautionRepeatCooldown = 6.0

    enum Decision: Equatable {
        case skip
        case speak(key: String, text: String)
    }

    private(set) var lastKey: String?
    private(set) var lastText: String?
    private(set) var lastTime: Double = -1e9

    static func priority(_ key: String?) -> Int {
        guard let key = key else { return 0 }
        let table: [String: Int] = [
            "safety_stop": 150, "pothole_ahead": 145, "stairs_ahead": 140,
            "front_blocked": 138, "stop": 125, "system_ready": 90, "nav_prompt": 85,
            "user_command": 80, "slope_up": 78, "slope_down": 78, "obstacle_left": 75, "obstacle_right": 75,
            "ramp_ahead": 74, "slow_left": 70, "slow_right": 70, "caution_ahead": 72, "caution_left": 65, "caution_right": 65, "slope_level": 15,
            "pause": 70, "resume": 70, "route_status": 25, "route_instruction": 20, "clear": 10,
        ]
        return table[key] ?? 0
    }

    static func direction(_ key: String?) -> String? {
        guard let key = key else { return nil }
        if key.hasSuffix("_left") { return "left" }
        if key.hasSuffix("_right") { return "right" }
        return nil
    }

    static func isUrgent(_ key: String?) -> Bool { priority(key) >= 120 }

    static func selectDuringPlayback(current: String?, requested: String?, audioBusy: Bool) -> String? {
        guard let requested = requested else { return nil }
        guard audioBusy, let current = current else { return requested }
        if current == requested { return nil }
        if let a = direction(current), let b = direction(requested), a != b { return "stop" }
        if priority(requested) > priority(current) && priority(requested) > 0 { return requested }
        return nil
    }

    /// Decide whether to speak `text` for `key` now. `safetyStopText` replaces
    /// the alert when two directions conflict. Records what was spoken.
    mutating func decide(key: String, text: String, explicit: Bool, now: Double,
                         audioBusy: Bool, safetyStopText: String) -> Decision {
        var key = key
        var text = text
        var selected = AlertArbiter.selectDuringPlayback(current: lastKey, requested: key, audioBusy: audioBusy)
        if audioBusy && key == lastKey && text != lastText { selected = key }
        if selected == "stop" && key != "stop" {
            key = "safety_stop"
            text = safetyStopText
        } else if selected == nil || selected != key {
            return .skip
        }

        if !explicit && text == lastText {
            let cooldown: Double
            if AlertArbiter.isUrgent(key) { cooldown = AlertArbiter.urgentRepeatCooldown }
            else if key == "clear" { cooldown = AlertArbiter.clearRepeatCooldown }
            else if key.hasPrefix("caution_") || key.hasPrefix("slow_") || key == "ramp_ahead" { cooldown = AlertArbiter.cautionRepeatCooldown }
            else { cooldown = AlertArbiter.repeatCooldown }
            if now - lastTime < cooldown { return .skip }
        } else if !explicit && !AlertArbiter.isUrgent(key) && now - lastTime < AlertArbiter.alertCooldown {
            return .skip
        }
        lastKey = key
        lastText = text
        lastTime = now
        return .speak(key: key, text: text)
    }
}
