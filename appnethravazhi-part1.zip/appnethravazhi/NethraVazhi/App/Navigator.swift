import Foundation

/// The triple-tap navigation mode:
///  1. asks "Where do you want to go?" by voice and listens for the answer,
///  2. finds the place and asks the user to confirm it,
///  3. uses the iPhone's current GPS location as the starting point
///     (if GPS is not available it asks the user to say where they are),
///  4. fetches an OpenStreetMap walking route and follows it turn by turn.
/// Camera detection keeps running the whole time and its warnings win.
@MainActor
final class Navigator {
    enum Phase: String {
        case idle, listening, searching, confirming, locating, routing, navigating
    }

    struct Announcement {
        var stepIndex: Int
        var text: String
    }

    private let speech: SpeechService
    private let voice: VoiceInput
    private let location: LocationService
    private let routing: RoutingService

    private(set) var phase: Phase = .idle
    private var flowTask: Task<Void, Never>?
    private var timer: Timer?
    private var route: WalkingRoute?
    private var destination: PlaceResult?
    private var geometryIndex = 0
    private var offRouteHits = 0
    private var rerouting = false
    private var lastStatusSpoken = Date.distantPast
    private var lastStatus = ""

    /// Status line for the screen.
    var onStatus: ((String) -> Void)?
    /// Called when navigation ends by itself (arrived / cancelled / failed).
    var onFinished: (() -> Void)?
    /// Current route step to announce when the camera reports no close hazard.
    private(set) var announcement: Announcement?
    private(set) var distanceToStep: Double?
    /// Increments every time a new route is fetched (so steps are re-announced).
    private(set) var routeVersion = 0

    var isActive: Bool { phase != .idle }
    /// True while a question is being asked or answered (camera speech holds back).
    private(set) var isListening = false
    private var messages: Messages { speech.messages }

    init(speech: SpeechService, voice: VoiceInput, location: LocationService, routing: RoutingService) {
        self.speech = speech
        self.voice = voice
        self.location = location
        self.routing = routing
    }

    func start() {
        guard phase == .idle else { return }
        location.start()
        phase = .listening
        flowTask = Task { [weak self] in await self?.runConversation() }
    }

    func stop(announce: Bool) {
        flowTask?.cancel()
        flowTask = nil
        voice.cancel()
        isListening = false
        timer?.invalidate()
        timer = nil
        route = nil
        destination = nil
        announcement = nil
        distanceToStep = nil
        phase = .idle
        location.stop()
        status("Detection mode")
        if announce { speech.say(messages.navStopped) }
    }

    private func finish(saying text: String?) {
        stop(announce: false)
        if let text = text { speech.say(text) }
        onFinished?()
    }

    private func status(_ text: String) {
        lastStatus = text
        onStatus?(text)
    }

    // MARK: Conversation
    private func ask(_ prompt: String, maxSeconds: Double = 8) async -> String {
        isListening = true
        defer { isListening = false }
        await speech.sayAndWait(prompt)
        if Task.isCancelled { return "" }
        speech.beep()
        try? await Task.sleep(nanoseconds: 350_000_000)
        if Task.isCancelled { return "" }
        let answer = await voice.listen(language: speech.language, maxSeconds: maxSeconds)
        status("Heard: \(answer.isEmpty ? "(nothing)" : answer)")
        return answer
    }

    private func runConversation() async {
        guard await VoiceInput.requestPermissions() else {
            finish(saying: messages.micDenied)
            return
        }
        if location.authorization == .denied || location.authorization == .restricted {
            finish(saying: messages.locationDenied)
            return
        }

        // 1. Destination
        status("Listening for destination…")
        var spoken = await ask(messages.navStart)
        if Task.isCancelled { return }
        if spoken.isEmpty {
            spoken = await ask(messages.askDestinationAgain)
            if Task.isCancelled { return }
        }
        if spoken.isEmpty || RouteLogic.isCancel(spoken) {
            finish(saying: spoken.isEmpty ? messages.noPlaceFound : messages.navStopped)
            return
        }

        // 2. Find and confirm the place
        phase = .searching
        status("Searching: \(spoken)")
        speech.say(messages.searching(spoken))
        let near = location.currentFix()?.0
        let results = await routing.searchPlaces(spoken, near: near)
        if Task.isCancelled { return }
        if results.isEmpty {
            finish(saying: messages.noPlaceFound)
            return
        }
        phase = .confirming
        var chosen: PlaceResult?
        for (i, place) in results.enumerated() {
            status("Confirm: \(place.label)")
            let answer = await ask(messages.confirmPlace(place.label, index: i + 1, total: results.count), maxSeconds: 6)
            if Task.isCancelled { return }
            if RouteLogic.isCancel(answer) { finish(saying: messages.navStopped); return }
            if RouteLogic.isYes(answer) { chosen = place; break }
        }
        guard let target = chosen else {
            finish(saying: messages.noMoreResults)
            return
        }
        destination = target

        // 3. Starting point = current GPS location
        phase = .locating
        status("Getting GPS location…")
        var start = location.reliableFix()
        if start == nil {
            speech.say(messages.waitingForGPS)
            for _ in 0..<40 {
                try? await Task.sleep(nanoseconds: 500_000_000)
                if Task.isCancelled { return }
                if let fix = location.reliableFix() { start = fix; break }
            }
        }
        if start == nil {
            // No usable GPS: ask the user where they are now.
            let here = await ask(messages.askCurrentLocation)
            if Task.isCancelled { return }
            if !here.isEmpty {
                let places = await routing.searchPlaces(here, near: location.currentFix()?.0 ?? target.coordinate)
                if let first = places.first {
                    let ok = await ask(messages.confirmStart(first.label), maxSeconds: 5)
                    if RouteLogic.isYes(ok) { start = first.coordinate }
                }
            }
            if start == nil { start = location.currentFix()?.0 }
        }
        guard let origin = start else {
            finish(saying: messages.noPlaceFound)
            return
        }

        // 4. Route
        guard await fetchRoute(from: origin, announceReady: true) else { return }
        phase = .navigating
        startTimer()
    }

    /// Returns false (and ends navigation) if no route could be found after retries.
    private func fetchRoute(from origin: Coordinate, announceReady: Bool) async -> Bool {
        guard let target = destination else { return false }
        phase = .routing
        status("Getting walking route…")
        speech.say(messages.gettingRoute)
        for attempt in 1...3 {
            if Task.isCancelled { return false }
            do {
                let newRoute = try await routing.walkingRoute(from: origin, to: target.coordinate)
                route = newRoute
                routeVersion += 1
                geometryIndex = 0
                offRouteHits = 0
                announcement = nil
                if announceReady {
                    await speech.sayAndWait(messages.routeReady(distanceM: newRoute.distanceM, durationS: newRoute.durationS))
                }
                status("Navigating to \(target.label)")
                phase = .navigating
                return true
            } catch {
                print("Route attempt \(attempt) failed: \(error)")
                status("Route error: \(error.localizedDescription)")
                speech.speakAlert(key: "route_status", text: messages.routeError)
                try? await Task.sleep(nanoseconds: 5_000_000_000)
            }
        }
        finish(saying: messages.routeError)
        return false
    }

    // MARK: Following the route (once per second, like ROUTE_POLL_SECONDS)
    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
    }

    private func speakStatusOccasionally(_ text: String) {
        if Date().timeIntervalSince(lastStatusSpoken) > 30 {
            lastStatusSpoken = Date()
            speech.speakAlert(key: "route_status", text: text)
        }
    }

    private func tick() {
        guard phase == .navigating, let route = route, !rerouting else { return }
        guard let fix = location.currentFix() else {
            status("Waiting for a reliable GPS fix")
            return
        }
        let here = fix.0
        let accuracy = fix.1
        if accuracy > RouteConfig.gpsMaxAccuracyMeters {
            status("GPS accuracy is low (\(Int(accuracy)) m)")
            speakStatusOccasionally(messages.poorGPS)
            return
        }
        if let last = route.geometry.last, RouteLogic.haversineM(here, last) <= RouteConfig.arrivalMeters {
            finish(saying: messages.arrived)
            return
        }
        let progress = RouteLogic.progress(route: route, at: here, lastIndex: geometryIndex)
        geometryIndex = progress.geometryIndex
        let nearestDistance = RouteLogic.haversineM(here, route.geometry[min(geometryIndex, route.geometry.count - 1)])
        offRouteHits = nearestDistance > RouteConfig.offRouteMeters ? offRouteHits + 1 : 0
        if offRouteHits >= RouteConfig.offRouteHits {
            status("Possibly off route – rerouting")
            speech.speakAlert(key: "user_command", text: messages.offRoute)
            rerouting = true
            Task { [weak self] in
                guard let self = self else { return }
                _ = await self.fetchRoute(from: here, announceReady: false)
                self.rerouting = false
            }
            return
        }
        let step = route.steps[progress.stepIndex]
        let text = RouteLogic.instruction(step.instruction, distanceM: progress.announceDistanceM, language: speech.language)
        distanceToStep = progress.distanceToStepM
        if announcement?.stepIndex != progress.stepIndex {
            announcement = Announcement(stepIndex: progress.stepIndex, text: text)
        } else if var current = announcement {
            current.text = text
            announcement = current
        }
        status("\(step.instruction) (\(Int(progress.distanceToStepM)) m)")
    }
}
