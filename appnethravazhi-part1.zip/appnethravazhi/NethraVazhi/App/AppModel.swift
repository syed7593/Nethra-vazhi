import Foundation
import Combine
import AVFoundation
import UIKit

/// Runs detection on camera frames (off the main thread).
final class DetectionLoop: @unchecked Sendable {   // only touched on the camera queue
    let detector = DetectorService()
    private var lastRun: Double = 0
    /// Called on the camera queue with a result or an error message.
    var onResult: (@Sendable (DetectionFrame?, String?) -> Void)?

    func attach(_ camera: CameraService) {
        camera.onFrame = { [weak self] buffer in self?.handle(buffer) }
    }

    private func handle(_ buffer: CVPixelBuffer) {
        let now = ProcessInfo.processInfo.systemUptime
        guard now - lastRun >= AppConfig.detectionInterval else { return }
        lastRun = now
        guard detector.isReady else { return }
        do {
            let frame = try detector.process(buffer)
            onResult?(frame, nil)
        } catch {
            detector.resetTracking()
            onResult?(nil, error.localizedDescription)
        }
    }
}

struct OverlayBox: Identifiable {
    let id: Int
    /// Normalized rect in the upright camera image (0...1).
    let x1: Double, y1: Double, x2: Double, y2: Double
    let text: String
    let confirmed: Bool
}

@MainActor
final class AppModel: ObservableObject {
    enum Mode { case detection, navigation }

    @Published var mode: Mode = .detection
    @Published var guidanceText = "Starting Nethra Vazhi…"
    @Published var navStatus = ""
    @Published var boxes: [OverlayBox] = []
    @Published var paused = false
    @Published var infoText = ""
    /// Shown in red only when a model could not be loaded.
    @Published var modelProblem = ""
    /// Live diagnostics: detection cycles per second and seconds since the last result.
    @Published var statsText = ""
    @Published var cameraReady = false

    let camera = CameraService()
    let speech = SpeechService()
    private let loop = DetectionLoop()
    private let location = LocationService()
    private let voice = VoiceInput()
    private let routing = RoutingService()
    private let slope = SlopeMonitor()
    private var slopeText = ""
    private lazy var navigator: Navigator = {
        let nav = Navigator(speech: speech, voice: voice, location: location, routing: routing)
        nav.onStatus = { [weak self] text in self?.navStatus = text }
        nav.onFinished = { [weak self] in self?.mode = .detection }
        return nav
    }()

    private var started = false
    private var running = false
    private var currentGuidance: Guidance?
    private var lastProcessed: Double = 0
    private var watchdog: Timer?
    private var lastRouteSpoken: (version: Int, step: Int)?
    private var lastVibration: Double = 0
    private var observers: [NSObjectProtocol] = []
    private var cyclesSinceStats = 0
    private var lastStatsTime: Double = 0
    private var lastCameraRestart: Double = 0
    private var detectionErrors = 0
    private var lastSignature = ""
    private var lastSignatureText = ""
    private var lastSignatureTime: Double = 0

    private var messages: Messages { speech.messages }
    private var now: Double { ProcessInfo.processInfo.systemUptime }

    // MARK: Lifecycle
    func start() async {
        guard !started else { return }
        started = true
        UIApplication.shared.isIdleTimerDisabled = true
        SpeechService.configureAudioSession()
        speech.chooseVoice()

        guard await CameraService.requestPermission() else {
            guidanceText = "Camera permission needed"
            speech.say(messages.cameraDenied)
            return
        }
        guidanceText = "Loading detection models…"
        let detector = loop.detector
        await Task.detached(priority: .userInitiated) { detector.load() }.value
        infoText = "Models: \(detector.loadedModelNames.joined(separator: ", ")) · Voice: \(speech.voiceDescription)"
        if !detector.loadErrors.isEmpty {
            print("Model load problems: \(detector.loadErrors)")
            modelProblem = detector.loadErrors.joined(separator: "\n")
        }
        if !detector.loadNotes.isEmpty { print("Model notes: \(detector.loadNotes)") }
        if !detector.isReady {
            guidanceText = "Detection models missing"
            speech.say(messages.modelsMissing)
        }

        loop.onResult = { [weak self] frame, error in
            Task { @MainActor in self?.apply(frame: frame, error: error) }
        }
        loop.attach(camera)
        do {
            try camera.configure()
            cameraReady = true
        } catch {
            guidanceText = "Camera error: \(error.localizedDescription)"
            speech.say(messages.cameraDenied)
            return
        }
        location.requestPermission()
        observeAudioInterruptions()
        slope.onEvent = { [weak self] event in
            Task { @MainActor in self?.slopeEvent(event) }
        }
        resume()
        speech.speakAlert(key: "system_ready", text: messages.startup, explicit: true)
        guidanceText = "Starting detection…"
    }

    func resume() {
        guard started, cameraReady, !running else { return }
        running = true
        SpeechService.configureAudioSession()   // re-activate audio after lock / other apps
        camera.start()
        slope.start()
        lastProcessed = now + 2.0   // grace period while the camera starts
        watchdog?.invalidate()
        watchdog = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.checkWatchdog() }
        }
    }

    func pauseForBackground() {
        guard running else { return }
        running = false
        watchdog?.invalidate()
        watchdog = nil
        camera.stop()
        slope.stop()
        if navigator.isActive {
            navigator.stop(announce: false)
            mode = .detection
        }
        speech.stop()
    }

    // MARK: Detection results
    private func apply(frame: DetectionFrame?, error: String?) {
        guard running else { return }
        guard let frame = frame else {
            guidanceText = "STOP - Detection error; wait and check safely"
            detectionErrors += 1
            speakSafetyStop()
            print("Detection error: \(error ?? "")")
            return
        }
        lastProcessed = now
        cyclesSinceStats += 1
        // nethracam.py guidance + the STOP distance threshold (approaching = caution, near = stop).
        let guidance = SceneLogic.applyThreshold(frame.guidance)
        currentGuidance = guidance
        guidanceText = guidance.display
        boxes = frame.candidates.enumerated().map { i, h in
            var label = h.label
            if label == "person" { label = "possible person?" }
            else if h.openVocab { label = "possible \(label)?" }
            let state = h.confirmed ? "confirmed" : "checking \(h.framesSeen)"
            if h.trackId > 0 { label += " #\(h.trackId)" }
            return OverlayBox(id: i, x1: h.box.x1 / frame.frameWidth, y1: h.box.y1 / frame.frameHeight,
                              x2: h.box.x2 / frame.frameWidth, y2: h.box.y2 / frame.frameHeight,
                              text: "\(label) \(String(format: "%.2f", h.confidence)) \(state)", confirmed: h.confirmed)
        }
        speakGuidance(guidance)
        maybeSpeakRoute()
    }

    /// speak_guidance from nethracam.py.
    private func speakGuidance(_ g: Guidance) {
        if g.key == "far" { return }
        if navigator.isActive && g.key == "clear" { return }   // route directions speak instead
        let urgent = AlertArbiter.isUrgent(g.key)
        if navigator.isListening {
            // Don't talk over the user's answer; vibrate for urgent hazards.
            if urgent && now - lastVibration > 1.0 {
                lastVibration = now
                AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
            }
            return
        }
        if paused && !urgent { return }
        speech.speakAlert(key: g.key, text: stableText(for: g))
    }

    /// Keeps the sentence identical while the same object stays the lead, so a chair count
    /// changing 2 -> 3 does not cut off and re-start the announcement.
    private func stableText(for g: Guidance) -> String {
        let signature = "\(g.key)|\(g.label ?? "")|\(g.side?.rawValue ?? "")"
        if signature == lastSignature, now - lastSignatureTime < 8 { return lastSignatureText }
        lastSignature = signature
        lastSignatureText = messages.spokenScene(for: g)
        lastSignatureTime = now
        return lastSignatureText
    }

    /// Route step is spoken only when the camera reports no close hazard.
    private func maybeSpeakRoute() {
        guard navigator.phase == .navigating, !paused, let ann = navigator.announcement else { return }
        let key = currentGuidance?.key ?? "clear"
        guard key == "clear" || key == "far", now - lastProcessed <= AppConfig.detectionStaleSeconds else { return }
        if let last = lastRouteSpoken, last.version == navigator.routeVersion, last.step == ann.stepIndex { return }
        if speech.speakAlert(key: "route_instruction", text: ann.text) {
            lastRouteSpoken = (navigator.routeVersion, ann.stepIndex)
        }
    }

    private func checkWatchdog() {
        guard running, loop.detector.isReady else { return }
        let stale = now - lastProcessed
        if stale > AppConfig.detectionStaleSeconds {
            guidanceText = "STOP - Detection delayed; wait and check safely"
            if !navigator.isListening { speakSafetyStop() }
            // Frames stopped for a while: restart the camera session (at most every 5 s).
            if stale > 4 && now - lastCameraRestart > 5 {
                lastCameraRestart = now
                print("No detections for \(Int(stale)) s - restarting camera")
                camera.restart()
            }
        }
        if now - lastStatsTime >= 2 {
            let rate = Double(cyclesSinceStats) / max(0.001, now - lastStatsTime)
            statsText = String(format: "%.1f detections/s · last result %.1f s ago · errors %d", rate, max(0, stale), detectionErrors) + slopeText
            cyclesSinceStats = 0
            lastStatsTime = now
        }
    }

    /// Barometer + pedometer slope warnings.
    private func slopeEvent(_ event: SlopeEvent) {
        let key: String, text: String
        switch event {
        case .uphill(let pct):
            key = "slope_up"; text = messages.slope(uphill: true, gradePercent: pct); slopeText = " · uphill \(pct)%"
        case .downhill(let pct):
            key = "slope_down"; text = messages.slope(uphill: false, gradePercent: pct); slopeText = " · downhill \(pct)%"
        case .level:
            key = "slope_level"; text = messages.slopeEnded; slopeText = ""
        }
        guard running, !navigator.isListening, !paused else { return }
        speech.speakAlert(key: key, text: text, queueIfBusy: true)
    }

    /// Phone calls, Siri, alarms etc. deactivate our audio; turn it back on afterwards.
    private func observeAudioInterruptions() {
        let center = NotificationCenter.default
        observers.append(center.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] note in
            let raw = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt
            let ended = raw == AVAudioSession.InterruptionType.ended.rawValue
            Task { @MainActor in self?.audioInterruption(ended: ended) }
        })
        observers.append(center.addObserver(forName: AVAudioSession.mediaServicesWereResetNotification, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.audioInterruption(ended: true) }
        })
    }

    private func audioInterruption(ended: Bool) {
        guard ended else { return }
        SpeechService.configureAudioSession()
        if running { camera.start() }
    }

    private func speakSafetyStop() {
        speech.speakAlert(key: "safety_stop", text: messages.safetyStop)
    }

    // MARK: Gestures
    func tripleTap() {
        if navigator.isActive {
            navigator.stop(announce: true)
            mode = .detection
            navStatus = ""
        } else {
            mode = .navigation
            lastRouteSpoken = nil
            navigator.start()
        }
    }

    func doubleTap() {
        guard !navigator.isListening else { return }
        let key = currentGuidance?.key ?? "clear"
        if navigator.phase == .navigating, key == "clear" || key == "far", let ann = navigator.announcement {
            speech.speakAlert(key: "route_instruction", text: ann.text, explicit: true)
            return
        }
        if let g = currentGuidance, g.key != "far" {
            speech.speakAlert(key: g.key, text: messages.spokenScene(for: g), explicit: true)
        } else if let g = currentGuidance {
            speech.speakAlert(key: "user_command", text: g.display, explicit: true)
        }
    }

    func longPress() {
        paused.toggle()
        speech.speakAlert(key: paused ? "pause" : "resume", text: paused ? messages.paused : messages.resumed, explicit: true)
    }

    func help() {
        guard !navigator.isListening else { return }
        speech.speakAlert(key: "user_command", text: messages.help, explicit: true)
    }
}
