import Foundation

enum AppConfig {
    /// OpenRouteService key (copied from osmmap.py). Get your own free key at
    /// https://openrouteservice.org/dev/#/signup and paste it here if this one stops working.
    static let orsApiKey = "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjcxMmE4ZTI0YTRmZTQzZmJhZjg0NzViNTU0YjE4ZDQ3IiwiaCI6Im11cm11cjY0In0="
    static let orsDirectionsURL = "https://api.openrouteservice.org/v2/directions/foot-walking/json"
    static let orsGeocodeURL = "https://api.openrouteservice.org/geocode/search"
    static let requestTimeoutSeconds = 15.0

    /// Bundled CoreML models (names of the .mlpackage files in Models/).
    static let cocoModelName = "COCODetector"
    static let potholeModelName = "PotholeDetector"
    static let hazardModelName = "HazardDetector"

    /// Seconds between detection cycles (the Python app ran every 3rd frame of a 30 fps camera).
    static let detectionInterval = 0.1
    /// true: a sentence being spoken is always finished before the next alert starts.
    /// false: urgent alerts may cut in (the old behaviour).
    static let finishSentenceBeforeNext = true
    /// Speak a safety stop if detection results are older than this.
    static let detectionStaleSeconds = 1.5
}
