import SwiftUI
import AVFoundation
import UIKit

struct ContentView: View {
    @ObservedObject var model: AppModel

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()
                if model.cameraReady {
                    CameraPreview(session: model.camera.session)
                        .ignoresSafeArea()
                }
                BoxOverlay(boxes: model.boxes, size: geo.size)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)

                VStack(spacing: 8) {
                    HStack {
                        Text(model.mode == .navigation ? "NAVIGATION + DETECTION" : "DETECTION")
                            .font(.headline.weight(.heavy))
                            .padding(.horizontal, 12).padding(.vertical, 6)
                            .background(model.mode == .navigation ? Color.blue : Color.green)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                        if model.paused {
                            Text("PAUSED")
                                .font(.headline.weight(.heavy))
                                .padding(.horizontal, 12).padding(.vertical, 6)
                                .background(Color.orange).foregroundColor(.black)
                                .clipShape(Capsule())
                        }
                        Spacer()
                    }
                    if !model.navStatus.isEmpty {
                        Text(model.navStatus)
                            .font(.subheadline.weight(.semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(8)
                            .background(Color.black.opacity(0.6))
                            .cornerRadius(8)
                    }
                    Spacer()
                    Text(model.guidanceText)
                        .font(.title3.weight(.bold))
                        .foregroundColor(model.guidanceText.hasPrefix("STOP") ? Color.yellow : Color.white)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(12)
                        .background(Color.black.opacity(0.7))
                        .cornerRadius(12)
                    if !model.modelProblem.isEmpty {
                        Text("Model problem:\n" + model.modelProblem)
                            .font(.caption2)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(8)
                            .background(Color.red.opacity(0.8))
                            .cornerRadius(8)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .allowsHitTesting(false)
                .accessibilityHidden(true)

                // Full-screen gesture surface (works with VoiceOver via direct interaction).
                GestureLayer(onTripleTap: { model.tripleTap() })
                    .ignoresSafeArea()
            }
        }
        .statusBarHidden(true)
    }
}

/// Live camera preview.
struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession

    final class PreviewView: UIView {
        override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
        var previewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
    }

    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView()
        view.previewLayer.session = session
        view.previewLayer.videoGravity = .resizeAspectFill
        if let connection = view.previewLayer.connection, connection.isVideoRotationAngleSupported(90) {
            connection.videoRotationAngle = 90
        }
        return view
    }

    func updateUIView(_ uiView: PreviewView, context: Context) {
        if let connection = uiView.previewLayer.connection, connection.isVideoRotationAngleSupported(90),
           connection.videoRotationAngle != 90 {
            connection.videoRotationAngle = 90
        }
    }
}

/// Draws detection boxes: yellow = still checking, green = confirmed (like the Python window).
struct BoxOverlay: View {
    let boxes: [OverlayBox]
    let size: CGSize

    var body: some View {
        Canvas { context, canvasSize in
            // Camera image is 3:4 portrait shown with aspect-fill.
            let imageAspect = 3.0 / 4.0
            let viewW = Double(canvasSize.width), viewH = Double(canvasSize.height)
            var drawW = viewW, drawH = viewW / imageAspect
            if drawH < viewH { drawH = viewH; drawW = viewH * imageAspect }
            let offX = (viewW - drawW) / 2, offY = (viewH - drawH) / 2
            for b in boxes {
                let rect = CGRect(x: offX + b.x1 * drawW, y: offY + b.y1 * drawH,
                                  width: (b.x2 - b.x1) * drawW, height: (b.y2 - b.y1) * drawH)
                let color: Color = b.confirmed ? .green : .yellow
                context.stroke(Path(rect), with: .color(color), lineWidth: 3)
                context.draw(Text(b.text).font(.caption.bold()).foregroundColor(color),
                             at: CGPoint(x: rect.minX + 4, y: max(10, rect.minY - 10)), anchor: .leading)
            }
        }
    }
}

/// Transparent full-screen view with the only gesture of the app:
/// triple tap = detection <-> navigation + detection.
struct GestureLayer: UIViewRepresentable {
    var onTripleTap: () -> Void

    final class Coordinator: NSObject {
        var parent: GestureLayer
        init(_ parent: GestureLayer) { self.parent = parent }
        @objc func handleTriple() { parent.onTripleTap() }
    }

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .clear
        // VoiceOver: let taps go straight to the app.
        view.isAccessibilityElement = true
        view.accessibilityLabel = "Nethra Vazhi camera"
        view.accessibilityHint = "Triple tap to start or stop navigation."
        view.accessibilityTraits = .allowsDirectInteraction

        let triple = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTriple))
        triple.numberOfTapsRequired = 3
        view.addGestureRecognizer(triple)
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        context.coordinator.parent = self
    }
}
