import SwiftUI

@main
struct NethraVazhiApp: App {
    @StateObject private var model = AppModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView(model: model)
                .task { await model.start() }
                .onChange(of: scenePhase) { _, phase in
                    switch phase {
                    case .active: model.resume()
                    case .background: model.pauseForBackground()
                    default: break
                    }
                }
        }
    }
}
